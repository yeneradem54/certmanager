function New-PSDashboard {
<#
.SYNOPSIS
Guncel sertifika verisiyle statik HTML dashboard olusturur (v2.2 - action butonlari).
.DESCRIPTION
Her sertifika icin action butonlari (+ Yenile, + Export, Cp Y, Cp D) render eder.
Butonlar JavaScript ile localStorage'a yazar; "Kuyrugu Indir" ile JSON dosyasi indirilir.
PowerShell tarafinda Import-PSCMActionFile ile aktarilir.
#>
    [CmdletBinding()]
    param([switch]$Open)
    $template = Join-Path $PSScriptRoot '..\Templates\dashboard-template.html'
    if (-not (Test-Path -LiteralPath $template)) {
        throw (New-PSCMException -Message 'Dashboard sablonu bulunamadi.' -Category 'Yapilandirma' -ErrorCode 'PSCM-3020')
    }
    Add-Type -AssemblyName System.Web -EA SilentlyContinue
    $certs = @(Get-PSCertificate)
    $rows = ''
    if ($certs.Count -gt 0) {
        foreach ($c in $certs) {
            $badge = 'status-ok'
            switch ($c.Status) {
                'Healthy'  { $badge='status-ok' }
                'Warning'  { $badge='status-warn' }
                'Critical' { $badge='status-crit' }
                'Expired'  { $badge='status-exp' }
            }
            $wildcardTr = if ($c.Wildcard) { 'Evet' } else { 'Hayir' }
            $domainEnc = [System.Web.HttpUtility]::HtmlEncode([string]$c.Domain)
            $issuerEnc = [System.Web.HttpUtility]::HtmlEncode([string]$c.Issuer)
            $domJs = ([string]$c.Domain).Replace("'","\'")
            $btns  = ('<button class="btn-renew" title="Sertifikayi Yenilemek Icin Kuyruga Ekle" onclick="enqueue(''renew'',''{0}'')"><svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg> Yenile</button>' -f $domJs)
            $rows += ('<tr><td><strong>{0}</strong></td><td>{1}</td><td>{2}</td><td>{3}</td><td><strong>{4} Gün</strong></td><td><span class="badge {5}">{6}</span></td><td class="actions">{7}</td></tr>' -f `
                $domainEnc, $wildcardTr, $issuerEnc, $c.NotAfter, $c.DaysRemaining, $badge, $c.Status, $btns)
        }
    } else {
        $rows = '<tr><td colspan="7" style="text-align:center;padding:20px;">Henuz kayitli sertifika yok.</td></tr>'
    }
    $html = Get-Content -LiteralPath $template -Raw -Encoding UTF8
    $ver = (Get-PSCMVersion).Version
    $now = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $total = $certs.Count
    $ok = @($certs | Where-Object { $_.Status -eq 'Healthy' }).Count
    $warn = @($certs | Where-Object { $_.Status -eq 'Warning' }).Count
    $crit = @($certs | Where-Object { $_.Status -in @('Critical','Expired') }).Count
    $html = $html.Replace('{{VERSION}}',[string]$ver).Replace('{{GENERATED}}',$now).Replace('{{ROWS}}',$rows)
    $html = $html.Replace('{{TOTAL}}',[string]$total).Replace('{{OK}}',[string]$ok).Replace('{{WARN}}',[string]$warn).Replace('{{CRIT}}',[string]$crit)
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    $out = Join-Path (Get-PSCMPath -Name Dashboard) ('dashboard-{0}.html' -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
    [System.IO.File]::WriteAllText($out,$html,$utf8)
    $latest = Join-Path (Get-PSCMPath -Name Dashboard) 'dashboard.html'
    [System.IO.File]::WriteAllText($latest,$html,$utf8)
    Write-PSCMLog -Level INFO -Message ('Dashboard uretildi: ' + $out) -Source 'Dashboard'
    if ($Open) { try { Start-Process $out } catch {} }
    return $out
}
