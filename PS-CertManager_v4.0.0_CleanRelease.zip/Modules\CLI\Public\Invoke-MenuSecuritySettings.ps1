function Invoke-MenuSecuritySettings {
    $run = $true
    while ($run) {
        Show-PSCMBanner
        Write-Host '  --- GUVENLIK, PAROLA & KASA AYARLARI ---' -ForegroundColor Yellow
        Write-Host ''
        $defaultPass = Get-PSCMSecret -Name 'Certificate.DefaultPfxPassword'
        $pfxStatus = if ($defaultPass) { 'Kayitli (SecretStore)' } else { 'Belirlenmedi' }
        Write-Host ('  Varsayilan PFX Parolasi: ' + $pfxStatus) -ForegroundColor Cyan
        Write-Host ''
        Write-Host '  [1] Varsayilan PFX Parolasini Degistir' -ForegroundColor White
        Write-Host '  [2] SecretStore Politikasini Ayarla (Session / None / Strict)' -ForegroundColor White
        Write-Host '  [3] SecretStore Kasasinin Kilidini Ac' -ForegroundColor White
        Write-Host '  [4] Ozel Parola / Gizli Anahtar Kaydet' -ForegroundColor White
        Write-Host '  [5] Gelismis Sistem Ayarlarini Goruntule / Duzenle' -ForegroundColor White
        Write-Host ''
        Write-Host '  Enter) Ana Menuye Don' -ForegroundColor DarkGray
        Write-Host ''
        
        $sel = Read-Host 'Secim'
        switch ($sel) {
            ''  { $run = $false }
            '0' { $run = $false }
            '1' {
                Write-Host 'Yeni varsayilan PFX parolasi girin (temizlemek icin bos birakin):'
                $val = Read-Host -AsSecureString
                try {
                    if ($val.Length -gt 0) {
                        Set-PSCMSecret -Name 'Certificate.DefaultPfxPassword' -Value $val
                        Write-Host 'Varsayilan PFX parolasi SecretStore''a kaydedildi.' -ForegroundColor Green
                    } else {
                        Remove-PSCMSecret -Name 'Certificate.DefaultPfxPassword' -EA SilentlyContinue
                        Write-Host 'Varsayilan PFX parolasi silindi.' -ForegroundColor Green
                    }
                } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
                Pause-PSCM
            }
            '2' { Invoke-MenuSecretPolicy }
            '3' { try { Unlock-PSCMSecretStore | Out-Null; Write-Host 'Kasa acildi.' -ForegroundColor Green } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }; Pause-PSCM }
            '4' {
                $name = Read-Host 'Secret Ismi'
                $val = Read-Host -AsSecureString -Prompt 'Deger'
                try { Set-PSCMSecret -Name $name -Value $val; Write-Host 'Kaydedildi.' -ForegroundColor Green }
                catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
                Pause-PSCM
            }
            '5' {
                Write-Host ''
                Get-PSSettings | Format-List | Out-String -Stream | ForEach-Object { Write-Host $_ }
                $edit = Read-Host 'Bir ayari manuel duzenlemek ister misiniz? [E/H]'
                if ($edit -match '^[EeYy]') {
                    $section = Read-Host 'Bolum'; $key = Read-Host 'Anahtar'; $value = Read-Host 'Deger'
                    try { Set-PSSettings -Section $section -Key $key -Value $value; Write-Host 'Guncellendi.' -ForegroundColor Green }
                    catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
                }
                Pause-PSCM
            }
            '0' { $run = $false }
        }
    }
}
