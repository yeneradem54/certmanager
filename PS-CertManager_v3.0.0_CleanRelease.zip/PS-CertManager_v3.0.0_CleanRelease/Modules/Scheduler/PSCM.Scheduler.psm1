﻿#Requires -Version 5.1
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'

$script:PSCMTaskName = 'PSCertManager-RenewalCycle'
$script:PSCMTaskFolder = '\PSCertManager\'
$script:PSCMQueueTaskName = 'PSCertManager-ActionQueue'

Get-ChildItem -Path (Join-Path $PSScriptRoot 'Public') -Filter '*.ps1' -EA SilentlyContinue | ForEach-Object { . $_.FullName }
Export-ModuleMember -Function @('Register-PSCMRenewalTask','Unregister-PSCMRenewalTask','Get-PSCMRenewalTask','Invoke-PSCMRenewalCycle')
