function New-PSCMSslPfx {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$CertPath,
        [Parameter(Mandatory=$true)][string]$KeyPath,
        [Parameter(Mandatory=$true)][string]$DestinationPfx,
        [Parameter(Mandatory=$true)][System.Security.SecureString]$PfxPass
    )
    if (-not (Test-Path $CertPath)) { throw "Sertifika bulunamadi: $CertPath" }
    if (-not (Test-Path $KeyPath)) { throw "Private Key bulunamadi: $KeyPath" }
    
    if (Get-Command openssl -ErrorAction SilentlyContinue) {
        Write-PSCMLog -Level INFO -Message "OpenSSL ile PFX olusturuluyor: $DestinationPfx" -Source 'SSLTools'
        $plainPass = (New-Object System.Management.Automation.PSCredential("x", $PfxPass)).GetNetworkCredential().Password
        $argsList = "pkcs12 -export -out `"$DestinationPfx`" -inkey `"$KeyPath`" -in `"$CertPath`" -passout pass:$plainPass"
        
        $p = Start-Process openssl -ArgumentList $argsList -Wait -NoNewWindow -PassThru
        if ($p.ExitCode -eq 0 -and (Test-Path $DestinationPfx)) {
            Write-PSCMLog -Level INFO -Message "PFX basariyla uretildi." -Source 'SSLTools'
            return $true
        }
        throw "openssl islem sirasinda hata dondurdu. (ExitCode: $($p.ExitCode))"
    } else {
        throw "PFX olusturma islemi (sertifika ve private key'i birlestirme) 'openssl' gerektirir. Lutfen sisteme OpenSSL kurun ve PATH'e ekleyin."
    }
}
