function Write-PSCMLog {
<#
.SYNOPSIS
    Merkezi log kaydi.
#>
    [CmdletBinding()]
    param(
        [ValidateSet('DEBUG','INFO','WARNING','ERROR')][string]$Level = 'INFO',
        [Parameter(Mandatory)][string]$Message,
        [string]$Source = 'PSCM',
        [switch]$NoConsole
    )
    try {
        # 1. Settings.json dynamic config reading
        $minLevel = 'INFO'
        $maxSizeMB = 10
        if (Get-Command Get-PSSettings -ErrorAction SilentlyContinue) {
            try {
                $settings = Get-PSSettings -Section 'Logging'
                if ($settings) {
                    if ($settings.MinimumLevel) { $minLevel = $settings.MinimumLevel }
                    if ($settings.MaxSizeMB) { $maxSizeMB = $settings.MaxSizeMB }
                }
            } catch {}
        }

        $priority = $script:PSCMLogConfig.LevelPriority[$Level]
        $minPri   = $script:PSCMLogConfig.LevelPriority[$minLevel]
        if ($priority -lt $minPri) { return }
        
        $ts      = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff')
        $safeMsg = $Message | ConvertTo-PSCMSafeString
        $line    = ('{0} [{1,-7}] [{2}] {3}' -f $ts,$Level,$Source,$safeMsg)
        
        $logDir  = Get-PSCMPath -Name Logs
        $logFile = Join-Path $logDir ('pscm-{0}.log' -f (Get-Date -Format 'yyyyMMdd'))
        
        # 2. Mutex based thread safety for rotation and file writing
        $mutexName = "Global\PSCM-Log-Write-Mutex"
        $createdNew = $false
        $mutex = New-Object System.Threading.Mutex($false, $mutexName, [ref]$createdNew)
        $hasHandle = $false
        try {
            $hasHandle = $mutex.WaitOne(5000) # Wait up to 5 seconds for lock
            
            # Log Rotation check inside lock
            if (Test-Path -LiteralPath $logFile) {
                $sz = (Get-Item -LiteralPath $logFile).Length / 1MB
                if ($sz -ge $maxSizeMB) {
                    Invoke-PSCMLogRotation -LogFile $logFile
                }
            }
            
            # Write to file inside lock (with a small retry loop just in case)
            $writeSuccess = $false
            for ($i = 0; $i -lt 5; $i++) {
                try {
                    Add-Content -LiteralPath $logFile -Value $line -Encoding UTF8 -ErrorAction Stop
                    $writeSuccess = $true
                    break
                } catch {
                    Start-Sleep -Milliseconds 100
                }
            }
        } finally {
            if ($hasHandle) {
                $mutex.ReleaseMutex()
            }
            $mutex.Dispose()
        }
        
        # 3. Windows Event Log integration (Bypassed if insufficient privileges)
        # Bypass flag auto-resets every hour so that if privileges are later fixed, logging resumes.
        if ($script:PSCMLogEventSourceFailed -and $script:PSCMLogEventSourceFailedAt) {
            if (((Get-Date) - $script:PSCMLogEventSourceFailedAt).TotalHours -ge 1) {
                $script:PSCMLogEventSourceFailed = $false
                $script:PSCMLogEventSourceFailedAt = $null
            }
        }
        if ($Level -in @('ERROR', 'WARNING') -and -not $script:PSCMLogEventSourceFailed) {
            try {
                if (-not [System.Diagnostics.EventLog]::SourceExists('PS-CertManager')) {
                    New-EventLog -LogName Application -Source 'PS-CertManager' -ErrorAction Stop
                }
                $entryType = if ($Level -eq 'ERROR') { 'Error' } else { 'Warning' }
                Write-EventLog -LogName Application -Source 'PS-CertManager' -EventId 1000 -EntryType $entryType -Message $Message -ErrorAction Stop
            } catch {
                $script:PSCMLogEventSourceFailed = $true
                $script:PSCMLogEventSourceFailedAt = Get-Date
                $evtErr = "EventLog yazilamadi (1 saat icinde tekrar denenecek): " + $_.Exception.Message
                $evtLine = ('{0} [{1,-7}] [{2}] {3}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'), 'WARNING', 'PSCM-Log', $evtErr)
                try { Add-Content -LiteralPath $logFile -Value $evtLine -Encoding UTF8 -ErrorAction SilentlyContinue } catch {}
            }
        }
        
        if ($script:PSCMLogConfig.ConsoleOutput -and -not $NoConsole) {
            switch ($Level) {
                'DEBUG'   { Write-Verbose $line }
                'INFO'    { Write-Host $line -ForegroundColor Gray }
                'WARNING' { Write-Host $line -ForegroundColor Yellow }
                'ERROR'   { Write-Host $line -ForegroundColor Red }
            }
        }
    } catch {
        Write-Host ('LOG YAZIM HATASI: ' + $_.Exception.Message) -ForegroundColor Red
    }
}
