function Invoke-MenuNewCertificate {
    Show-PSCMBanner
    Write-Host '  --- YENI SERTIFIKA SIHIRBAZI ---' -ForegroundColor Yellow
    Write-Host ''
    $defaults = $null
    try { $defaults = Get-PSSettings -Section 'Defaults' -ErrorAction Stop } catch { }

    Write-Host '  --- SERTIFIKA SAGLAYICISI (PROVIDER) ---' -ForegroundColor Cyan
    $providers = Get-PSCMAcmeProviders
    for ($i = 0; $i -lt $providers.Count; $i++) {
        Write-Host "  [$($i+1)] ACME - $($providers[$i].DisplayName)" -ForegroundColor White
    }
    $localCaIdx = $providers.Count + 1
    Write-Host "  [$localCaIdx] Local CA - Windows ADCS (Ic Ag / Yerel CA)" -ForegroundColor White
    Write-Host ''
    Write-Host '  Enter) Ana Menuye Don' -ForegroundColor DarkGray
    Write-Host ''
    $provIn = Read-Host 'Secim'
    if (-not $provIn) { return }
    
    $provider = 'ACME'
    $acmeProvider = $null
    
    if ([int]::TryParse($provIn, [ref]$idx)) {
        if ($idx -gt 0 -and $idx -le $providers.Count) {
            $provider = 'ACME'
            $acmeProvider = $providers[$idx - 1].Name
        }
        elseif ($idx -eq $localCaIdx) {
            $provider = 'LocalCA'
        }
        else {
            return
        }
    } else {
        return
    }
    
    $templateName = if ($defaults -and $defaults.PSObject.Properties.Name -contains 'TemplateName' -and $defaults.TemplateName) { $defaults.TemplateName } else { 'WebServer' }
    if ($provider -eq 'LocalCA') {
        Write-Host ''
        $tmpIn = Read-Host "Windows CA Sablon Adi (Template) [Varsayilan: $templateName]"
        if ($tmpIn) { $templateName = $tmpIn.Trim() }
    }
    
    Write-Host ''
    Write-Host 'Sertifika Yontemi:'
    Write-Host '  1) Sifirdan Olustur (Otomatik Private Key uretilir)'
    Write-Host '  2) Mevcut CSR Dosyasi Kullan (Sadece .cer alinir, otomatik deploy yapilamaz)'
    Write-Host ''
    $methodIn = Read-Host 'Secim (Varsayilan: 1)'
    $csrPath = $null
    if ($methodIn -eq '2') {
        $csrPath = Read-Host 'CSR Dosyasi Yolu (Ornek: C:\Temp\req.csr)'
        if ($csrPath) {
            $csrPath = $csrPath.Trim("`"").Trim("'")
        }
        if (-not (Test-Path $csrPath)) {
            Write-Host 'Hata: Belirtilen CSR dosyasi bulunamadi!' -ForegroundColor Red
            Pause-PSCM
            return
        }
    }
    
    Write-Host ''
    $wildcardIn = Read-Host 'Wildcard mi? [E/H]'
    $wildcard = ($wildcardIn -match '^[EeYy]')
    $domain = Read-Host 'Domain (Ornek: app.sirket.local)'
    
    $sanList = @()
    $sans = Read-Host 'Ek SAN listesi (DNS adlari veya IP adresleri, virgulle ayirin, yoksa bos birakin)'
    if ($sans) { $sanList = @($sans -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' }) }
    
    $friendly = Read-Host 'Friendly Name (bos birakabilirsiniz)'
    
    $pfxPass = $null
    if (-not $csrPath) {
        Write-Host 'PFX icin parola girin (Bos birakilirsa sistemdeki varsayilan parola kullanilir):'
        $pfxPass = Read-Host -AsSecureString
        if ($pfxPass -and $pfxPass.Length -eq 0) { $pfxPass = $null }
    }
    
    try {
        $pArgs = @{ Domain = $domain; Provider = $provider }
        if ($acmeProvider) { $pArgs['AcmeProvider'] = $acmeProvider }
        if ($pfxPass) { $pArgs['PfxPass'] = $pfxPass }
        if ($csrPath) { $pArgs['CsrPath'] = $csrPath }
        if ($provider -eq 'LocalCA') { $pArgs['TemplateName'] = $templateName }
        if ($wildcard) { $pArgs['Wildcard'] = $true }
        if ($friendly) { $pArgs['FriendlyName'] = $friendly }
        if ($sanList.Count -gt 0) { $pArgs['SANList'] = $sanList }
        New-PSCertificate @pArgs
        Write-Host 'Sertifika basariyla alindi.' -ForegroundColor Green
    } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
    Pause-PSCM
}
