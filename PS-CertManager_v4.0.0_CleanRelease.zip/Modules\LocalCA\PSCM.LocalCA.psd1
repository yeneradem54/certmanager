@{
    RootModule = 'PSCM.LocalCA.psm1'
    ModuleVersion = '4.0.0'
    GUID = '661bdb17-7ca6-45ea-8809-1be42db009a1'
    Author = 'PS-CertManager Ekibi'
    CompanyName = 'PS-CertManager'
    Copyright = '(c) 2026 PS-CertManager. Tum haklari saklidir.'
    Description = 'Local CA (Windows ADCS) Provider'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Invoke-PSCMLocalCACertificateRequest','Repair-PSCMLocalCAPermissions')
    CmdletsToExport = @()
    VariablesToExport = @()
    AliasesToExport = @()
}
