function Invoke-MenuLogs {
    Show-PSCMBanner
    Write-Host '  --- SISTEM LOGLARI ---' -ForegroundColor Yellow
    Write-Host ''
    $level = Read-Host 'Seviye (DEBUG/INFO/WARNING/ERROR/ALL) [ALL]'
    if (-not $level) { $level = 'ALL' }
    $lastIn = Read-Host 'Son kac satir? [50]'
    $last = 50
    if ($lastIn) { [int]::TryParse($lastIn,[ref]$last) | Out-Null }
    Get-PSLog -Level $level -Last $last -Days 3 | ForEach-Object { Write-Host $_ }
    Pause-PSCM
}
