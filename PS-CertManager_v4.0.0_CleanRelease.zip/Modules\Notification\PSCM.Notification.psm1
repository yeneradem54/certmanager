#Requires -Version 5.1
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'
Get-ChildItem -Path (Join-Path $PSScriptRoot 'Public') -Filter '*.ps1' -EA SilentlyContinue | ForEach-Object { . $_.FullName }
Export-ModuleMember -Function @('Send-PSCMMailNotification','Send-PSCMTeamsNotification','Send-PSCMSlackNotification','Send-PSCMDiscordNotification')
