﻿function Start-PSCMConfigWizard {
<#
.SYNOPSIS
Azure baglanti ve ACME bilgilerini adim adim yapilandirir.
#>
    [CmdletBinding()]
    param()
    Write-Host ''
    Write-Host '============================================================' -ForegroundColor Cyan
    Write-Host '  PS-CertManager - Azure Kurulum Sihirbazi' -ForegroundColor Cyan
    Write-Host '============================================================' -ForegroundColor Cyan
    Write-Host ''
    Write-Host 'Bos gecerseniz mevcut deger korunur.' -ForegroundColor DarkGray
    Write-Host ''
    try { Initialize-PSCMSettings | Out-Null } catch {}
    $current = Get-PSSettings

    Write-Host '--- 1) Azure Baglanti Bilgileri ---' -ForegroundColor Yellow
    $curTenant = if ($current.Azure.TenantId) { $current.Azure.TenantId } else { '(bos)' }
    Write-Host ('  Mevcut Tenant ID       : ' + $curTenant) -ForegroundColor DarkGray
    $tenant = Read-Host '  Yeni Tenant ID'
    if ($tenant) { Set-PSSettings -Section Azure -Key TenantId -Value $tenant }

    $curSub = if ($current.Azure.SubscriptionId) { $current.Azure.SubscriptionId } else { '(bos)' }
    Write-Host ('  Mevcut Subscription ID : ' + $curSub) -ForegroundColor DarkGray
    $sub = Read-Host '  Yeni Subscription ID'
    if ($sub) { Set-PSSettings -Section Azure -Key SubscriptionId -Value $sub }

    $curRg = if ($current.Azure.ResourceGroup) { $current.Azure.ResourceGroup } else { '(bos)' }
    Write-Host ('  Mevcut Resource Group  : ' + $curRg) -ForegroundColor DarkGray
    $rg = Read-Host '  DNS Zone hangi Resource Group icinde'
    if ($rg) { Set-PSSettings -Section Azure -Key ResourceGroup -Value $rg }

    $curZone = if ($current.Azure.DnsZone) { $current.Azure.DnsZone } else { '(bos)' }
    Write-Host ('  Mevcut DNS Zone        : ' + $curZone) -ForegroundColor DarkGray
    $zone = Read-Host '  DNS Zone adi (ornek: ornek.com)'
    if ($zone) { Set-PSSettings -Section Azure -Key DnsZone -Value $zone }

    Write-Host ''
    Write-Host '--- 2) Kimlik Dogrulama Modu ---' -ForegroundColor Yellow
    Write-Host '  1) Interactive       (tarayici ile giris)'
    Write-Host '  2) ServicePrincipal  (uygulama kimligi + secret)'
    Write-Host '  3) ManagedIdentity   (Azure VM icinde)'
    $curMode = if ($current.Azure.AuthMode) { $current.Azure.AuthMode } else { 'Interactive' }
    Write-Host ('  Mevcut mod: ' + $curMode) -ForegroundColor DarkGray
    $modeIn = Read-Host '  Secim [1/2/3] (Enter = degistirme)'
    $mode = $curMode
    switch ($modeIn) {
        '1' { $mode = 'Interactive' }
        '2' { $mode = 'ServicePrincipal' }
        '3' { $mode = 'ManagedIdentity' }
    }
    Set-PSSettings -Section Azure -Key AuthMode -Value $mode

    if ($mode -eq 'ServicePrincipal') {
        Write-Host ''
        Write-Host '--- 3) Service Principal Kimligi ---' -ForegroundColor Yellow
        $curClientId = if ($current.Azure.ClientId) { $current.Azure.ClientId } else { '(bos)' }
        Write-Host ('  Mevcut ClientId: ' + $curClientId) -ForegroundColor DarkGray
        $clientId = Read-Host '  Application (Client) ID'
        if ($clientId) { Set-PSSettings -Section Azure -Key ClientId -Value $clientId }

        Write-Host '  Client Secret SecretStore icinde saklanacak.' -ForegroundColor DarkGray
        $secret = Read-Host '  Client Secret' -AsSecureString
        if ($secret -and $secret.Length -gt 0) {
            try {
                Initialize-PSCMSecretStore -AllowClobber | Out-Null
                Set-PSCMSecret -Name 'Azure.ClientSecret' -Value $secret
                Write-Host '  [OK] Client Secret kaydedildi.' -ForegroundColor Green
            } catch {
                Write-Host ('  [HATA] SecretStore: ' + $_.Exception.Message) -ForegroundColor Red
            }
        }
    }

    Write-Host ''
    Write-Host '--- 4) ACME Hesap E-Postasi ---' -ForegroundColor Yellow
    $curEmail = if ($current.Acme.AccountEmail) { $current.Acme.AccountEmail } else { '(bos)' }
    Write-Host ('  Mevcut e-posta: ' + $curEmail) -ForegroundColor DarkGray
    $email = Read-Host '  E-posta'
    if ($email) { Set-PSSettings -Section Acme -Key AccountEmail -Value $email }

    Write-Host ''
    Write-Host '--- 5) Baglanti Testi ---' -ForegroundColor Yellow
    $doTest = Read-Host 'Azure baglantisi test edilsin mi? [E/H]'
    if ($doTest -match '^[EeYy]') {
        try {
            $test = Test-PSAzure
            if ($test.Durum) { Write-Host ('  [OK] ' + $test.Aciklama) -ForegroundColor Green }
            else { Write-Host ('  [UYARI] ' + $test.Aciklama) -ForegroundColor Yellow }
        } catch {
            Write-Host ('  [HATA] ' + $_.Exception.Message) -ForegroundColor Red
        }
    }
    Write-Host ''
    Write-Host 'Sihirbaz tamamlandi. Ana menuden 4) Yeni Sertifika secebilirsiniz.' -ForegroundColor Green
}
