﻿#Requires -Version 5.1
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'

function Get-PSCMActionRoot {
    $root = Join-Path (Get-PSCMPath -Name State) 'actions'
    foreach ($sub in @('pending','processed','failed')) {
        $p = Join-Path $root $sub
        if (-not (Test-Path -LiteralPath $p)) {
            New-Item -ItemType Directory -Path $p -Force | Out-Null
        }
    }
    return $root
}

Get-ChildItem -Path (Join-Path $PSScriptRoot 'Public') -Filter '*.ps1' -EA SilentlyContinue | ForEach-Object { . $_.FullName }
Export-ModuleMember -Function @('Add-PSCMAction','Get-PSCMActionQueue','Invoke-PSCMActionQueue','Clear-PSCMActionQueue','Import-PSCMActionFile')
