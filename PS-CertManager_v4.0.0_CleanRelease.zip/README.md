# PS-CertManager v4.0.0

**Enterprise Class Automated Certificate Management Framework**

PS-CertManager, karmaşık web altyapıları için tasarlanmış, modüler yapısı sayesinde sınırsız genişletilebilir, Uçtan Uca (E2E) test edilen ve çoklu sağlayıcı mimarisine sahip kurumsal bir SSL/TLS Sertifika Yönetim otomasyonudur. 

v4.0.0 sürümü ile birlikte, sistem artık sadece basit bir IIS sertifika kurucusu olmaktan çıkmış, **Nginx / Apache / IIS** ortamları için Multi-CA (Çoklu Sertifika Otoritesi) ve Multi-DNS destekli bir altyapıya dönüşmüştür.

---

## 🌟 Öne Çıkan v4 Özellikleri

* **Gelişmiş Web UI Dashboard (v2.0)**: CLI bağımlılığının ötesinde, tarayıcı üzerinden 5 ayrı pano (Dashboard, Sertifikalar, İşlem Kuyruğu, Sistem/Loglar, Canlı Ayarlar) sunan, glassmorphism tasarımlı, süre grafikli ve auto-refresh özellikli Single Page Application (SPA) arayüzü.
* **Yeni Sertifika Sihirbazı (Redesigned)**: Baştan tasarlanan sertifika modalı sayesinde artık hem **✏️ Form Doldurarak** hem de **📂 Hazır CSR Yükleyerek** yerel (**LocalCA**) veya genel (**ACME - Let's Encrypt**) otoritelerden sertifika üretebilirsiniz.
* **CSR'dan Otomatik Alan Adı Çıkarma**: Hazır CSR dosyası yüklenerek yapılan üretimlerde domain/alan adı girilmesine gerek yoktur; sistem `certutil` yardımıyla CSR içerisindeki Common Name (CN) bilgisini otomatik ayıklar ve sertifikayı bu isimle üretir.
* **Modern Windows Native Dialog Entegrasyonu**: Web arayüzünde dosya/klasör seçme butonları tarayıcı kısıtlamalarını aşarak arka planda çalışan PowerShell STA thread'i üzerinden doğrudan Windows API (user32.dll) ile haberleşir. `SetForegroundWindow` ve `SetWindowPos` aracılığıyla pencerenin arkada kalması önlenmiş, modern `SaveFileDialog`/`OpenFileDialog` ve IFileOpenDialog COM klasör seçicileri entegre edilmiştir.
* **Çoklu CA (Certificate Authority) Desteği**: Sadece Let's Encrypt ile sınırlı kalmayın. İhtiyacınıza göre tek tuşla **ZeroSSL** veya **ADCS (LocalCA)** sağlayıcılarına geçiş yapın. Let's Encrypt Staging/Production ortamları arasında hızlı geçiş imkanı.
* **Kapsamlı DNS Otomasyonu**: Wildcard sertifikalar için zorunlu olan DNS doğrulama adımları; **Azure DNS**, **Cloudflare**, **AWS Route53** ve **GoDaddy** API'leri ile tam entegredir.
* **Genişletilmiş Platform Desteği (Cross-Platform Ready)**:
  - Windows IIS bağlamaları (Bindings) için otomatik PFX kurulumları.
  - Linux sunucular (Nginx/Apache) için PFX dosyalarından şifresiz `Fullchain (.pem)` ve `Private Key (.key)` dosyalarının **OpenSSL** ile otomatik olarak çıkartılması.
  - Sistemde OpenSSL yoksa, `winget` üzerinden otomatik kurulum asistanı.
* **Gelişmiş Bildirim Ağı (Notifications)**: Kritik sertifika yenileme başarı/hata bildirimleri sadece E-Posta (SMTP) ile değil; modern ekipler için **Slack** ve **Discord** web kancaları (Webhook) ile anlık iletilir.
* **Birim Test (Unit Test) Güvencesi**: Projenin sağlığını korumak adına StrictMode tabanlı **78 adet Pester testi** entegre edilmiş, tüm işlemler modüler uyumluluk testlerinden geçirilmiştir.

---

## 🏗️ Mimari ve Modül Yapısı

PS-CertManager, 19 bağımsız modül üzerine inşa edilmiş, `SOLID` prensiplerine sadık bir mimari sunar:

- `Modules\PSCertManager`: Ana kontrolcü (Master) modül.
- `Modules\ACME`: Let's Encrypt, ZeroSSL vb. ACME protokolü ile sertifika alma işlerini yürütür.
- `Modules\AzureDNS` / Diğer Pluginler: DNS-01 Challenge için DNS kayıtlarının API'ler üzerinden yönetimini sağlar.
- `Modules\Certificate`: Alınan sertifikaların şifreleme/çözme, geçerlilik tarihi okuma gibi temel objelerini yönetir.
- `Modules\Deployment`: Üretilen sertifikanın IIS, WebStore gibi hedef noktalara otomatik aktarımını sağlar.
- `Modules\Notification`: Slack, Discord ve SMTP uyarı motorudur.
- `Modules\Scheduler`: Belirlenen zaman (Threshold) aralıklarında süresi dolan sertifikaları bulur ve arka planda yenileme döngüsünü tetikler.
- `Modules\SSLTools`: OpenSSL entegrasyonu sayesinde Cross-Platform Web sunucuları için PFX->PEM dönüşümü yapar.
- `Modules\WebServer`: Dahili HTTP Listener ile canlı REST API ve Web UI Dashboard sunar.
- `Modules\CLI`: Etkileşimli konsol menülerini (UI) yönetir.

---

## 🚀 Başlarken (Kurulum)

Projeyi test etmek veya canlı sisteminizde (Production) kullanmak oldukça basittir.

1. Projeyi sisteminize indirin.
2. Konsolu **Yönetici (Administrator)** olarak açın (Sertifika Store izinleri için gereklidir).
3. Ana dizindeki `Manager-Start.ps1` dosyasını çalıştırın.
4. İlk açılışta gerekli `Settings.json` ve klasör yapısı (Current, Archive, State, Logs) sistem tarafından otomatik olarak inşa edilir.

**Bakım & Sorun Giderme:**
CLI arayüzündeki **Bakım ve Loglar** menüsünden sisteminizdeki eksik bağımlılıkları (Örn: OpenSSL) tek tıkla kurabilir, `Pester` altyapısı ile manifest ve mimari testlerini anında çalıştırabilirsiniz.
