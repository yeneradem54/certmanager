﻿@{
    RootModule = 'PSCM.Notification.psm1'
    ModuleVersion = '2.1.0'
    GUID = '99999999-9999-9999-9999-999999999999'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager Bildirim Modulu (SMTP + Teams)'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Send-PSCMMailNotification','Send-PSCMTeamsNotification')
}
