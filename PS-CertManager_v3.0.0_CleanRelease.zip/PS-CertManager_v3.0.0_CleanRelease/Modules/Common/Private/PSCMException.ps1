﻿class PSCMException : System.Exception {
    [string]$Category
    [string]$ErrorCode
    PSCMException([string]$m) : base($m) { $this.Category = 'Genel'; $this.ErrorCode = 'PSCM-0000' }
    PSCMException([string]$m,[string]$c,[string]$e) : base($m) { $this.Category = $c; $this.ErrorCode = $e }
    PSCMException([string]$m,[System.Exception]$i) : base($m,$i) { $this.Category = 'Genel'; $this.ErrorCode = 'PSCM-0000' }
}
class PSCMAcmeException : PSCMException { PSCMAcmeException([string]$m) : base($m,'ACME','PSCM-1000') {} }
class PSCMAzureException : PSCMException { PSCMAzureException([string]$m) : base($m,'Azure','PSCM-2000') {} }
class PSCMConfigException : PSCMException { PSCMConfigException([string]$m) : base($m,'Yapilandirma','PSCM-3000') {} }
class PSCMValidationException : PSCMException { PSCMValidationException([string]$m) : base($m,'Dogrulama','PSCM-4000') {} }
class PSCMSecurityException : PSCMException { PSCMSecurityException([string]$m) : base($m,'Guvenlik','PSCM-5000') {} }
