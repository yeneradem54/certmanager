#Requires -Modules Pester
<#
.SYNOPSIS
    Settings Modul Birim Testleri
#>

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$env:PSCM_ROOT = $ProjectRoot
$commonManifest = Join-Path $ProjectRoot 'Modules\Common\PSCM.Common.psd1'
Import-Module $commonManifest -Force -DisableNameChecking -ErrorAction Stop

$settingsManifest = Join-Path $ProjectRoot 'Modules\Settings\PSCM.Settings.psd1'
Import-Module $settingsManifest -Force -DisableNameChecking -ErrorAction Stop

Describe 'Get-PSSettings' {
    It 'Settings nesnesi dondurmeli' {
        $s = Get-PSSettings
        $s | Should -Not -BeNullOrEmpty
    }
    
    It 'Version ozelligi olmali' {
        $s = Get-PSSettings
        $s.Version | Should -Not -BeNullOrEmpty
    }
}

Remove-Module PSCM.Settings -Force -ErrorAction SilentlyContinue
Remove-Module PSCM.Common -Force -ErrorAction SilentlyContinue
