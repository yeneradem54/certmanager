function Sync-PSCMCertificateCache {
<#
.SYNOPSIS
Certificates\Current klasorundeki sertifikalari SQLite veritabanina (pscm.db) senkronize eder.
.DESCRIPTION
Baska sunucudan veya elle Current klasorune kopyalanan sertifikalarin metadata.json
veya cert.cer dosyalarindan bilgileri okuyup State veritabanina kaydeder.
#>
    [CmdletBinding()]
    param()

    $currentPath = Get-PSCMPath -Name Current
    if (-not (Test-Path $currentPath)) {
        Write-Host "Certificates\Current klasoru bulunamadi." -ForegroundColor Red
        return
    }

    $dirs = Get-ChildItem -Path $currentPath -Directory -ErrorAction SilentlyContinue
    if (-not $dirs -or $dirs.Count -eq 0) {
        Write-Host "Current klasorunde taranacak sertifika klasoru bulunamadi." -ForegroundColor DarkGray
        return
    }

    $added = 0
    $existingCerts = @(Get-PSCMState -Table 'certificates')

    foreach ($d in $dirs) {
        $metaPath = Join-Path $d.FullName 'metadata.json'
        $cerPath = Join-Path $d.FullName 'cert.cer'

        $meta = $null
        if (Test-Path $metaPath) {
            try { $meta = Read-PSCMJson -Path $metaPath } catch { }
        }

        if (-not $meta -and (Test-Path $cerPath)) {
            # metadata.json yoksa cert.cer uzerinden olustur
            try {
                $x509 = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($cerPath)
                $dom = $d.Name -replace '^wildcard_', '*.'
                $meta = [PSCustomObject]@{
                    Domain       = $dom
                    Wildcard     = ($dom.StartsWith('*.'))
                    Issuer       = $x509.Issuer
                    Thumbprint   = $x509.Thumbprint
                    NotBefore    = $x509.NotBefore.ToString('o')
                    NotAfter     = $x509.NotAfter.ToString('o')
                    FriendlyName = $dom
                    Path         = $d.FullName
                    SourceFolder = $d.FullName
                    CreatedAt    = (Get-Date).ToString('o')
                    Provider     = 'Manual'
                }
                $meta | Write-PSCMJson -Path $metaPath
            } catch { }
        }

        if ($meta -and $meta.Domain) {
            $dom = $meta.Domain
            # Eger zaten veritabaninda ayni domain varsa cikarip yenisini ekle
            $existingCerts = @($existingCerts | Where-Object { $_.Domain -ne $dom })
            $existingCerts += $meta
            $added++
            Write-Host "  [+] Senkronize edildi: $dom" -ForegroundColor Green
        }
    }

    if ($added -gt 0) {
        Set-PSCMState -Table 'certificates' -Data $existingCerts
        Write-Host "`nToplam $added adet sertifika SQLite veritabanina basariyla aktarildi!" -ForegroundColor Cyan
    } else {
        Write-Host "Yeni aktarilacak sertifika bulunamadi." -ForegroundColor DarkGray
    }
}
