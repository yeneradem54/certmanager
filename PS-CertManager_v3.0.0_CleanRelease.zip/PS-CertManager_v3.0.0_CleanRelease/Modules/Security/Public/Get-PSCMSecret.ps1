﻿function Get-PSCMSecret {
<#
.SYNOPSIS
Vault'tan secret getirir.
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Name,
        [switch]$AsPlainText
    )
    try {
        if ($AsPlainText) { return (Get-Secret -Name $Name -Vault $script:PSCMVaultName -AsPlainText) }
        return (Get-Secret -Name $Name -Vault $script:PSCMVaultName)
    } catch {
        Write-PSCMLog -Level WARNING -Message ('Secret bulunamadi: ' + $Name) -Source 'Security'
        return $null
    }
}
