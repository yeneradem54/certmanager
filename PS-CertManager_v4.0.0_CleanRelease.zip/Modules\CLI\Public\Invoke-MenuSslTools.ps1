function Invoke-MenuSslTools {
    $run = $true
    while ($run) {
        Show-PSCMBanner
        Write-Host '  --- SSL ARACLAR (TOOLBOX) ---' -ForegroundColor Yellow
        Write-Host ''
        Write-Host '  [1] CSR Dosyasi Bilgilerini Gor' -ForegroundColor White
        Write-Host '  [2] PEM/CER Sertifika Bilgilerini Gor' -ForegroundColor White
        Write-Host '  [3] Sertifika ve Private Key''i PFX Yap (.cer + .key = .pfx)' -ForegroundColor White
        Write-Host '  [4] PFX Icerisinden Private Key (.key) ve Sertifika (.cer) Cikar' -ForegroundColor White
        Write-Host '  [5] PFX Dosyasini Java Keystore (.keystore) Formatina Cevir' -ForegroundColor White
        Write-Host ''
        Write-Host '  Enter) Ana Menuye Don' -ForegroundColor DarkGray
        Write-Host ''
        
        $choice = Read-Host 'Secim'
        switch ($choice) {
            '1' {
                $path = Read-Host 'CSR Dosyasi Yolu (Ornek: C:\Temp\req.csr)'
                if ($path) {
                    $path = $path.Trim("`"").Trim("'")
                    try {
                        $info = Get-PSCMSslCsrInfo -CsrPath $path
                        Write-Host ''
                        Write-Host $info -ForegroundColor Cyan
                    } catch { Write-Host "Hata: $($_.Exception.Message)" -ForegroundColor Red }
                }
                Pause-PSCM
            }
            '2' {
                $path = Read-Host 'Sertifika Yolu (Ornek: C:\Temp\cert.pem)'
                if ($path) {
                    $path = $path.Trim("`"").Trim("'")
                    try {
                        $info = Get-PSCMSslCertInfo -CertPath $path
                        Write-Host ''
                        $info | Format-List | Out-String | Write-Host -ForegroundColor Cyan
                    } catch { Write-Host "Hata: $($_.Exception.Message)" -ForegroundColor Red }
                }
                Pause-PSCM
            }
            '3' {
                $cert = Read-Host 'Sertifika (.cer/.pem) Yolu'
                $key = Read-Host 'Private Key (.key) Yolu'
                $dest = Read-Host 'Olusturulacak PFX Yolu (Ornek: C:\Temp\yeni.pfx)'
                Write-Host 'Yeni PFX icin parola belirleyin:'
                $pass = Read-Host -AsSecureString
                if ($cert -and $key -and $dest -and $pass) {
                    $cert = $cert.Trim("`"").Trim("'")
                    $key = $key.Trim("`"").Trim("'")
                    $dest = $dest.Trim("`"").Trim("'")
                    try {
                        New-PSCMSslPfx -CertPath $cert -KeyPath $key -DestinationPfx $dest -PfxPass $pass
                    } catch { Write-Host "Hata: $($_.Exception.Message)" -ForegroundColor Red }
                }
                Pause-PSCM
            }
            '4' {
                $pfx = Read-Host 'PFX Dosyasi Yolu (Ornek: C:\Temp\eski.pfx)'
                Write-Host 'PFX Parolasi:'
                $pass = Read-Host -AsSecureString
                $folder = Read-Host 'Cikarilacak Klasor Yolu (Ornek: C:\Temp\Cikti)'
                if ($pfx -and $pass -and $folder) {
                    $pfx = $pfx.Trim("`"").Trim("'")
                    $folder = $folder.Trim("`"").Trim("'")
                    try {
                        $res = Export-PSCMSslPrivateKey -PfxPath $pfx -PfxPass $pass -OutFolder $folder
                        Write-Host "Islem basarili! Dosyalar $folder klasorune kaydedildi." -ForegroundColor Green
                    } catch { Write-Host "Hata: $($_.Exception.Message)" -ForegroundColor Red }
                }
                Pause-PSCM
            }
            '5' {
                $pfx = Read-Host 'PFX Dosyasi Yolu (Ornek: C:\Temp\eski.pfx)'
                $dest = Read-Host 'Olusturulacak Keystore Yolu (Ornek: C:\Temp\app.keystore)'
                if ($pfx -and $dest) {
                    $pfx = $pfx.Trim("`"").Trim("'")
                    $dest = $dest.Trim("`"").Trim("'")
                    try {
                        Export-PSCMSslKeystore -PfxPath $pfx -DestinationJks $dest | Out-Null
                    } catch { Write-Host "Hata: $($_.Exception.Message)" -ForegroundColor Red }
                }
                Pause-PSCM
            }
            ''  { $run = $false }
        }
    }
}
