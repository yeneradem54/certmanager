# PS-CertManager — Sıfırdan Üretim Promptu

> Bu belge, PS-CertManager projesini sıfırdan yeniden oluşturmak için
> başka bir yapay zekaya (AI) verilebilecek en kapsamlı prompttur.

---

## PROMPT BAŞLANGICI

Aşağıdaki özelliklere sahip, **PowerShell 5.1+ / 7.x uyumlu**, Windows ortamında çalışan, kurumsal düzeyde bir **SSL/TLS Sertifika Yaşam Döngüsü Yönetim Otomasyonu** oluştur. Projenin adı **PS-CertManager**.

---

### 1. GENEL MİMARİ VE TASARIM İLKELERİ

- **Dil:** Tamamı PowerShell (`.ps1`, `.psm1`, `.psd1`). Web UI için HTML + CSS + Vanilla JavaScript.
- **Uyumluluk:** `CompatiblePSEditions = @('Desktop','Core')`. `Set-StrictMode -Version 3.0` ve `$ErrorActionPreference = 'Stop'` her modülde zorunlu.
- **Modüler Yapı:** Proje 19 bağımsız PowerShell modülüne ayrılmalıdır. Her modül kendi `PSCM.<Isim>.psd1` (manifest) ve `PSCM.<Isim>.psm1` (script module) dosyasına sahip olmalıdır.
- **Fonksiyon Organizasyonu:** Her modül `Public/` ve opsiyonel `Private/` alt dizinlerine sahiptir. `.psm1` dosyası, `Public/*.ps1` dosyalarını dot-source eder ve `Export-ModuleMember` ile dışa aktarır. Her public fonksiyon ayrı bir `.ps1` dosyasında olmalıdır.
- **Ana Konteyner Modül:** `PSCertManager` adında bir master modül, diğer 18 modülü `NestedModules` olarak birleştirmeli ve tüm fonksiyonları tek bir `Import-Module PSCertManager` komutuyla erişilebilir kılmalıdır.
- **Giriş Noktası:** `Manager-Start.ps1` dosyası Administrator kontrolü yapmalı, gerekirse kendini yükseltilmiş olarak yeniden başlatmalı, modülü yüklemeli, ilk çalıştırma kontrolü yapmalı ve CLI menüsünü başlatmalıdır.

---

### 2. 19 MODÜL DETAYLI TANIM

#### 2.1. Common (Çekirdek)
- Projenin kök dizinini dinamik çözümleyen `Get-PSCMRootPath` fonksiyonu.
- Alt dizin yollarını çözümleyen `Get-PSCMPath` (Config, Logs, Temp, Certificates/Current, Certificates/Archive).
- JSON okuma/yazma (`Read-PSCMJson`, `Write-PSCMJson`) — UTF-8 encoding zorunlu.
- Administrator kontrolü (`Test-PSCMAdmin`).
- Global Mutex tabanlı kaynak kilitleme (`Lock-PSCMResource`, `Unlock-PSCMResource`).
- Dosya adı güvenli string dönüşümü (`ConvertTo-PSCMSafeString`).
- Standart hata nesnesi üretimi (`New-PSCMException` — kategori + hata kodu).
- **SQLite veri katmanı:** `PSSQLite` modülünü kullanarak sertifika ve deployment durumlarını SQLite veritabanında saklayan `Get-PSCMState` / `Set-PSCMState` fonksiyonları. Eski `certificates.json` formatından otomatik migrasyon yapan `Initialize-PSCMSQLite`.
- Hata dayanıklılık çerçevesi: `Invoke-PSCMReliableAction` — configurable retry count ve exponential backoff ile ScriptBlock çalıştırma.

#### 2.2. Settings (Yapılandırma)
- `Config/settings.json` dosyasını okuyan `Get-PSSettings` (bölüm bazlı veya tümü).
- Ayar yazan `Set-PSSettings` (Section + Key + Value). **GÜVENLİK:** `Password`, `Secret`, `ApiKey`, `ClientSecret` gibi hassas alanları JSON'a yazmayı engellemeli, bunları SecretStore'a yönlendirmeli.
- İlk çalıştırmada varsayılan şablonu oluşturan `Initialize-PSCMSettings`.

#### 2.3. Logging (Loglama)
- `Write-PSCMLog` — Level (DEBUG/INFO/WARN/ERROR), Message, Source parametreleri. **Thread-safe:** `System.Threading.Mutex` (`Global\PSCM-Log-Write-Mutex`) kullanarak paralel job'lardan güvenli dosya yazımı. Konsola renkli çıktı, opsiyonel Windows Event Log.
- `Get-PSLog` — Log dosyasından kayıtları seviye ve satır sayısı filtreleriyle oku.
- `Invoke-PSCMLogRotation` — Boyut (MB) ve yaş (gün) bazında log döndürme.

#### 2.4. Security (Güvenlik Kasası)
- `Microsoft.PowerShell.SecretManagement` ve `Microsoft.PowerShell.SecretStore` modüllerini kullanan vault yönetimi.
- `Initialize-PSCMSecretStore` — Vault yoksa oluşturur, politikayı ayarlar.
- `Set-PSCMSecret` / `Get-PSCMSecret` / `Remove-PSCMSecret` — CRUD operasyonları. Girdi olarak `SecureString` kabul etmeli.
- `Unlock-PSCMSecretStore` — Kasa kilidini açma.
- `Set-PSCMSecretStorePolicy` — Politikayı Session/None/Strict olarak değiştirme.

#### 2.5. Bootstrap (İlk Kurulum)
- `Initialize-PSCertManager` — Tüm dizinleri ve SQLite DB'yi oluşturur.
- `Get-PSInfrastructure` — Modüller, bağımlılıklar, dizin yapısı için detaylı sağlık raporu.
- `Repair-PSInfrastructure` — Eksik bağımlılıkları otomatik kurar.
- `Start-PSCMConfigWizard` — İnteraktif ilk yapılandırma sihirbazı.

#### 2.6. ACME (Sertifika Otoritesi)
- **Dinamik Sağlayıcı Kaydı (Kritik Tasarım):** `Get-PSCMAcmeProviders` fonksiyonu, desteklenen tüm CA'ları (Name, DisplayName, DirectoryUrl, RequireEAB) bir dizi olarak döndürür. Bu, tüm CLI menüleri ve Web UI'nin tek veri kaynağıdır. Yeni CA eklemek için yalnızca bu listeye bir satır eklenmesi yeterli olmalıdır.
- `Initialize-PSCMAcmeProvider` — Sağlayıcı adını `Get-PSCMAcmeProviders` listesinden çözümleyerek `PSCMPoshAcmeProvider` nesnesi oluşturan fabrika fonksiyonu.
- `New-PSCMAcmeCertificate` / `Update-PSCMAcmeCertificate` — Posh-ACME wrapper'ları.
- `Private/PSCMAcmeContract.ps1` — `PSCMPoshAcmeProvider` PowerShell class'ı. Register (EAB destekli) ve Order metotları. EAB anahtarları SecretStore'dan `Acme.EabKeyId.<ProviderName>` formatında dinamik çekilir.

#### 2.7. Certificate (Sertifika Yaşam Döngüsü)
- `Get-PSCertificate` — SQLite'dan sertifika kayıtlarını sorgular.
- `New-PSCertificate` — Ana üretim orkestratörü. `AcmeProvider` parametresi ile istek bazında CA override. ACME veya LocalCA'ya yönlendirir, PFX kaydeder, durumu günceller.
- `Update-PSCertificate` — Mevcut sertifikayı yeniler.
- `Remove-PSCertificate` — Sertifika ve PFX dosyasını siler.
- `Export-PSCertificate` — PFX'i PEM/Key/JKS formatlarına dönüştürür.
- `Test-PSCertificate` — Geçerlilik süresi kontrolü.
- `Repair-PSCMCertificatePfx` — Bozuk PFX onarımı.

#### 2.8. LocalCA (Windows ADCS)
- `Invoke-PSCMLocalCACertificateRequest` — `Get-Certificate` cmdlet'i ile ADCS'den sertifika talep eder.
- `Repair-PSCMLocalCAPermissions` — AD sertifika şablonunda LDAP üzerinden Enroll izni ayarlar.

#### 2.9. AzureDNS
- `Connect-PSCMAzure` — Service Principal ile Azure oturum açma.
- DNS Zone CRUD (`Get`, `Find`, `Add`, `Remove`).
- **Harici bağımlılık:** `Az.Accounts`, `Az.Dns`.

#### 2.10. SSLTools (OpenSSL Araçları)
- CSR bilgisi okuma, sertifika bilgisi okuma, PFX oluşturma, Private Key export, Java Keystore (JKS) export, CSR oluşturma.
- **Harici bağımlılık:** `openssl.exe` (yoksa `winget` ile kurulum asistanı).

#### 2.11. Deployment (Dağıtım)
- `Install-CertificateToStore` — PFX'i Windows sertifika deposuna aktarır.
- `Set-IISCertificateBinding` — IIS HTTPS binding oluşturur/günceller (SNI destekli).
- `Set-NginxApacheBinding` — PFX'ten CRT+Key çıkartarak Nginx/Apache sunucuya kopyalar.
- `Invoke-RemoteIISDeployment` — WinRM ile uzak IIS'e sertifika dağıtımı.
- `Get-PSCMDeploymentConfig` — SQLite'dan deployment konfigürasyonunu okur.
- `Get-PSCMIISBinding` — Mevcut IIS binding'lerini listeler.
- **ÖNEMLİ:** Tüm geçici dosyalar (`.inf` vb.) projenin `Temp/` dizininde oluşturulmalı, `$env:TEMP` kullanılmamalıdır (GPO/AppLocker uyumluluğu için).

#### 2.12. Notification (Bildirim)
- 4 kanal: SMTP (`System.Net.Mail.SmtpClient`), Microsoft Teams (MessageCard), Slack (attachment), Discord (embed). Her biri ayrı `.ps1` dosyası.
- Gizli bilgiler (SMTP şifre, webhook URL) SecretStore'dan çekilmeli.

#### 2.13. Scheduler (Zamanlayıcı)
- Windows Task Scheduler ile yenileme görevi CRUD. `Invoke-PSCMRenewalCycle` ile süresi dolmak üzere olan sertifikaları toplu yenileme.

#### 2.14. ActionQueue (İşlem Kuyruğu)
- Dosya tabanlı asenkron kuyruk: `Pending/`, `Processed/`, `Failed/` dizinleri. Her işlem bir JSON dosyası.
- `Add-PSCMAction`, `Get-PSCMActionQueue`, `Invoke-PSCMActionQueue`, `Clear-PSCMActionQueue`, `Import-PSCMActionFile`.

#### 2.15. Dashboard
- `New-PSDashboard` — Statik HTML rapor dosyası oluşturur.
- `Get-PSDashboard` — Sertifika özet verisi nesnesi üretir.

#### 2.16. WebServer (REST API + SPA)
- **Backend:** `System.Net.HttpListener` tabanlı HTTP sunucu (varsayılan port 8080).
- **Güvenlik:** Sunucu başladığında benzersiz bir `$script:PSCMApiToken` üretir ve `index.html`'e gömer. Tüm POST istekleri `X-PSCM-Token` başlığı ile doğrulanır.
- **API Uç Noktaları:** `/api/v1/certificates`, `/api/v1/settings` (GET/POST), `/api/v1/secrets` (POST), `/api/v1/secrets/status` (GET), `/api/v1/acme/providers` (GET), `/api/v1/infrastructure`, `/api/v1/logs`, `/api/v1/actionqueue`, `/api/v1/scheduler`, `/api/v1/system/summary`, `/api/v1/notifications/*`, `/api/v1/ssl-tools/*`, `/api/v1/system/reset`.
- **Frontend:** Tek sayfalık uygulama (SPA). Koyu temalı glassmorphism tasarım. Sidebar navigasyon. Dashboard istatistik kartları, sertifika tablosu (renkli süre göstergeleri), işlem kuyruğu görünümü, SSL araçları (CSR parse, PFX oluştur), ayarlar sayfası (dinamik CA/DNS formları, kasa durumu göstergeleri), bildirim kanalları yönetimi, tehlikeli bölge (factory reset).
- **Dinamik Formlar (Kritik):** CA ve DNS sağlayıcı seçimleri dropdown olmalı. Seçilen sağlayıcıya göre altındaki form alanları JavaScript ile dinamik olarak güncellenmeli. Gizli alanların yanında kasadaki kayıt durumu gösterilmeli (`Kayıtlı: *****` yeşil veya `Kayıt Yok` kırmızı).

#### 2.17. CLI (Terminal Arayüzü)
- `Show-PSCMBanner` — ASCII banner ve versiyon.
- `Show-PSCMMenu` — Ana menü döngüsü (3 alt menü: İşlemler, Ayarlar, Bakım + Web Dashboard).
- 25+ interaktif menü fonksiyonu. Her menü kendi `.ps1` dosyasında.
- **Dinamik Sağlayıcı Listesi (Kritik):** Yeni Sertifika Sihirbazı ve Entegrasyon Ayarları menüsü, sağlayıcı listesini `Get-PSCMAcmeProviders` fonksiyonundan dinamik olarak okumalı. Hardcoded switch-case kullanılmamalı. EAB gerektiren sağlayıcılar için (RequireEAB=true) otomatik olarak EAB Key ID ve HMAC Key sorup kasaya kaydetmeli.

#### 2.18. Testing
- `Invoke-PSCMTestSuite` — Otomatik E2E test. Altyapı kontrolü, SQLite okuma, ActionQueue, WebServer API endpointlerini sırasıyla test eder.

---

### 3. YAPILANDIRMA DÜZENİ

`Config/settings.json` şu bölümleri içermeli:
```json
{
  "Version": "4.0.0",
  "General": { "IsConfigured": false },
  "Azure": { "TenantId": "", "SubscriptionId": "", "ResourceGroup": "", "DnsZone": "", "ClientId": "", "AuthMode": "ServicePrincipal" },
  "Acme": { "Provider": "LetsEncrypt", "KeyLength": "2048", "Client": "Posh-ACME", "ChallengeType": "dns-01", "DnsPlugin": "Azure", "AccountEmail": "" },
  "Certificate": { "DefaultExportFormat": "pfx", "AutoRenew": true, "RenewalThresholdDay": 30 },
  "Notification": { "Smtp": { "Port": 587, "Server": "", "UseTls": true, "From": "", "Username": "", "To": [] }, "Teams": { "WebhookRef": "Teams.WebhookUrl", "Enabled": false }, "Enabled": false },
  "Logging": { "MinimumLevel": "INFO", "MaxSizeMB": 10, "RetentionDays": 90 },
  "Paths": { "ArchiveFolder": "Certificates\\Archive", "OutputFolder": "Certificates\\Current" },
  "Defaults": { "Provider": "ACME", "TemplateName": "WebServer", "StoreName": "WebHosting" }
}
```

**KRİTİK KURAL:** Gizli bilgiler (şifreler, API anahtarları, webhook URL'leri) asla settings.json'a yazılmamalı. Tümü `Microsoft.PowerShell.SecretStore` kasasında DPAPI ile şifreli saklanmalıdır.

---

### 4. TEST STRATEJİSİ

- **Pester Birim Testleri:** `Tests/` dizininde. Common fonksiyonları, 19 modülün yapısal doğrulaması (var olma, sürüm, Public/ dizini), Settings fonksiyonları. `StrictMode -Version 3.0` altında çalışmalı.
- **E2E Sandbox Testi:** `Invoke-PSCMTestSuite` fonksiyonu. CLI fonksiyonlarının var olmasını, WebServer'ın başlatılıp API endpoint'lerinin HTTP 200 döndürmesini doğrular.

---

### 5. PAKETLEME

- `Build-Release.ps1` — Projeyi temiz bir ZIP dosyasına paketler. Kişisel verileri (log, DB, sertifika çıktıları, git geçmişi) temizler. `settings.json`'u `settings.example.json` olarak anonimleştirir.

---

### 6. KRİTİK TASARIM KARARLARI

1. **Sistem TEMP kullanma:** GPO/AppLocker kısıtlamalarına takılmamak için tüm geçici dosyalar projenin kendi `Temp/` dizininde oluşturulmalı. `$env:TEMP` asla kullanılmamalı.
2. **Single Source of Truth:** ACME sağlayıcı listesi tek bir fonksiyonda (`Get-PSCMAcmeProviders`) tanımlanmalı. CLI menüleri, Web UI dropdown'ları ve fabrika fonksiyonları bu listeyi dinamik okumalı.
3. **Gizli bilgi koruması:** Settings modülü, hassas alanları JSON'a yazmayı aktif olarak engellemeli. Tüm şifreler SecretStore kasasında tutulmalı.
4. **Thread-safety:** Log yazma işlemleri Global Mutex ile korunmalı.
5. **API güvenliği:** WebServer her başlangıçta benzersiz token üretmeli ve tüm POST'larda doğrulamalı.
6. **Koyu tema uyumluluğu:** Web UI'da `select option` elemanlarının koyu modda okunabilir olması için CSS override gerekli.

---

### 7. DİZİN YAPISI

```
PS-CertManager/
├── Manager-Start.ps1
├── Build-Release.ps1
├── README.md
├── CHANGELOG.md
├── Config/settings.json
├── Certificates/{Current,Archive}/
├── Logs/
├── Temp/
├── Tests/{Common,PSCertManager,Settings}.Tests.ps1
└── Modules/
    ├── PSCertManager/         # Master konteyner (NestedModules ile 18 alt modül)
    ├── Common/                # Public/{16 dosya}
    ├── Settings/              # Public/{3 dosya}
    ├── Logging/               # Public/{3 dosya}
    ├── Security/              # Public/{6 dosya}
    ├── Bootstrap/             # Public/{4 dosya}
    ├── ACME/                  # Public/{4 dosya} + Private/{1 class dosyası}
    ├── Certificate/           # Public/{7 dosya}
    ├── LocalCA/               # Public/{2 dosya}
    ├── AzureDNS/              # Public/{7 dosya}
    ├── SSLTools/              # Public/{6 dosya}
    ├── Deployment/            # Public/{6 dosya} + Private/{1 dosya}
    ├── Notification/          # Public/{4 dosya}
    ├── Scheduler/             # Public/{4 dosya}
    ├── ActionQueue/           # Public/{5 dosya}
    ├── Dashboard/             # Public/{2 dosya}
    ├── WebServer/             # Public/{1 dosya} + PublicWeb/{index.html, js/app.js, css/style.css}
    ├── CLI/                   # Public/{25+ dosya}
    └── Testing/               # Public/{1 dosya}
```

## PROMPT SONU
