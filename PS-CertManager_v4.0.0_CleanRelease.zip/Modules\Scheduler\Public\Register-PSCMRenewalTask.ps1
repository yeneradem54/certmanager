function Register-PSCMRenewalTask {
<#
.SYNOPSIS
Sertifika yenileme icin Windows Task Scheduler gorevi kayit eder.
.DESCRIPTION
Her gun belirtilen saatte Invoke-PSCMRenewalCycle cagirir.
IncludeActionQueue verilirse her 5 dakikada Invoke-PSCMActionQueue cagiran
ikinci bir gorev de kayit edilir.
.PARAMETER Time
Yenileme saati (varsayilan 03:00).
.PARAMETER IncludeActionQueue
Action queue gorevini de kayit et.
.PARAMETER RunAsUser
Gorev hangi kullanici kimligiyle calisacak.
.EXAMPLE
Register-PSCMRenewalTask -Time '03:00' -IncludeActionQueue
#>
    [CmdletBinding()]
    param(
        [string]$Time = '03:00',
        [switch]$IncludeActionQueue,
        [string]$RunAsUser = $env:USERNAME
    )
    if (-not (Test-PSCMAdmin)) {
        throw (New-PSCMException -Message 'Task Scheduler kayit icin yonetici yetkisi gerekir.' -Category 'Guvenlik' -ErrorCode 'PSCM-5030')
    }

    $root = Get-PSCMRootPath
    $ps = (Get-Command powershell.exe -EA SilentlyContinue).Source
    if (-not $ps) { $ps = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" }

    # Try to load Windows domain password for the scheduler user from SecretStore
    $secretName = 'Scheduler.Password'
    $schedulerPass = Get-PSCMSecret -Name $secretName -EA SilentlyContinue
    
    if (-not $schedulerPass) {
        if ([Environment]::UserInteractive) {
            Write-Host ""
            Write-Host "Zamanlanmis gorevin local CA (ADCS) ve network kaynaklarina erisebilmesi icin domain parolaniz gereklidir." -ForegroundColor Yellow
            Write-Host "Girilen parola PSCertManagerVault (SecretStore) icerisinde guvenli sekilde saklanacaktir." -ForegroundColor White
            Write-Host ""
            $promptPass = Read-Host -Prompt "$RunAsUser kullanicisi icin etki alani (domain) parolasi" -AsSecureString
            if ($promptPass -and $promptPass.Length -gt 0) {
                Set-PSCMSecret -Name $secretName -Value $promptPass
                $schedulerPass = $promptPass
                Write-Host "Parola basariyla PSCertManagerVault'a kaydedildi." -ForegroundColor Green
            }
        }
    }

    $plainPass = $null
    if ($schedulerPass) {
        $plainPass = (New-Object System.Management.Automation.PSCredential("x", $schedulerPass)).GetNetworkCredential().Password
    }

    # Yenileme gorevi
    $renewCmd = ('-NoProfile -ExecutionPolicy Bypass -Command "Import-Module ''{0}\Modules\PSCertManager\PSCertManager.psd1'' -Force; Invoke-PSCMRenewalCycle"' -f $root)
    $action = New-ScheduledTaskAction -Execute $ps -Argument $renewCmd -WorkingDirectory $root
    $trigger = New-ScheduledTaskTrigger -Daily -At $Time
    $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -RunOnlyIfNetworkAvailable -DontStopOnIdleEnd -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

    Unregister-ScheduledTask -TaskName $script:PSCMTaskName -TaskPath $script:PSCMTaskFolder -Confirm:$false -EA SilentlyContinue
    
    if ($plainPass) {
        Register-ScheduledTask -TaskName $script:PSCMTaskName -TaskPath $script:PSCMTaskFolder -Action $action -Trigger $trigger -Settings $settings -User $RunAsUser -Password $plainPass -RunLevel Highest | Out-Null
    } else {
        $principal = New-ScheduledTaskPrincipal -UserId $RunAsUser -LogonType S4U -RunLevel Highest
        Register-ScheduledTask -TaskName $script:PSCMTaskName -TaskPath $script:PSCMTaskFolder -Action $action -Trigger $trigger -Settings $settings -Principal $principal | Out-Null
    }
    Write-PSCMLog -Level INFO -Message ('Task Scheduler kayit edildi: ' + $script:PSCMTaskName + ' (Saat: ' + $Time + ')') -Source 'Scheduler'

    if ($IncludeActionQueue) {
        $qCmd = ('-NoProfile -ExecutionPolicy Bypass -Command "Import-Module ''{0}\Modules\PSCertManager\PSCertManager.psd1'' -Force; Invoke-PSCMActionQueue"' -f $root)
        $qAction = New-ScheduledTaskAction -Execute $ps -Argument $qCmd -WorkingDirectory $root
        $qTrigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 5) -RepetitionDuration (New-TimeSpan -Days 9999)
        Unregister-ScheduledTask -TaskName $script:PSCMQueueTaskName -TaskPath $script:PSCMTaskFolder -Confirm:$false -EA SilentlyContinue
        
        if ($plainPass) {
            Register-ScheduledTask -TaskName $script:PSCMQueueTaskName -TaskPath $script:PSCMTaskFolder -Action $qAction -Trigger $qTrigger -Settings $settings -User $RunAsUser -Password $plainPass -RunLevel Highest | Out-Null
        } else {
            $principal = New-ScheduledTaskPrincipal -UserId $RunAsUser -LogonType S4U -RunLevel Highest
            Register-ScheduledTask -TaskName $script:PSCMQueueTaskName -TaskPath $script:PSCMTaskFolder -Action $qAction -Trigger $qTrigger -Settings $settings -Principal $principal | Out-Null
        }
        Write-PSCMLog -Level INFO -Message ('Task Scheduler kayit edildi: ' + $script:PSCMQueueTaskName) -Source 'Scheduler'
    }
    return (Get-PSCMRenewalTask)
}
