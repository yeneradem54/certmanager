@{
    RootModule = 'PSCM.Testing.psm1'
    ModuleVersion = '4.0.0'
    GUID = 'c2566b13-6d3c-40a4-958d-4c79a4c8a041'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager Testing Module'
    FunctionsToExport = @('Invoke-PSCMTestSuite')
}
