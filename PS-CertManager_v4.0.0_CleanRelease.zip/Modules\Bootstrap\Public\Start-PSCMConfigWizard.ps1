function Start-PSCMConfigWizard {
<#
.SYNOPSIS
Azure baglanti ve ACME bilgilerini adim adim yapilandirir.
#>
    [CmdletBinding()]
    param()
    Write-Host ''
    Write-Host '============================================================' -ForegroundColor Cyan
    Write-Host '  PS-CertManager - Azure Kurulum Sihirbazi' -ForegroundColor Cyan
    Write-Host '============================================================' -ForegroundColor Cyan
    Write-Host ''
    Write-Host 'Bos gecerseniz mevcut deger korunur.' -ForegroundColor DarkGray
    Write-Host ''
    try { Initialize-PSCMSettings | Out-Null } catch {}
    $current = Get-PSSettings

    Write-Host '--- 1) Azure Baglanti Bilgileri ---' -ForegroundColor Yellow
    $curTenant = if ($current.Azure.TenantId) { $current.Azure.TenantId } else { '(bos)' }
    Write-Host ('  Mevcut Tenant ID       : ' + $curTenant) -ForegroundColor DarkGray
    $tenant = Read-Host '  Yeni Tenant ID'
    if ($tenant) { Set-PSSettings -Section Azure -Key TenantId -Value $tenant }

    $curSub = if ($current.Azure.SubscriptionId) { $current.Azure.SubscriptionId } else { '(bos)' }
    Write-Host ('  Mevcut Subscription ID : ' + $curSub) -ForegroundColor DarkGray
    $sub = Read-Host '  Yeni Subscription ID'
    if ($sub) { Set-PSSettings -Section Azure -Key SubscriptionId -Value $sub }

    $curRg = if ($current.Azure.ResourceGroup) { $current.Azure.ResourceGroup } else { '(bos)' }
    Write-Host ('  Mevcut Resource Group  : ' + $curRg) -ForegroundColor DarkGray
    $rg = Read-Host '  DNS Zone hangi Resource Group icinde'
    if ($rg) { Set-PSSettings -Section Azure -Key ResourceGroup -Value $rg }

    $curZone = if ($current.Azure.DnsZone) { $current.Azure.DnsZone } else { '(bos)' }
    Write-Host ('  Mevcut DNS Zone        : ' + $curZone) -ForegroundColor DarkGray
    $zone = Read-Host '  DNS Zone adi (ornek: ornek.com)'
    if ($zone) { Set-PSSettings -Section Azure -Key DnsZone -Value $zone }

    Write-Host ''
    Write-Host '--- 2) Kimlik Dogrulama Modu ---' -ForegroundColor Yellow
    Write-Host '  1) Interactive       (tarayici ile giris)'
    Write-Host '  2) ServicePrincipal  (uygulama kimligi + secret)'
    Write-Host '  3) ManagedIdentity   (Azure VM icinde)'
    $curMode = if ($current.Azure.AuthMode) { $current.Azure.AuthMode } else { 'Interactive' }
    Write-Host ('  Mevcut mod: ' + $curMode) -ForegroundColor DarkGray
    $modeIn = Read-Host '  Secim [1/2/3] (Enter = degistirme)'
    $mode = $curMode
    switch ($modeIn) {
        '1' { $mode = 'Interactive' }
        '2' { $mode = 'ServicePrincipal' }
        '3' { $mode = 'ManagedIdentity' }
    }
    Set-PSSettings -Section Azure -Key AuthMode -Value $mode

    if ($mode -eq 'ServicePrincipal') {
        Write-Host ''
        Write-Host '--- 3) Service Principal Kimligi ---' -ForegroundColor Yellow
        $curClientId = if ($current.Azure.ClientId) { $current.Azure.ClientId } else { '(bos)' }
        Write-Host ('  Mevcut ClientId: ' + $curClientId) -ForegroundColor DarkGray
        $clientId = Read-Host '  Application (Client) ID'
        if ($clientId) { Set-PSSettings -Section Azure -Key ClientId -Value $clientId }

        Write-Host '  Client Secret SecretStore icinde saklanacak.' -ForegroundColor DarkGray
        $secret = Read-Host '  Client Secret' -AsSecureString
        if ($secret -and $secret.Length -gt 0) {
            try {
                Initialize-PSCMSecretStore -AllowClobber | Out-Null
                Set-PSCMSecret -Name 'Azure.ClientSecret' -Value $secret
                Write-Host '  [OK] Client Secret kaydedildi.' -ForegroundColor Green
            } catch {
                Write-Host ('  [HATA] SecretStore: ' + $_.Exception.Message) -ForegroundColor Red
            }
        }
    }

    Write-Host ''
    Write-Host '--- 3b) SecretStore Guvenlik Politikasi ---' -ForegroundColor Yellow
    Write-Host '  Guvenli kasanin (vault) kilit politikasini belirleyin.' -ForegroundColor White
    Write-Host '  1) None / DPAPI  - Hicbir zaman parola sormaz. Arka plan gorevleri icin ONERILEN.' -ForegroundColor DarkGray
    Write-Host '  2) Session       - 8 saatte bir parola sorar (interaktif kullanim).' -ForegroundColor DarkGray
    Write-Host '  3) Varsayilan    - Degistirme (mevcut politika korunur).' -ForegroundColor DarkGray
    $policyIn = Read-Host '  Secim [1/2/3] (Enter = 1)'
    if (-not $policyIn -or $policyIn -eq '1') {
        try {
            Set-PSCMSecretStorePolicy -Policy None
        } catch {
            Write-Host ('  [UYARI] SecretStore policy ayarlanamadi: ' + $_.Exception.Message) -ForegroundColor Yellow
        }
    } elseif ($policyIn -eq '2') {
        try {
            Set-PSCMSecretStorePolicy -Policy Session -TimeoutHours 8
        } catch {
            Write-Host ('  [UYARI] SecretStore policy ayarlanamadi: ' + $_.Exception.Message) -ForegroundColor Yellow
        }
    }

    Write-Host ''
    Write-Host '--- 3c) DNS Dogrulama Saglayicisi (DnsPlugin) ---' -ForegroundColor Yellow
    Write-Host '  Wildcard/internet sertifikalari icin DNS dogrulamasi saglayicisi.' -ForegroundColor White
    Write-Host '  1) Azure DNS  - Azure DNS Zone kullanir.' -ForegroundColor DarkGray
    Write-Host '  2) GoDaddy    - GoDaddy API anahtari kullanir.' -ForegroundColor DarkGray
    Write-Host '  3) Cloudflare - Cloudflare API Token kullanir.' -ForegroundColor DarkGray
    Write-Host '  4) Route53    - AWS Route53 Access Key kullanir.' -ForegroundColor DarkGray
    Write-Host '  5) Varsayilan - Degistirme (mevcut saglayici korunur).' -ForegroundColor DarkGray
    
    $curPlugin = if ($current.Acme.DnsPlugin) { $current.Acme.DnsPlugin } else { 'Azure' }
    Write-Host ("  Mevcut saglayici: " + $curPlugin) -ForegroundColor DarkGray
    
    $pluginIn = Read-Host '  Secim [1/2/3/4/5] (Enter = degistirme)'
    $plugin = $curPlugin
    switch ($pluginIn) {
        '1' { $plugin = 'Azure' }
        '2' { $plugin = 'GoDaddy' }
        '3' { $plugin = 'Cloudflare' }
        '4' { $plugin = 'Route53' }
    }
    
    Set-PSSettings -Section Acme -Key DnsPlugin -Value $plugin
    Write-Host ("  DnsPlugin '$plugin' olarak ayarlandi.") -ForegroundColor Green
    
    # Seçilen plugin'e göre gizli anahtarları SecretStore'a ekleme adımı
    if ($plugin -eq 'GoDaddy') {
        Write-Host ''
        Write-Host '  -- GoDaddy API Kimlik Bilgileri --' -ForegroundColor Yellow
        $gdKey = Read-Host '  GoDaddy API Key' -AsSecureString
        if ($gdKey -and $gdKey.Length -gt 0) {
            Set-PSCMSecret -Name 'GoDaddy.Key' -Value $gdKey
            Write-Host '  [OK] GoDaddy.Key SecretStore''a kaydedildi.' -ForegroundColor Green
        }
        $gdSecret = Read-Host '  GoDaddy API Secret' -AsSecureString
        if ($gdSecret -and $gdSecret.Length -gt 0) {
            Set-PSCMSecret -Name 'GoDaddy.Secret' -Value $gdSecret
            Write-Host '  [OK] GoDaddy.Secret SecretStore''a kaydedildi.' -ForegroundColor Green
        }
    }
    elseif ($plugin -eq 'Cloudflare') {
        Write-Host ''
        Write-Host '  -- Cloudflare API Kimlik Bilgileri --' -ForegroundColor Yellow
        $cfToken = Read-Host '  Cloudflare API Token' -AsSecureString
        if ($cfToken -and $cfToken.Length -gt 0) {
            Set-PSCMSecret -Name 'Cloudflare.Token' -Value $cfToken
            Write-Host '  [OK] Cloudflare.Token SecretStore''a kaydedildi.' -ForegroundColor Green
        }
    }
    elseif ($plugin -eq 'Route53') {
        Write-Host ''
        Write-Host '  -- AWS Route53 API Kimlik Bilgileri --' -ForegroundColor Yellow
        $awsKey = Read-Host '  AWS Access Key ID' -AsSecureString
        if ($awsKey -and $awsKey.Length -gt 0) {
            Set-PSCMSecret -Name 'Route53.AccessKey' -Value $awsKey
            Write-Host '  [OK] Route53.AccessKey SecretStore''a kaydedildi.' -ForegroundColor Green
        }
        $awsSecret = Read-Host '  AWS Secret Access Key' -AsSecureString
        if ($awsSecret -and $awsSecret.Length -gt 0) {
            Set-PSCMSecret -Name 'Route53.SecretKey' -Value $awsSecret
            Write-Host '  [OK] Route53.SecretKey SecretStore''a kaydedildi.' -ForegroundColor Green
        }
    }

    Write-Host ''
    Write-Host '--- 3d) ACME Sertifika Saglayicisi (Otorite / CA) ---' -ForegroundColor Yellow
    Write-Host '  1) Let''s Encrypt (Ucretsiz, Varsayilan)' -ForegroundColor DarkGray
    Write-Host '  2) Let''s Encrypt Staging (Ucretsiz, Test/Deneme)' -ForegroundColor DarkGray
    Write-Host '  3) ZeroSSL (Ucretsiz / Ucretli)' -ForegroundColor DarkGray
    Write-Host '  4) GoDaddy CA (Ucretli - EAB gerektirir)' -ForegroundColor DarkGray
    Write-Host '  5) Varsayilan - Degistirme (mevcut saglayici korunur)' -ForegroundColor DarkGray
    
    $curProvider = if ($current.Acme.Provider) { $current.Acme.Provider } else { 'LetsEncrypt' }
    Write-Host ("  Mevcut saglayici: " + $curProvider) -ForegroundColor DarkGray
    
    $provIn = Read-Host '  Secim [1/2/3/4/5] (Enter = degistirme)'
    $provider = $curProvider
    switch ($provIn) {
        '1' { $provider = 'LetsEncrypt' }
        '2' { $provider = 'LetsEncryptStaging' }
        '3' { $provider = 'ZeroSSL' }
        '4' { $provider = 'GoDaddy' }
    }
    
    Set-PSSettings -Section Acme -Key Provider -Value $provider
    Write-Host ("  Acme.Provider '$provider' olarak ayarlandi.") -ForegroundColor Green
    
    # EAB gerektiren GoDaddy seçildiyse EAB bilgilerini soralım
    if ($provider -eq 'GoDaddy') {
        Write-Host ''
        Write-Host '  -- GoDaddy CA ACME EAB Kimlik Bilgileri --' -ForegroundColor Yellow
        Write-Host '  (GoDaddy SSL ACME kurulum sayfasindan edindiginiz keyleri girin)' -ForegroundColor DarkGray
        
        $eabKeyId = Read-Host '  GoDaddy EAB Key ID' -AsSecureString
        if ($eabKeyId -and $eabKeyId.Length -gt 0) {
            Set-PSCMSecret -Name 'Acme.EabKeyId.GoDaddy' -Value $eabKeyId
            Write-Host '  [OK] Acme.EabKeyId.GoDaddy kasaya kaydedildi.' -ForegroundColor Green
        }
        $eabHmac = Read-Host '  GoDaddy EAB HMAC Key' -AsSecureString
        if ($eabHmac -and $eabHmac.Length -gt 0) {
            Set-PSCMSecret -Name 'Acme.EabHmacKey.GoDaddy' -Value $eabHmac
            Write-Host '  [OK] Acme.EabHmacKey.GoDaddy kasaya kaydedildi.' -ForegroundColor Green
        }
    }

    Write-Host ''
    Write-Host '--- 4) ACME Hesap E-Postasi ---' -ForegroundColor Yellow
    $curEmail = if ($current.Acme.AccountEmail) { $current.Acme.AccountEmail } else { '(bos)' }
    Write-Host ('  Mevcut e-posta: ' + $curEmail) -ForegroundColor DarkGray
    $email = Read-Host '  E-posta'
    if ($email) { Set-PSSettings -Section Acme -Key AccountEmail -Value $email }

    Write-Host ''
    Write-Host '--- 5) Baglanti Testi ---' -ForegroundColor Yellow
    $doTest = Read-Host 'Azure baglantisi test edilsin mi? [E/H]'
    if ($doTest -match '^[EeYy]') {
        try {
            $test = Test-PSAzure
            if ($test.Durum) { Write-Host ('  [OK] ' + $test.Aciklama) -ForegroundColor Green }
            else { Write-Host ('  [UYARI] ' + $test.Aciklama) -ForegroundColor Yellow }
        } catch {
            Write-Host ('  [HATA] ' + $_.Exception.Message) -ForegroundColor Red
        }
    }
    Write-Host ''
    Write-Host 'Sihirbaz tamamlandi. Ana menuden 4) Yeni Sertifika secebilirsiniz.' -ForegroundColor Green
}
