function Invoke-MenuDashboard {
    Show-PSCMBanner
    Write-Host '>> Canli Web Dashboard & API' -ForegroundColor Yellow
    Write-Host ''
    try {
        Start-Process powershell -WindowStyle Hidden -ArgumentList "-Command `"Start-Sleep -Seconds 2; Start-Process 'http://localhost:8080/'`"" -ErrorAction SilentlyContinue
        Start-PSCMWebServer -Port 8080
    } catch { 
        Write-Host "Sunucu baslatilamadi: $($_.Exception.Message)" -ForegroundColor Red
    }
    Pause-PSCM
}
