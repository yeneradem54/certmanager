function Remove-PSCertificate {
<#
.SYNOPSIS
Sertifikayi index'ten cikarir. Dosyalar Archive'a tasinir.
#>
    [CmdletBinding(SupportsShouldProcess,ConfirmImpact='High')]
    param([Parameter(Mandatory)][string]$Domain)
    if ($PSCmdlet.ShouldProcess($Domain,'Sertifika kaldir')) {
        $data = @(Get-PSCMState -Table 'certificates')
        if ($data.Count -gt 0) {
            $filtered = @($data | Where-Object { $_.Domain -ne $Domain })
            Set-PSCMState -Table 'certificates' -Data $filtered
        }
        $safe = ($Domain -replace '\*','wildcard') -replace '[^a-zA-Z0-9\.\-_]','_'
        $currentDir = Join-Path (Get-PSCMPath -Name Current) $safe
        if (Test-Path -LiteralPath $currentDir) {
            $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
            $archive = Join-Path (Join-Path (Get-PSCMPath -Name Archive) $safe) ('removed_' + $stamp)
            
            # Klasörü kopyala, sonra sil (Move-Item kilit hatalarına karşı korur)
            New-Item -ItemType Directory -Path $archive -Force | Out-Null
            Copy-Item -LiteralPath $currentDir -Destination $archive -Recurse -Force -ErrorAction SilentlyContinue
            Remove-Item -LiteralPath $currentDir -Recurse -Force -ErrorAction SilentlyContinue
            
            Write-PSCMLog -Level INFO -Message ('Aktif klasor arsivlendi ve silindi: ' + $archive) -Source 'Certificate'
        }
        Write-PSCMLog -Level INFO -Message ('Sertifika index kaldirildi: ' + $Domain) -Source 'Certificate'
    }
}
