﻿function Format-PSCMCertTable {
    [CmdletBinding()]
    [OutputType([object[]])]
    param(
        [Parameter(ValueFromPipeline)]$Certificates,
        [switch]$PassThru
    )
    begin { $list = New-Object System.Collections.ArrayList }
    process {
        if ($Certificates) {
            foreach ($c in @($Certificates)) { if ($c) { [void]$list.Add($c) } }
        }
    }
    end {
        if ($list.Count -eq 0) {
            Write-Host 'Kayitli sertifika yok.' -ForegroundColor DarkGray
            return
        }
        Write-Host ('Toplam: ' + $list.Count + ' sertifika') -ForegroundColor Cyan
        Write-Host ''
        $header = '{0,-4} {1,-32} {2,-8} {3,-18} {4,-19} {5,-14} {6,-10}' -f '#','DOMAIN','WILDCARD','ISSUER','BITIS','KALAN','DURUM'
        Write-Host $header -ForegroundColor Gray
        Write-Host ('-' * 115) -ForegroundColor DarkGray
        $indexed = New-Object System.Collections.ArrayList
        $i = 1
        foreach ($c in $list) {
            $props = @($c.PSObject.Properties.Name)
            $dom = if ($props -contains 'Domain' -and $c.Domain) { [string]$c.Domain } else { '(bos)' }
            $wc = 'Hayir'
            if ($props -contains 'Wildcard' -and $c.Wildcard) { $wc = 'Evet' }
            $iss = "Let's Encrypt"
            if ($props -contains 'Issuer' -and $c.Issuer) { $iss = [string]$c.Issuer }
            if ($iss.Length -gt 18) { $iss = $iss.Substring(0,15) + '...' }
            $exp = '-'
            if ($props -contains 'NotAfter' -and $c.NotAfter) {
                try { $exp = ([datetime]$c.NotAfter).ToString('yyyy-MM-dd HH:mm') } catch { $exp = [string]$c.NotAfter }
            }
            $days = -1
            if ($props -contains 'DaysRemaining' -and $null -ne $c.DaysRemaining) {
                try { $days = [int]$c.DaysRemaining } catch { $days = -1 }
            }
            $stat = '-'
            if ($props -contains 'Status' -and $c.Status) { $stat = [string]$c.Status }
            $daysTxt = if ($days -lt 0) { 'Suresi doldu' } else { $days.ToString() + ' gun' }
            $color = 'White'
            switch ($stat) {
                'Healthy'  { $color = 'Green' }
                'Warning'  { $color = 'Yellow' }
                'Critical' { $color = 'Red' }
                'Expired'  { $color = 'DarkRed' }
            }
            $line = '{0,-4} {1,-32} {2,-8} {3,-18} {4,-19} {5,-14} {6,-10}' -f `
                $i, $dom.PadRight(32).Substring(0,32), $wc, $iss.PadRight(18).Substring(0,18),
                $exp, $daysTxt.PadRight(14).Substring(0,14), $stat
            Write-Host $line -ForegroundColor $color
            [void]$indexed.Add([PSCustomObject]@{
                Index         = $i
                Domain        = $dom
                Wildcard      = if ($props -contains 'Wildcard') { [bool]$c.Wildcard } else { $false }
                Issuer        = $iss
                NotAfter      = if ($props -contains 'NotAfter') { $c.NotAfter } else { $null }
                DaysRemaining = $days
                Status        = $stat
                FriendlyName  = if ($props -contains 'FriendlyName') { $c.FriendlyName } else { $dom }
                Path          = if ($props -contains 'Path') { $c.Path } else { '' }
                Thumbprint    = if ($props -contains 'Thumbprint') { $c.Thumbprint } else { '' }
            })
            $i++
        }
        if ($PassThru) {
            foreach ($item in $indexed) { $item }
        }
    }
}
