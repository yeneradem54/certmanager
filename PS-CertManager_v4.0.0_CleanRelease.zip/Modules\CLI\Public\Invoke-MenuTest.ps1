function Invoke-MenuTest {
    Show-PSCMBanner
    Write-Host '  --- SERTIFIKA SAGLIGI TESTI ---' -ForegroundColor Yellow
    Write-Host ''
    $dom = Read-Host 'Domain (bos = tumu)'
    try {
        if ($dom) { $r = Test-PSCertificate -Domain $dom -All } else { $r = Test-PSCertificate -All }
        $r | Format-Table Domain,Durum,DosyaVarMi,X509Gecerli,ThumbprintOk,SANSayisi,KalanGun -AutoSize | Out-String -Stream | ForEach-Object { Write-Host $_ }
    } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
    Pause-PSCM
}
