﻿#Requires -Version 5.1
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'
$script:PSCMLogConfig = @{
    MaxSizeMB     = 10
    RetentionDays = 90
    ConsoleOutput = $true
    MinimumLevel  = 'INFO'
    LevelPriority = @{ DEBUG = 0; INFO = 1; WARNING = 2; ERROR = 3 }
}
Get-ChildItem -Path (Join-Path $PSScriptRoot 'Public') -Filter '*.ps1' -EA SilentlyContinue | ForEach-Object { . $_.FullName }
Export-ModuleMember -Function @('Write-PSCMLog','Get-PSLog','Invoke-PSCMLogRotation')
