@{
    RootModule = 'PSCM.Deployment.psm1'
    ModuleVersion = '1.0.0'
    GUID = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'
    Author = 'PS-CertManager Ekibi'
    CompanyName = 'PS-CertManager'
    Copyright = '(c) 2026 PS-CertManager. Tum haklari saklidir.'
    Description = 'PS-CertManager Deployment Modülü (IIS ve Uzak Sunucu)'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Install-CertificateToStore', 'Set-IISCertificateBinding', 'Invoke-RemoteIISDeployment', 'Get-PSCMDeploymentConfig', 'Get-PSCMIISBinding')
}
