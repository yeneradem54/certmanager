function Start-PSCMWebServer {
<#
.SYNOPSIS
Localhost uzerinde calisan ve REST API/Dashboard sunan hafif bir HTTP sunucusu baslatir.
#>
    [CmdletBinding()]
    param(
        [int]$Port = 8080
    )
    
    $listener = New-Object System.Net.HttpListener
    $url = "http://localhost:$($Port)/"
    $listener.Prefixes.Add($url)
    
    try {
        $listener.Start()
        Write-Host "=====================================================" -ForegroundColor Cyan
        Write-Host " PS-CertManager Canli Dashboard & API Sunucusu Calisiyor" -ForegroundColor Green
        Write-Host "=====================================================" -ForegroundColor Cyan
        Write-Host " Tarayicinizda acin: " -NoNewline; Write-Host $url -ForegroundColor Yellow
        Write-Host " Durdurmak icin 'Q' veya 'ESC' tusuna basin..." -ForegroundColor Gray
        Write-Host ""
        
        Write-PSCMLog -Level INFO -Message "WebServer baslatildi: $url" -Source 'WebServer'

        while ($listener.IsListening) {
            # Kullanici Q veya ESC tusuna basarsa sunucuyu durdur
            if ([Console]::KeyAvailable) {
                $key = [Console]::ReadKey($true)
                if ($key.Key -eq 'Q' -or $key.Key -eq 'Escape') {
                    Write-Host "`n[BILGI] Sunucu durduruluyor..." -ForegroundColor Yellow
                    break
                }
            }

            $asyncResult = $listener.BeginGetContext($null, $null)
            while (-not $asyncResult.IsCompleted) {
                if ([Console]::KeyAvailable) {
                    $key = [Console]::ReadKey($true)
                    if ($key.Key -eq 'Q' -or $key.Key -eq 'Escape') {
                        Write-Host "`n[BILGI] Sunucu durduruluyor..." -ForegroundColor Yellow
                        $listener.Stop()
                        break
                    }
                }
                Start-Sleep -Milliseconds 200
            }
            if (-not $listener.IsListening) { break }
            $context = $listener.EndGetContext($asyncResult)
            $request = $context.Request
            $response = $context.Response
            
            # CORS Headers
            $response.AppendHeader("Access-Control-Allow-Origin", "*")
            $response.AppendHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            $response.AppendHeader("Access-Control-Allow-Headers", "Content-Type")

            if ($request.HttpMethod -eq 'OPTIONS') {
                $response.StatusCode = 204
                $response.Close()
                continue
            }
            
            $path = $request.Url.LocalPath.ToLower()
            $responseBytes = New-Object byte[] 0
            
            try {
                if ($path -eq '/' -or $path -eq '/index.html') {
                    $templatePath = Join-Path (Get-PSCMRootPath) "Modules\Dashboard\Templates\dashboard-template.html"
                    if (Test-Path $templatePath) {
                        $content = Get-Content -Path $templatePath -Raw -Encoding UTF8
                        $responseBytes = [System.Text.Encoding]::UTF8.GetBytes($content)
                        $response.ContentType = "text/html; charset=utf-8"
                    } else {
                        $response.StatusCode = 404
                        $responseBytes = [System.Text.Encoding]::UTF8.GetBytes("Dashboard sablonu bulunamadi.")
                    }
                }
                elseif ($path -eq '/api/certificates' -and $request.HttpMethod -eq 'GET') {
                    $data = Get-PSCMState -Table 'certificates'
                    if ($data -and $data.Count -gt 0) {
                        $json = ConvertTo-Json -InputObject @($data) -Depth 5 -Compress
                    } else {
                        $json = '[]'
                    }
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes($json)
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/action' -and $request.HttpMethod -eq 'POST') {
                    $reader = New-Object System.IO.StreamReader($request.InputStream, $request.ContentEncoding)
                    $body = $reader.ReadToEnd()
                    $payload = $body | ConvertFrom-Json
                    
                    if ($payload -and $payload.Action -and $payload.Domain) {
                        $pHash = @{}
                        if ($payload.psobject.Properties.Match('Params').Count -gt 0) {
                            if ($payload.Params) {
                                $payload.Params.psobject.Properties | ForEach-Object { $pHash[$_.Name] = $_.Value }
                            }
                        }
                        Add-PSCMAction -Action $payload.Action -Domain $payload.Domain -Params $pHash
                        $resObj = @{ success = $true; message = "Aksiyon kuyruga eklendi: $($payload.Action) $($payload.Domain)" }
                        $json = ConvertTo-Json -InputObject $resObj -Compress
                        $responseBytes = [System.Text.Encoding]::UTF8.GetBytes($json)
                        $response.ContentType = "application/json; charset=utf-8"
                    } else {
                        $response.StatusCode = 400
                        $resObj = @{ success = $false; message = "Gecersiz istek (Action veya Domain eksik)." }
                        $responseBytes = [System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $resObj -Compress))
                    }
                }
                elseif ($path -eq '/api/actionqueue' -and $request.HttpMethod -eq 'GET') {
                    $pend = @(Get-PSCMActionQueue -Status pending)
                    $proc = @(Get-PSCMActionQueue -Status processed)
                    $fail = @(Get-PSCMActionQueue -Status failed)
                    $qData = @{ pending = $pend; processed = $proc; failed = $fail }
                    $json = ConvertTo-Json -InputObject $qData -Depth 5 -Compress
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes($json)
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/actionqueue/process' -and $request.HttpMethod -eq 'POST') {
                    $res = @(Invoke-PSCMActionQueue)
                    $resObj = @{ success = $true; message = "$($res.Count) islem kuyruktan islendi."; results = $res }
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $resObj -Depth 5 -Compress))
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/actionqueue/clear' -and $request.HttpMethod -eq 'POST') {
                    $n = Clear-PSCMActionQueue -Status processed -OlderThanDays 30
                    $resObj = @{ success = $true; message = "$n eski islem temizlendi." }
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $resObj -Compress))
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/logs' -and $request.HttpMethod -eq 'GET') {
                    $logs = @(Get-PSLog -Level ALL -Last 100 -Days 3 | ForEach-Object { [string]$_ })
                    if ($logs.Count -gt 0) { $json = ConvertTo-Json -InputObject $logs -Compress } else { $json = '[]' }
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes($json)
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/infrastructure' -and $request.HttpMethod -eq 'GET') {
                    $infra = @(Get-PSInfrastructure)
                    if ($infra.Count -gt 0) { $json = ConvertTo-Json -InputObject $infra -Compress } else { $json = '[]' }
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes($json)
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/scheduler' -and $request.HttpMethod -eq 'GET') {
                    $tasks = @(Get-PSCMRenewalTask)
                    $json = $tasks | ConvertTo-Json -Compress
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes($json)
                    $response.ContentType = "application/json; charset=utf-8"
                }
                else {
                    $response.StatusCode = 404
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes("Bulunamadi")
                }
            } catch {
                $response.StatusCode = 500
                $resObj = @{ success = $false; message = $_.Exception.Message }
                $responseBytes = [System.Text.Encoding]::UTF8.GetBytes(($resObj | ConvertTo-Json -Compress))
            }
            
            if ($responseBytes.Length -gt 0) {
                $response.ContentLength64 = $responseBytes.Length
                $output = $response.OutputStream
                $output.Write($responseBytes, 0, $responseBytes.Length)
                $output.Close()
            } else {
                $response.Close()
            }
        }
    } catch {
        if ($_.Exception.Message -match "Erişim engellendi") {
            Write-Host "[HATA] Sunucuyu baslatmak icin Administrator yetkisi gerekebilir, ya da port kullanimda." -ForegroundColor Red
        } else {
            Write-Host "[HATA] WebServer Hatasi: $($_.Exception.Message)" -ForegroundColor Red
        }
    } finally {
        if ($listener) {
            $listener.Stop()
            $listener.Close()
        }
    }
}
