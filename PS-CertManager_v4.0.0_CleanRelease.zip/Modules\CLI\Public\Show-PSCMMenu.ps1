function Show-PSCMBanner {
    Clear-Host
    $ver = try { (Get-PSCMVersion).Version } catch { '4.0.0' }
    
    # Canli durum verilerini topla
    $acmeSet = try { Get-PSSettings -Section 'Acme' } catch { $null }
    $provider = if ($acmeSet -and $acmeSet.PSObject.Properties.Name -contains 'Provider' -and $acmeSet.Provider) { $acmeSet.Provider } else { 'LetsEncrypt' }
    
    $certs = try { @(Get-PSCertificate) } catch { @() }
    $totalCerts = $certs.Count
    $okCount = 0; $warnCount = 0; $critCount = 0
    foreach ($c in $certs) {
        if ($c.Status -eq 'Healthy') { $okCount++ }
        elseif ($c.Status -eq 'Warning') { $warnCount++ }
        else { $critCount++ }
    }
    
    Write-Host ''
    Write-Host '  +----------------------------------------------------------------------+' -ForegroundColor Cyan
    Write-Host '  |  PS-CertManager - Enterprise Certificate Manager                     |' -ForegroundColor Cyan
    Write-Host '  +----------------------------------------------------------------------+' -ForegroundColor Cyan
    Write-Host ("  |  [+] ACME Saglayici : $provider" + (' ' * [Math]::Max(1, 46 - $provider.Length)) + '|') -ForegroundColor DarkCyan
    Write-Host ("  |  [+] Sertifikalar   : $totalCerts Toplam | $okCount Saglikli | $warnCount Uyari | $critCount Kritik") -ForegroundColor DarkCyan
    Write-Host '  +----------------------------------------------------------------------+' -ForegroundColor Cyan
    Write-Host ''
}

function Show-PSCMMenu {
    Show-PSCMBanner
    
    Write-Host '  --- ANA MENU ---' -ForegroundColor Yellow
    Write-Host ''
    Write-Host '  [1] Sertifika Listesi & Islemler (Yenile, Export, PFX Onar)' -ForegroundColor White
    Write-Host '  [2] Yeni Sertifika Sihirbazi (ACME / Windows ADCS)' -ForegroundColor White
    Write-Host '  [3] Canli Web Dashboard & REST API Sunucusu (localhost:8080)' -ForegroundColor Green
    Write-Host ''
    Write-Host '  --- OTOMASYON & DAGITIM ---' -ForegroundColor Yellow
    Write-Host '  [4] Islem Kuyrugu (Action Queue) & Zamanlayici (Scheduler)' -ForegroundColor White
    Write-Host '  [5] Web Sunucusu Dagitim Ayarlari (IIS / Nginx / Apache)' -ForegroundColor White
    Write-Host '  [6] SSL Araclari (PFX->PEM/Key, CSR Uretme, Keystore)' -ForegroundColor White
    Write-Host ''
    Write-Host '  --- YAPILANDIRMA & BAKIM ---' -ForegroundColor Yellow
    Write-Host '  [7] Guvenlik, Kasa (SecretStore) & Bildirim Ayarlari' -ForegroundColor White
    Write-Host '  [8] Bakim, Testler (Pester / E2E) & OpenSSL Kurulumu' -ForegroundColor White
    Write-Host ''
    Write-Host '  [0] Cikis' -ForegroundColor DarkGray
    Write-Host ''
}

function Pause-PSCM {
    Write-Host ''
    Write-Host 'Devam etmek icin bir tusa basin...' -ForegroundColor DarkGray
    [void][System.Console]::ReadKey($true)
}
