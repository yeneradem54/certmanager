function Get-PSCMSslCertInfo {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$CertPath)

    $CertPath = $CertPath.Trim("`"").Trim("'").Trim()
    if (-not (Test-Path $CertPath)) { throw "Sertifika bulunamadi: $CertPath" }
    
    Write-PSCMLog -Level INFO -Message "Sertifika bilgileri okunuyor: $CertPath" -Source 'SSLTools'
    try {
        $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($CertPath)
        $sans = @()
        foreach ($ext in $cert.Extensions) {
            if ($ext.Oid.FriendlyName -match 'Subject Alternative Name|Konu|SAN') {
                $sans += $ext.Format($true)
            }
        }
        return [PSCustomObject]@{
            Subject = $cert.Subject
            Issuer = $cert.Issuer
            Thumbprint = $cert.Thumbprint
            NotBefore = $cert.NotBefore.ToString('g')
            NotAfter = $cert.NotAfter.ToString('g')
            SerialNumber = $cert.SerialNumber
            SignatureAlgorithm = $cert.SignatureAlgorithm.FriendlyName
            SAN = ($sans -join ' | ')
        }
    } catch {
        throw "Sertifika okunamadi. Hata: $($_.Exception.Message)"
    }
}
