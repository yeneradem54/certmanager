﻿function ConvertTo-PSCMSafeString {
<#
.SYNOPSIS
Log icin secret pattern'lerini maskeler.
#>
    [CmdletBinding()]
    param([Parameter(Mandatory,ValueFromPipeline)][string]$Text)
    process {
        $t = $Text
        $t = [regex]::Replace($t,'-----BEGIN[^-]+PRIVATE KEY-----[\s\S]*?-----END[^-]+PRIVATE KEY-----','[***MASKED-PRIVATE-KEY***]')
        $t = [regex]::Replace($t,'(?i)(password|pwd|secret|token|apikey|api_key)\s*[:=]\s*[^\s,;}]+','$1=[***MASKED***]')
        return $t
    }
}
