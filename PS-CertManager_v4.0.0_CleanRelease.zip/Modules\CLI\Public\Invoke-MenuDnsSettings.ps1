function Invoke-MenuDnsSettings {
    [CmdletBinding()]
    param()

    while ($true) {
        Show-PSCMBanner
        Write-Host '  --- DNS & ACME PROVIDER AYARLARI ---' -ForegroundColor Yellow
        Write-Host ''

        try {
            $acme = Get-PSSettings -Section 'Acme'
            $currentDns = 'Azure'
            if ($acme.PSObject.Properties.Name -contains 'DnsPlugin' -and -not [string]::IsNullOrWhiteSpace($acme.DnsPlugin)) { $currentDns = $acme.DnsPlugin }
            $currentCA  = 'LetsEncrypt'
            if ($acme.PSObject.Properties.Name -contains 'Provider' -and -not [string]::IsNullOrWhiteSpace($acme.Provider)) { $currentCA = $acme.Provider }

            Write-Host "  Mevcut ACME Provider (CA): " -NoNewline; Write-Host $currentCA -ForegroundColor Cyan
            Write-Host "  Mevcut DNS Provider      : " -NoNewline; Write-Host $currentDns -ForegroundColor Cyan
            Write-Host ''
            Write-Host '  [1] ACME Provider Degistir (LetsEncrypt, ZeroSSL vb.)' -ForegroundColor White
            Write-Host '  [2] DNS Provider Degistir (Azure, Cloudflare, Route53, GoDaddy)' -ForegroundColor White
            Write-Host '  [3] Cloudflare API Token Kaydet / Guncelle' -ForegroundColor White
            Write-Host '  [4] AWS Route53 Access/Secret Key Kaydet / Guncelle' -ForegroundColor White
            Write-Host '  [5] GoDaddy API Key/Secret Kaydet / Guncelle' -ForegroundColor White
            Write-Host ''
            Write-Host '  Enter) Ana Menuye Don' -ForegroundColor DarkGray
            Write-Host ''
            
            $choice = Read-Host 'Seciminiz'
            switch ($choice) {
                ''  { return }
                '1' {
                    Write-Host 'Kullanilabilir ACME Provider (CA) Secenekleri:'
                    Write-Host '1) LetsEncrypt (Uretim)'
                    Write-Host '2) LetsEncryptStaging (Test)'
                    Write-Host '3) ZeroSSL'
                    $caChoice = Read-Host 'Seciminiz (1/2/3)'
                    $newCa = $null
                    if ($caChoice -eq '1') { $newCa = 'LetsEncrypt' }
                    elseif ($caChoice -eq '2') { $newCa = 'LetsEncryptStaging' }
                    elseif ($caChoice -eq '3') { $newCa = 'ZeroSSL' }

                    if ($newCa) {
                        if ($acme.PSObject.Properties.Name -contains 'Provider') { $acme.Provider = $newCa }
                        else { $acme | Add-Member -NotePropertyName 'Provider' -NotePropertyValue $newCa }
                        Set-PSSettings -Section 'Acme' -Value $acme
                        Write-Host "ACME Provider $newCa olarak guncellendi!" -ForegroundColor Green
                    }
                    Pause-PSCM
                }
                '2' {
                    Write-Host 'Kullanilabilir DNS Provider Secenekleri:'
                    Write-Host '1) Azure'
                    Write-Host '2) Cloudflare'
                    Write-Host '3) Route53'
                    Write-Host '4) GoDaddy'
                    $dnsChoice = Read-Host 'Seciminiz (1/2/3/4)'
                    $newDns = $null
                    if ($dnsChoice -eq '1') { $newDns = 'Azure' }
                    elseif ($dnsChoice -eq '2') { $newDns = 'Cloudflare' }
                    elseif ($dnsChoice -eq '3') { $newDns = 'Route53' }
                    elseif ($dnsChoice -eq '4') { $newDns = 'GoDaddy' }

                    if ($newDns) {
                        if ($acme.PSObject.Properties.Name -contains 'DnsPlugin') { $acme.DnsPlugin = $newDns }
                        else { $acme | Add-Member -NotePropertyName 'DnsPlugin' -NotePropertyValue $newDns }
                        Set-PSSettings -Section 'Acme' -Value $acme
                        Write-Host "DNS Provider $newDns olarak guncellendi!" -ForegroundColor Green
                    }
                    Pause-PSCM
                }
                '3' {
                    $token = Read-Host 'Cloudflare API Token Giriniz'
                    if (-not [string]::IsNullOrWhiteSpace($token)) {
                        $sec = ConvertTo-SecureString $token -AsPlainText -Force
                        Set-PSCMSecret -Name 'Cloudflare.Token' -Secret $sec
                        Write-Host 'Cloudflare API Token basariyla kasaya kaydedildi.' -ForegroundColor Green
                    }
                    Pause-PSCM
                }
                '4' {
                    $access = Read-Host 'AWS Route53 Access Key Giriniz'
                    $secret = Read-Host 'AWS Route53 Secret Key Giriniz'
                    if (-not [string]::IsNullOrWhiteSpace($access) -and -not [string]::IsNullOrWhiteSpace($secret)) {
                        Set-PSCMSecret -Name 'Route53.AccessKey' -Secret (ConvertTo-SecureString $access -AsPlainText -Force)
                        Set-PSCMSecret -Name 'Route53.SecretKey' -Secret (ConvertTo-SecureString $secret -AsPlainText -Force)
                        Write-Host 'AWS Route53 anahtarlari basariyla kasaya kaydedildi.' -ForegroundColor Green
                    }
                    Pause-PSCM
                }
                '5' {
                    $key = Read-Host 'GoDaddy API Key Giriniz'
                    $secret = Read-Host 'GoDaddy API Secret Giriniz'
                    if (-not [string]::IsNullOrWhiteSpace($key) -and -not [string]::IsNullOrWhiteSpace($secret)) {
                        Set-PSCMSecret -Name 'GoDaddy.Key' -Secret (ConvertTo-SecureString $key -AsPlainText -Force)
                        Set-PSCMSecret -Name 'GoDaddy.Secret' -Secret (ConvertTo-SecureString $secret -AsPlainText -Force)
                        Write-Host 'GoDaddy anahtarlari basariyla kasaya kaydedildi.' -ForegroundColor Green
                    }
                    Pause-PSCM
                }
                '0' { return }
                default { Write-Host 'Gecersiz secim!' -ForegroundColor Red; Pause-PSCM }
            }
        } catch {
            Write-Host ("Hata: " + $_.Exception.Message) -ForegroundColor Red
            Pause-PSCM
        }
    }
}
