function Export-PSCMSslPrivateKey {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$PfxPath,
        [Parameter(Mandatory=$true)][System.Security.SecureString]$PfxPass,
        [Parameter(Mandatory=$true)][string]$OutFolder
    )
    if (-not (Test-Path $PfxPath)) { throw "PFX dosyasi bulunamadi: $PfxPath" }
    if (-not (Test-Path $OutFolder)) { New-Item -ItemType Directory -Path $OutFolder -Force | Out-Null }
    
    if (Get-Command openssl -ErrorAction SilentlyContinue) {
        Write-PSCMLog -Level INFO -Message "OpenSSL ile PFX icerisinden key cikariliyor: $PfxPath" -Source 'SSLTools'
        $plainPass = (New-Object System.Management.Automation.PSCredential("x", $PfxPass)).GetNetworkCredential().Password
        $keyDest = Join-Path $OutFolder "private.key"
        $certDest = Join-Path $OutFolder "cert.pem"
        
        $osslVer = & openssl version
        $legacyArgs = ""
        if ($osslVer -match "OpenSSL [345]\.") {
            $legacyArgs = " -legacy"
        }
        
        # Export private key
        $argsKey = "pkcs12 -in `"$PfxPath`" -nocerts -nodes -passin pass:$plainPass -out `"$keyDest`"$legacyArgs"
        $p1 = Start-Process openssl -ArgumentList $argsKey -Wait -NoNewWindow -PassThru
        
        # Export cert
        $argsCert = "pkcs12 -in `"$PfxPath`" -clcerts -nokeys -passin pass:$plainPass -out `"$certDest`"$legacyArgs"
        $p2 = Start-Process openssl -ArgumentList $argsCert -Wait -NoNewWindow -PassThru
        
        if ($p1.ExitCode -eq 0 -and $p2.ExitCode -eq 0 -and (Test-Path $keyDest) -and (Test-Path $certDest)) {
            Write-PSCMLog -Level INFO -Message "Sifresiz Private Key ve Sertifika basariyla cikarildi." -Source 'SSLTools'
            return [PSCustomObject]@{ Key = $keyDest; Cert = $certDest }
        }
        throw "openssl islem sirasinda hata dondurdu."
    } else {
        throw "PFX icerisinden sifresiz Private Key cikarabilmek icin 'openssl' komutu gereklidir."
    }
}
