﻿#Requires -Version 5.1
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'
$script:PSCMSettingsFile = 'settings.json'
Get-ChildItem -Path (Join-Path $PSScriptRoot 'Public') -Filter '*.ps1' -EA SilentlyContinue | ForEach-Object { . $_.FullName }
Export-ModuleMember -Function @('Get-PSSettings','Set-PSSettings','Initialize-PSCMSettings')
