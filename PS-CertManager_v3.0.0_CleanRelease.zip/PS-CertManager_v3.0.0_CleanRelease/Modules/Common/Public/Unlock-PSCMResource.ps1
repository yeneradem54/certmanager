﻿function Unlock-PSCMResource {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Name)
    $lockFile = Join-Path (Join-Path (Get-PSCMPath -Name Temp) 'locks') "$Name.lock"
    if (Test-Path -LiteralPath $lockFile) {
        Remove-Item -LiteralPath $lockFile -Force -ErrorAction SilentlyContinue
    }
}
