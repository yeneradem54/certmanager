function Set-PSCMState {
<#
.SYNOPSIS
Sistem durumunu kaydeder (v3 Data Access Layer).
.DESCRIPTION
SQLite veritabaninda Transaction (Toplu Islem) kullanarak yuksek performansli yazma yapar.
.EXAMPLE
Set-PSCMState -Table 'certificates' -Data $certArray
#>
    [CmdletBinding()]
    param(
        [string]$Table = 'certificates',
        [Parameter(Mandatory)][object]$Data
    )
    
    try {
        Initialize-PSCMSQLite
        $dbPath = Join-Path (Get-PSCMPath -Name State) "pscm.db"
        
        if ($Table -eq 'certificates') {
            Import-Module PSSQLite -ErrorAction Stop
            # PSSQLite altinda System.Data.SQLite namespace yuklenmis oluyor.
            $connString = "Data Source=$dbPath"
            $conn = New-Object System.Data.SQLite.SQLiteConnection($connString)
            $conn.Open()
            $cmd = $conn.CreateCommand()
            $tx = $conn.BeginTransaction()
            try {
                $cmd.CommandText = "DELETE FROM certificates"
                $cmd.ExecuteNonQuery() | Out-Null
                
                if ($Data) {
                    $cmd.CommandText = "INSERT INTO certificates (Domain, Wildcard, Issuer, Thumbprint, NotBefore, NotAfter, FriendlyName, Path, SourceFolder, CreatedAt, RenewedAt) VALUES (@Domain, @Wildcard, @Issuer, @Thumbprint, @NotBefore, @NotAfter, @FriendlyName, @Path, @SourceFolder, @CreatedAt, @RenewedAt)"
                    
                    @('Domain','Wildcard','Issuer','Thumbprint','NotBefore','NotAfter','FriendlyName','Path','SourceFolder','CreatedAt','RenewedAt') | ForEach-Object {
                        $cmd.Parameters.AddWithValue("@$_", $null) | Out-Null
                    }
                    
                    foreach ($c in @($Data)) {
                        if ($null -eq $c) { continue }
                        $cProps = if ($null -ne $c.PSObject -and $null -ne $c.PSObject.Properties) { @($c.PSObject.Properties.Name) } else { @() }
                        $wc = if ($cProps -contains 'Wildcard' -and $c.Wildcard) { 1 } else { 0 }
                        $cmd.Parameters["@Domain"].Value = if ($cProps -contains 'Domain') { $c.Domain } else { [DBNull]::Value }
                        $cmd.Parameters["@Wildcard"].Value = $wc
                        $cmd.Parameters["@Issuer"].Value = if ($cProps -contains 'Issuer') { $c.Issuer } else { [DBNull]::Value }
                        $cmd.Parameters["@Thumbprint"].Value = if ($cProps -contains 'Thumbprint') { $c.Thumbprint } else { [DBNull]::Value }
                        $cmd.Parameters["@NotBefore"].Value = if ($cProps -contains 'NotBefore') { $c.NotBefore } else { [DBNull]::Value }
                        $cmd.Parameters["@NotAfter"].Value = if ($cProps -contains 'NotAfter') { $c.NotAfter } else { [DBNull]::Value }
                        $cmd.Parameters["@FriendlyName"].Value = if ($cProps -contains 'FriendlyName') { $c.FriendlyName } else { [DBNull]::Value }
                        $cmd.Parameters["@Path"].Value = if ($cProps -contains 'Path') { $c.Path } else { [DBNull]::Value }
                        $cmd.Parameters["@SourceFolder"].Value = if ($cProps -contains 'SourceFolder') { $c.SourceFolder } else { [DBNull]::Value }
                        $cmd.Parameters["@CreatedAt"].Value = if ($cProps -contains 'CreatedAt') { $c.CreatedAt } else { [DBNull]::Value }
                        $cmd.Parameters["@RenewedAt"].Value = if ($cProps -contains 'RenewedAt') { $c.RenewedAt } else { [DBNull]::Value }
                        $cmd.ExecuteNonQuery() | Out-Null
                    }
                }
                $tx.Commit()
            } catch {
                if ($tx) { $tx.Rollback() }
                throw
            } finally {
                if ($conn) { $conn.Close() }
            }
        }
    } catch {
        Write-PSCMLog -Level ERROR -Message ("Set-PSCMState hatasi: " + $_.Exception.Message) -Source 'State'
    }
}
