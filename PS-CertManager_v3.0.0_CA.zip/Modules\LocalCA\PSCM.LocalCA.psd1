@{
    RootModule = 'PSCM.LocalCA.psm1'
    ModuleVersion = '1.0.0'
    GUID = 'eeeeeeee-1111-2222-3333-444444444444'
    Author = 'PS-CertManager Ekibi'
    CompanyName = 'PS-CertManager'
    Copyright = '(c) 2026 PS-CertManager. Tum haklari saklidir.'
    Description = 'Local CA (Windows ADCS) Provider'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Invoke-PSCMLocalCACertificateRequest')
    CmdletsToExport = @()
    VariablesToExport = @()
    AliasesToExport = @()
}
