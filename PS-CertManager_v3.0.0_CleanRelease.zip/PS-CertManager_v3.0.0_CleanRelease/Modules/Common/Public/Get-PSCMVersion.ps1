function Get-PSCMVersion {
<#
.SYNOPSIS
Sistem surum bilgisi.
#>
    [CmdletBinding()]
    param()
    $manifest = Join-Path (Get-PSCMRootPath) 'PSCertManager.psd1'
    if (Test-Path -LiteralPath $manifest) {
        $data = Import-PowerShellDataFile -LiteralPath $manifest
        return [PSCustomObject]@{
            Version     = '3.0.0'
            ReleaseDate = '2026'
            Status      = 'Stable'
            PSVersion   = $PSVersionTable.PSVersion.ToString()
            PSEdition   = $PSVersionTable.PSEdition
            Root        = Get-PSCMRootPath
        }
    }
    return [PSCustomObject]@{ Version = '3.0.0'; PSVersion = $PSVersionTable.PSVersion.ToString() }
}
