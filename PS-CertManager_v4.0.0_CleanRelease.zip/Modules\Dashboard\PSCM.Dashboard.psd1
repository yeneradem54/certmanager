@{
    RootModule = 'PSCM.Dashboard.psm1'
    ModuleVersion = '4.0.0'
    GUID = 'eac9a4be-8b07-4ba5-ba69-029443430935'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager HTML Dashboard Modulu'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Get-PSDashboard','New-PSDashboard')
}
