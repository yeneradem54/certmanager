﻿@{
    RootModule = 'PSCM.Settings.psm1'
    ModuleVersion = '2.1.0'
    GUID = '44444444-4444-4444-4444-444444444444'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager Yapilandirma Modulu'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Get-PSSettings','Set-PSSettings','Initialize-PSCMSettings')
}
