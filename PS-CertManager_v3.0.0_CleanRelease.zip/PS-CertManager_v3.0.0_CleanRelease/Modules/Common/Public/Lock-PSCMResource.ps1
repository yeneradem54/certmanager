﻿function Lock-PSCMResource {
<#
.SYNOPSIS
Kilit dosyasi olusturur (mutex).
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Name,
        [int]$TimeoutSec = 30
    )
    $lockDir = Join-Path (Get-PSCMPath -Name Temp) 'locks'
    if (-not (Test-Path $lockDir)) { New-Item -ItemType Directory -Path $lockDir -Force | Out-Null }
    $lockFile = Join-Path $lockDir "$Name.lock"
    $start = Get-Date
    while (Test-Path -LiteralPath $lockFile) {
        if ((Get-Date) - $start -gt (New-TimeSpan -Seconds $TimeoutSec)) {
            throw (New-Object PSCMException("Kilit zaman asimi: $Name",'Kilit','PSCM-0100'))
        }
        Start-Sleep -Milliseconds 500
    }
    $info = @{ Pid = $PID; TimeStamp = (Get-Date).ToString('o'); User = $env:USERNAME }
    ($info | ConvertTo-Json -Compress) | Set-Content -LiteralPath $lockFile -Encoding UTF8
    return $lockFile
}
