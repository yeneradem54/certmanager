#Requires -Version 5.1
<#
.SYNOPSIS
PS-CertManager v4.0.0 CLI baslangic dosyasi.
#>
[CmdletBinding()]
param()
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'

# Yonetici yetkisi kontrolü ve zorlama
$isAdmin = try {
    $id = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object System.Security.Principal.WindowsPrincipal($id)
    $p.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
} catch { $false }

if (-not $isAdmin) {
    Write-Host "UYARI: Bu script yonetici yetkileri ile calismalidir." -ForegroundColor Yellow
    Write-Host "Script yonetici yetkileriyle yeniden baslatiliyor..." -ForegroundColor Cyan
    $hostProcess = if ($PSVersionTable.PSVersion.Major -ge 6) { 'pwsh.exe' } else { 'powershell.exe' }
    $myPath = $MyInvocation.MyCommand.Path
    try {
        Start-Process $hostProcess -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$myPath`"" -Verb RunAs
    } catch {
        Write-Host "HATA: Yonetici yetkisi ile baslatilamadi. Lutfen scripti Yonetici olarak calistirin." -ForegroundColor Red
        Write-Host "Devam etmek icin bir tusa basin..." -ForegroundColor DarkGray
        [void][System.Console]::ReadKey($true)
    }
    Exit
}

try {
    chcp 65001 | Out-Null
    [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new()
    [Console]::InputEncoding  = [System.Text.UTF8Encoding]::new()
    $OutputEncoding           = [System.Text.UTF8Encoding]::new()
} catch { }

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$env:PSCM_ROOT = $here
$manifest = Join-Path $here 'Modules\PSCertManager\PSCertManager.psd1'
if (-not (Test-Path -LiteralPath $manifest)) {
    Write-Host ('PSCertManager.psd1 bulunamadi: ' + $manifest) -ForegroundColor Red
    exit 1
}
try {
    Import-Module $manifest -Force -DisableNameChecking -ErrorAction Stop
} catch {
    Write-Host ""
    Write-Host "Kritik Hata: Modul yuklenemedi!" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Devam etmek icin bir tusa basin..." -ForegroundColor DarkGray
    [void][System.Console]::ReadKey($true)
    Exit
}

# Ilk Kurulum (First-Run) ve Otomatik Onarim Mantigi
try {
    $settings = Get-PSSettings
    $isConfig = $false
    $isConfig = $false
    if ($settings -and ($settings.PSObject.Properties['General'] -ne $null)) {
        if ($settings.General -and ($settings.General.PSObject.Properties['IsConfigured'] -ne $null)) {
            if ($settings.General.IsConfigured -eq $true) { $isConfig = $true }
        }
    }
    if (-not $isConfig) {
        Clear-Host
        Write-Host "============================================================" -ForegroundColor Cyan
        Write-Host " PS-CertManager v4.0.0 Ilk Kurulum Sihirbazina Hosgeldiniz! " -ForegroundColor Cyan
        Write-Host "============================================================" -ForegroundColor Cyan
        Write-Host "`nEksik bagimliliklar ve klasorler kontrol ediliyor..." -ForegroundColor Yellow
        $infra = Get-PSInfrastructure
        $missingModules = $infra | Where-Object { $_.Kategori -eq 'Modul' -and $_.Durum -eq 'EKSIK' }
        $missingFolders = $infra | Where-Object { $_.Kategori -eq 'Klasor' -and $_.Durum -eq 'HATA' }
        if ($missingModules -or $missingFolders) {
            Write-Host "Eksik bilesenler tespit edildi. Otomatik onarim baslatiliyor..." -ForegroundColor Yellow
            Repair-PSInfrastructure -Force -NoInteractive | Out-Null
            Write-Host "Bagimliliklar basariyla kuruldu." -ForegroundColor Green
        }
        
        Write-Host "`nSistem ayarlari (Azure, Vault vb.) yapilandiriliyor..." -ForegroundColor Yellow
        Start-PSCMConfigWizard
        
        $settings = Get-PSSettings
        if ($settings.PSObject.Properties['General'] -eq $null) {
            $settings | Add-Member -MemberType NoteProperty -Name "General" -Value [PSCustomObject]@{ IsConfigured = $true } -Force
        } else {
            $settings.General | Add-Member -MemberType NoteProperty -Name "IsConfigured" -Value $true -Force
        }
        Write-PSCMJson -Path (Join-Path (Get-PSCMPath -Name Config) 'settings.json') -InputObject $settings
        
        Write-Host "`nIlk kurulum basariyla tamamlandi! Sisteme giris yapiliyor..." -ForegroundColor Green
        Start-Sleep -Seconds 2
    }
} catch {
    Write-Host ''
    Write-Host '  [HATA] Ilk kurulum sirasinda beklenmeyen bir hata olustu:' -ForegroundColor Red
    Write-Host ("  " + $_.Exception.Message) -ForegroundColor Yellow
    Write-Host ''
    Write-Host '  Eksik yapilandirma ile devam etmek bazi islemlerin calismamasina neden olabilir.' -ForegroundColor DarkYellow
    $cont = Read-Host '  Yine de devam edilsin mi? [E/H]'
    if ($cont -notmatch '^[EeYy]') { Exit 1 }
}

$vaultOk = $false
try { $vaultOk = Unlock-PSCMSecretStore -Silent } catch { }
if (-not $vaultOk) {
    Write-Host ''
    Write-Host '  [UYARI] Guvenli kasa (SecretStore vault) acilamamadi.' -ForegroundColor Yellow
    Write-Host '  Azure Client Secret, SMTP sifresi ve diger gizli bilgiler kullanilamayabilir.' -ForegroundColor DarkYellow
    Write-Host '  Cozum: Ayarlar > Guvenlik menusu ile vault yapilandirmasini kontrol edin.' -ForegroundColor DarkGray
    Write-Host ''
}

$running = $true
while ($running) {
    Show-PSCMMenu
    $choice = (Read-Host 'Secim').Trim().ToUpper()
    switch ($choice) {
        '1' { Invoke-MenuCertificates }
        'L' { Invoke-MenuCertificates }
        '2' { Invoke-MenuNewCertificate }
        'N' { Invoke-MenuNewCertificate }
        '3' { Invoke-MenuDashboard }
        'W' { Invoke-MenuDashboard }
        '4' { Invoke-SubMenuAutomation }
        'K' { Invoke-SubMenuAutomation }
        '5' { Invoke-MenuDeployments }
        'D' { Invoke-MenuDeployments }
        '6' { Invoke-MenuSslTools }
        'S' { Invoke-MenuSslTools }
        '7' { Invoke-SubMenuSettings }
        'C' { Invoke-SubMenuSettings }
        '8' { Invoke-SubMenuMaintenance }
        'M' { Invoke-SubMenuMaintenance }
        '0' { $running = $false }
        'X' { $running = $false }
        ''  { }
        default { Write-Host 'Gecersiz secim.' -ForegroundColor Red; Start-Sleep -Milliseconds 800 }
    }
}
Write-Host ''
Write-Host 'PS-CertManager kapatildi.' -ForegroundColor Cyan
