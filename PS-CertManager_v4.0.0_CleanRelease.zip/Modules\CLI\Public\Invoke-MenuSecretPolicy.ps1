function Invoke-MenuSecretPolicy {
    Show-PSCMBanner
    Write-Host '  --- SECRETSTORE POLITIKASI ---' -ForegroundColor Yellow
    Write-Host ''
    Write-Host '  [1] Session   - Oturum boyu (8 saat) acik. (Onerilen)' -ForegroundColor White
    Write-Host '  [2] None      - Hicbir zaman sormaz. DPAPI korumali.' -ForegroundColor White
    Write-Host '  [3] Strict    - Varsayilan (Her 15 dakikada bir sifre ister).' -ForegroundColor White
    Write-Host '  [4] Simdi Kasa Kilidini Ac' -ForegroundColor White
    Write-Host ''
    Write-Host '  Enter) Ana Menuye Don' -ForegroundColor DarkGray
    Write-Host ''
    $sel = Read-Host 'Secim'
    switch ($sel) {
        '1' {
            $hIn = Read-Host 'Timeout kac saat? [8]'
            $h = 8
            if ($hIn) { [int]::TryParse($hIn,[ref]$h) | Out-Null }
            try { Set-PSCMSecretStorePolicy -Policy Session -TimeoutHours $h }
            catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
        }
        '2' { try { Set-PSCMSecretStorePolicy -Policy None } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red } }
        '3' { try { Set-PSCMSecretStorePolicy -Policy Strict } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red } }
        '4' { try { Unlock-PSCMSecretStore | Out-Null } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red } }
    }
    Pause-PSCM
}
