#Requires -Version 5.1
<#
.SYNOPSIS
PS-CertManager v2.3.1 CLI baslangic dosyasi.
#>
[CmdletBinding()]
param()
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'

# Yonetici yetkisi kontrolü ve zorlama
$isAdmin = try {
    $id = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object System.Security.Principal.WindowsPrincipal($id)
    $p.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
} catch { $false }

if (-not $isAdmin) {
    Write-Host "UYARI: Bu script yonetici yetkileri ile calismalidir." -ForegroundColor Yellow
    Write-Host "Script yonetici yetkileriyle yeniden baslatiliyor..." -ForegroundColor Cyan
    $hostProcess = if ($PSVersionTable.PSVersion.Major -ge 6) { 'pwsh.exe' } else { 'powershell.exe' }
    $myPath = $MyInvocation.MyCommand.Path
    try {
        Start-Process $hostProcess -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$myPath`"" -Verb RunAs
    } catch {
        Write-Host "HATA: Yonetici yetkisi ile baslatilamadi. Lutfen scripti Yonetici olarak calistirin." -ForegroundColor Red
        Write-Host "Devam etmek icin bir tusa basin..." -ForegroundColor DarkGray
        [void][System.Console]::ReadKey($true)
    }
    Exit
}

try {
    chcp 65001 | Out-Null
    [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new()
    [Console]::InputEncoding  = [System.Text.UTF8Encoding]::new()
    $OutputEncoding           = [System.Text.UTF8Encoding]::new()
} catch { }

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$env:PSCM_ROOT = $here
$manifest = Join-Path $here 'Modules\PSCertManager\PSCertManager.psd1'
if (-not (Test-Path -LiteralPath $manifest)) {
    Write-Host ('PSCertManager.psd1 bulunamadi: ' + $manifest) -ForegroundColor Red
    exit 1
}
Import-Module $manifest -Force -DisableNameChecking -ErrorAction Stop

# Ilk Kurulum (First-Run) ve Otomatik Onarim Mantigi
try {
    $settings = Get-PSSettings
    $isConfig = $false
    if ($settings.psobject.Properties.Match('General').Count -gt 0) {
        if ($settings.General.psobject.Properties.Match('IsConfigured').Count -gt 0) {
            if ($settings.General.IsConfigured -eq $true) { $isConfig = $true }
        }
    }
    if (-not $isConfig) {
        Clear-Host
        Write-Host "============================================================" -ForegroundColor Cyan
        Write-Host " PS-CertManager v3 Ilk Kurulum Sihirbazina Hosgeldiniz! " -ForegroundColor Cyan
        Write-Host "============================================================" -ForegroundColor Cyan
        Write-Host "`nEksik bagimliliklar ve klasorler kontrol ediliyor..." -ForegroundColor Yellow
        $infra = Get-PSInfrastructure
        $missingModules = $infra | Where-Object { $_.Kategori -eq 'Modul' -and $_.Durum -eq 'EKSIK' }
        $missingFolders = $infra | Where-Object { $_.Kategori -eq 'Klasor' -and $_.Durum -eq 'HATA' }
        if ($missingModules -or $missingFolders) {
            Write-Host "Eksik bilesenler tespit edildi. Otomatik onarim baslatiliyor..." -ForegroundColor Yellow
            Repair-PSInfrastructure -Force -NoInteractive | Out-Null
            Write-Host "Bagimliliklar basariyla kuruldu." -ForegroundColor Green
        }
        
        Write-Host "`nSistem ayarlari (Azure, Vault vb.) yapilandiriliyor..." -ForegroundColor Yellow
        Start-PSCMConfigWizard
        
        $settings = Get-PSSettings
        if ($settings.psobject.Properties.Match('General').Count -eq 0) {
            $settings | Add-Member -MemberType NoteProperty -Name "General" -Value [PSCustomObject]@{ IsConfigured = $true } -Force
        } else {
            $settings.General | Add-Member -MemberType NoteProperty -Name "IsConfigured" -Value $true -Force
        }
        Write-PSCMJson -Path (Join-Path (Get-PSCMPath -Name Config) 'settings.json') -InputObject $settings
        
        Write-Host "`nIlk kurulum basariyla tamamlandi! Sisteme giris yapiliyor..." -ForegroundColor Green
        Start-Sleep -Seconds 2
    }
} catch {
    Write-Host ("Ilk kurulum sirasinda hata olustu: " + $_.Exception.Message) -ForegroundColor Red
    Start-Sleep -Seconds 3
}

try { Unlock-PSCMSecretStore -Silent | Out-Null } catch { }

function Show-PSCMBanner {
    Clear-Host
    $ver = try { (Get-PSCMVersion).Version } catch { '3.0.0' }
    Write-Host ''
    Write-Host '============================================================' -ForegroundColor Cyan
    Write-Host ('  PS-CertManager v' + $ver) -ForegroundColor Cyan
    Write-Host '  Certificate Lifecycle Management Framework' -ForegroundColor Gray
    Write-Host '============================================================' -ForegroundColor Cyan
    Write-Host ''
}

function Show-PSCMMenu {
    Show-PSCMBanner
    
    $menu = @(
        @{ Header='--- PS-CERTMANAGER ANA MENU ---' }
        @{ Id='1'; Text='Canli Web Dashboard & API Baslat'; Color='Cyan' }
        @{ Id='2'; Text='Sertifika Operasyonlari'; Color='Cyan' }
        @{ Id='3'; Text='Otomasyon (Gorev Zamanlayici)'; Color='Cyan' }
        @{ Id='4'; Text='Sistem Ayarlari & Guvenlik'; Color='Cyan' }
        @{ Id='5'; Text='Bakim & Loglar'; Color='Cyan' }
        @{ Header='' }
        @{ Id='0'; Text='Cikis'; Color='White' }
    )

    foreach ($item in $menu) {
        if ($item.ContainsKey('Header')) {
            Write-Host ('  ' + $item.Header) -ForegroundColor Cyan
        } else {
            $idPad = $item.Id.PadLeft(2)
            Write-Host ('  ' + $idPad + ') ') -ForegroundColor Yellow -NoNewline
            Write-Host $item.Text -ForegroundColor $item.Color
        }
    }
    Write-Host ''
}

function Pause-PSCM {
    Write-Host ''
    Write-Host 'Devam etmek icin bir tusa basin...' -ForegroundColor DarkGray
    [void][System.Console]::ReadKey($true)
}

function Invoke-MenuLocalCAPermissions {
    Clear-Host
    Show-PSCMBanner
    Write-Host '>> Local CA (ADCS) Izin ve Yetki Yonetimi' -ForegroundColor Yellow
    Write-Host ''
    
    $cred = $null
    $templates = @()
    
    try {
        Write-Host "Active Directory ortamindaki sertifika sablonlari taranirken lutfen bekleyin..." -ForegroundColor Cyan
        $rootDse = [ADSI]"LDAP://RootDSE"
        $configContext = $rootDse.Properties["configurationNamingContext"].Value
        if (-not $configContext) { throw "RootDSE erisimi basarisiz." }
        
        $templatePath = "LDAP://CN=Certificate Templates,CN=Public Key Services,CN=Services,$configContext"
        $templatesContainer = [ADSI]$templatePath
        
        # Sadece okumayi test etmek icin child kontrolu
        $childCount = $templatesContainer.Children.Count
    } catch {
        Write-Host ""
        Write-Host "Mevcut kullanici yetkilerinizle ADCS sablonlari okunamadi veya erisim reddedildi." -ForegroundColor Yellow
        Write-Host "Lutfen Root Domain (Kök Alan Adi) yetkili hesabinizin (Domain Admin vb.) bilgilerini girin." -ForegroundColor White
        Write-Host ""
        $cred = Get-Credential -Message "Active Directory Erisimi - Yetkili Hesap"
        if (-not $cred) { return }
        
        try {
            Write-Host "Yetkili hesap ile tekrar baglaniliyor..." -ForegroundColor Cyan
            $rootDse = New-Object System.DirectoryServices.DirectoryEntry("LDAP://RootDSE", $cred.UserName, $cred.GetNetworkCredential().Password)
            $configContext = $rootDse.Properties["configurationNamingContext"].Value
            $templatePath = "LDAP://CN=Certificate Templates,CN=Public Key Services,CN=Services,$configContext"
            $templatesContainer = New-Object System.DirectoryServices.DirectoryEntry($templatePath, $cred.UserName, $cred.GetNetworkCredential().Password)
        } catch {
            Write-Host "Girilen yetkili hesapla da baglanti kurulamadi: $_" -ForegroundColor Red
            Pause-PSCM
            return
        }
    }
    
    foreach ($child in $templatesContainer.Children) {
        $tName = $child.Name
        $tDisp = $child.Properties["displayName"].Value
        if (-not $tDisp) { $tDisp = $tName }
        $templates += [PSCustomObject]@{ Name = $tName; DisplayName = $tDisp }
    }
    
    if ($templates.Count -eq 0) {
        Write-Host "Active Directory icerisinde hicbir sertifika sablonu bulunamadi." -ForegroundColor Red
        Pause-PSCM
        return
    }
    
    $templates = $templates | Sort-Object DisplayName
    
    Clear-Host
    Show-PSCMBanner
    Write-Host '>> Local CA (ADCS) Izin ve Yetki Yonetimi' -ForegroundColor Yellow
    Write-Host ''
    Write-Host "Asagidaki listeden erisim izni (Enroll) tanimlanacak sablonun numarasini secin:" -ForegroundColor White
    Write-Host ''
    
    for ($i = 0; $i -lt $templates.Count; $i++) {
        Write-Host ("  {0,2}) {1} ({2})" -f ($i+1), $templates[$i].DisplayName, $templates[$i].Name)
    }
    Write-Host ''
    Write-Host '  0) Iptal / Cikis' -ForegroundColor DarkGray
    Write-Host ''
    
    $selection = Read-Host "Sablon Numarasi [1-$($templates.Count)]"
    if ($selection -eq '0' -or -not $selection) { return }
    
    $idx = 0
    if (-not ([int]::TryParse($selection, [ref]$idx)) -or $idx -lt 1 -or $idx -gt $templates.Count) {
        Write-Host "Gecersiz secim!" -ForegroundColor Red
        Pause-PSCM
        return
    }
    
    $selectedTemplate = $templates[$idx-1].Name
    
    try {
        Write-Host "Yetkilendirme basliyor: $selectedTemplate" -ForegroundColor Cyan
        if ($cred) {
            Repair-PSCMLocalCAPermissions -TemplateName $selectedTemplate -Credential $cred
        } else {
            Repair-PSCMLocalCAPermissions -TemplateName $selectedTemplate
        }
        Write-Host "Islem basariyla tamamlandi!" -ForegroundColor Green
    } catch {
        # Catch unauthorized access for write
        Write-Host "Mevcut hesabin okuma yetkisi vardi ancak yazma yetkisi YOK (Erisim Reddedildi)!" -ForegroundColor Yellow
        $cred = Get-Credential -Message "Sablon Guncelleme Icin Root Domain Admin Bilgilerini Girin"
        if (-not $cred) { return }
        try {
            Repair-PSCMLocalCAPermissions -TemplateName $selectedTemplate -Credential $cred
            Write-Host "Islem basariyla tamamlandi!" -ForegroundColor Green
        } catch {
            Write-Host "Hata: $_" -ForegroundColor Red
        }
    }
    Pause-PSCM
}

# v2.3.1: $Input rezerve degisken -> $RangeText olarak yeniden adlandirildi.
function ConvertFrom-PSCMRangeString {
    param(
        [string]$RangeText,
        [int]$Max
    )
    if (-not $RangeText) { return @() }
    $t = $RangeText.Trim()
    if ($t -match '^[Aa]$') { return @(1..$Max) }
    $result = New-Object System.Collections.Generic.List[int]
    foreach ($part in $t.Split(',')) {
        $p = $part.Trim()
        if (-not $p) { continue }
        if ($p -match '^\s*(\d+)\s*-\s*(\d+)\s*$') {
            $s = [int]$matches[1]; $e = [int]$matches[2]
            if ($s -gt $e) { $tmp = $s; $s = $e; $e = $tmp }
            for ($i = $s; $i -le $e; $i++) {
                if ($i -ge 1 -and $i -le $Max) { [void]$result.Add($i) }
            }
        } elseif ($p -match '^\d+$') {
            $n = [int]$p
            if ($n -ge 1 -and $n -le $Max) { [void]$result.Add($n) }
        }
    }
    return @($result | Sort-Object -Unique)
}

function Invoke-PSCMSingleCertAction {
    param(
        [Parameter(Mandatory)][ValidateSet('Y','E','D','R','S','T','Q')][string]$Action,
        [Parameter(Mandatory)][PSCustomObject]$Cert,
        [string]$ExportDest,
        [System.Security.SecureString]$RepairPass
    )
    $dom = [string]$Cert.Domain
    try {
        switch ($Action) {
            'Y' {
                Write-Host ('  -> Yenile: ' + $dom) -ForegroundColor Cyan
                Update-PSCertificate -Domain $dom -Confirm:$false | Out-Null
                Write-Host ('     [OK] Yenilendi.') -ForegroundColor Green
            }
            'E' {
                Write-Host ('  -> Export: ' + $dom + ' -> ' + $ExportDest) -ForegroundColor Cyan
                Export-PSCertificate -Domain $dom -Destination $ExportDest -Format all | Out-Null
                Write-Host ('     [OK] Kopyalandi.') -ForegroundColor Green
            }
            'D' {
                Write-Host ('  -> Detay: ' + $dom) -ForegroundColor Cyan
                Get-PSCertificate -Domain $dom | Format-List * | Out-String -Stream | ForEach-Object { Write-Host $_ }
            }
            'R' {
                Write-Host ('  -> PFX Onar: ' + $dom) -ForegroundColor Cyan
                Repair-PSCMCertificatePfx -Domain $dom -PfxPass $RepairPass -Confirm:$false | Out-Null
                Write-Host ('     [OK] PFX onarildi.') -ForegroundColor Green
            }
            'S' {
                Write-Host ('  -> Sil (arsivle): ' + $dom) -ForegroundColor Cyan
                Remove-PSCertificate -Domain $dom -Confirm:$false | Out-Null
                Write-Host ('     [OK] Arsive tasindi.') -ForegroundColor Green
            }
            'T' {
                Write-Host ('  -> Test: ' + $dom) -ForegroundColor Cyan
                $r = Test-PSCertificate -Domain $dom
                $r | Format-List | Out-String -Stream | ForEach-Object { Write-Host $_ }
            }
            'Q' {
                Write-Host ('  -> Kuyruga ekle (renew): ' + $dom) -ForegroundColor Cyan
                Add-PSCMAction -Action renew -Domain $dom | Out-Null
                Write-Host ('     [OK] Kuyruga eklendi.') -ForegroundColor Green
            }
        }
    } catch {
        Write-Host ('     [HATA] ' + $_.Exception.Message) -ForegroundColor Red
    }
}

function Invoke-MenuCertificates {
    Show-PSCMBanner
    Write-Host '>> Sertifikalar' -ForegroundColor Yellow
    Write-Host ''
    try { $certs = @(Get-PSCertificate) } catch {
        Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red; Pause-PSCM; return
    }
    if ($certs.Count -eq 0) {
        Write-Host 'Kayitli sertifika yok. Menu 4 ile olusturun.' -ForegroundColor DarkGray
        Pause-PSCM; return
    }

    # v2.3.1 FIX: @() ile array garantisi (StrictMode-safe .Count)
    $indexed = @(Format-PSCMCertTable -Certificates $certs -PassThru)
    if ($indexed.Count -eq 0) { Pause-PSCM; return }

    Write-Host ''
    Write-Host '  Islemler:  Y) Yenile   E) Export   D) Detay   R) PFX Onar' -ForegroundColor DarkGray
    Write-Host '             S) Sil      T) Test     Q) Kuyruga Ekle (renew)' -ForegroundColor DarkGray
    Write-Host '  Enter) Geri' -ForegroundColor DarkGray
    Write-Host ''
    $sel = Read-Host 'Islem'
    if (-not $sel) { return }
    $sel = $sel.ToUpper()
    if ($sel -notmatch '^[YEDRSTQ]$') {
        Write-Host 'Gecersiz islem. Y/E/D/R/S/T/Q girin.' -ForegroundColor Red
        Pause-PSCM; return
    }

    Write-Host ''
    Write-Host ('  Numara(lar) girin. Ornek: 2   veya   1,3-5   veya   A (tumu)') -ForegroundColor DarkGray
    $nums = Read-Host 'Numara'
    if (-not $nums) { return }

    # v2.3.1 FIX: parametre adi $RangeText
    $indexes = @(ConvertFrom-PSCMRangeString -RangeText $nums -Max $indexed.Count)
    if ($indexes.Count -eq 0) {
        Write-Host 'Gecerli numara bulunamadi.' -ForegroundColor Red
        Pause-PSCM; return
    }

    $exportDest = $null
    $repairPass = $null
    switch ($sel) {
        'E' {
            $exportDest = Read-Host 'Hedef klasor'
            if (-not $exportDest) { Write-Host 'Hedef bos, iptal.' -ForegroundColor Red; Pause-PSCM; return }
        }
        'R' {
            Write-Host 'Yeni PFX parolasi girin (tum secilen sertifikalar icin ayni parola):'
            $repairPass = Read-Host -AsSecureString
        }
        'S' {
            Write-Host ''
            Write-Host ('  UYARI: ' + $indexes.Count + ' sertifika kaldirilacak (dosyalar Archive''a tasinir).') -ForegroundColor Yellow
            $onay = Read-Host 'Onaylayin [E/H]'
            if ($onay -notmatch '^[EeYy]') { Write-Host 'Iptal.' -ForegroundColor DarkGray; Pause-PSCM; return }
        }
    }

    Write-Host ''
    Write-Host ('Islem baslatiliyor: ' + $indexes.Count + ' sertifika') -ForegroundColor Cyan
    Write-Host ''
    foreach ($idx in $indexes) {
        $c = $indexed | Where-Object { $_.Index -eq $idx } | Select-Object -First 1
        if (-not $c) { continue }
        Invoke-PSCMSingleCertAction -Action $sel -Cert $c -ExportDest $exportDest -RepairPass $repairPass
    }
    Write-Host ''
    Write-Host 'Islem tamamlandi.' -ForegroundColor Green
    Pause-PSCM
}

function Invoke-MenuInfrastructure {
    Show-PSCMBanner
    Write-Host '>> Altyapi Kontrolu' -ForegroundColor Yellow
    Write-Host ''
    $report = Get-PSInfrastructure
    $report | Format-Table Kategori,Bilesen,Durum,Detay -AutoSize | Out-String -Stream | ForEach-Object { Write-Host $_ }
    $azRow = $report | Where-Object { $_.Kategori -eq 'Azure' } | Select-Object -First 1
    if ($azRow -and $azRow.Durum -ne 'OK') {
        Write-Host ''
        Write-Host '  ! Azure baglantisi kurulu degil. Menu 8 ile ayarlayin.' -ForegroundColor Yellow
    }
    Write-Host ''
    $yn = Read-Host 'Eksik modul/klasor yuklensin mi? [E/H]'
    if ($yn -match '^[EeYy]') {
        Repair-PSInfrastructure | Format-Table Kategori,Bilesen,Durum -AutoSize | Out-String -Stream | ForEach-Object { Write-Host $_ }
    }
    Pause-PSCM
}

function Invoke-MenuDashboard {
    Show-PSCMBanner
    Write-Host '>> Canli Web Dashboard & API' -ForegroundColor Yellow
    Write-Host ''
    try {
        Start-Process powershell -WindowStyle Hidden -ArgumentList "-Command `"Start-Sleep -Seconds 2; Start-Process 'http://localhost:8080/'`"" -ErrorAction SilentlyContinue
        Start-PSCMWebServer -Port 8080
    } catch { 
        Write-Host "Sunucu baslatilamadi: $($_.Exception.Message)" -ForegroundColor Red
    }
    Pause-PSCM
}

function Invoke-MenuNewCertificate {
    Show-PSCMBanner
    Write-Host '>> Yeni Sertifika Sihirbazi' -ForegroundColor Yellow
    Write-Host ''
    Write-Host 'Sertifika Saglayicisi (Provider) Secin:'
    Write-Host '  1) Genel / Internet (Let''s Encrypt - ACME)'
    Write-Host '  2) Ic Ag / Local Domain (Windows ADCS)'
    Write-Host ''
    $provIn = Read-Host 'Secim (Varsayilan: 1)'
    $provider = if ($provIn -eq '2') { 'LocalCA' } else { 'ACME' }
    
    $templateName = 'WebServer'
    if ($provider -eq 'LocalCA') {
        Write-Host ''
        $tmpIn = Read-Host 'Windows CA Sablon Adi (Template) [Varsayilan: WebServer]'
        if ($tmpIn) { $templateName = $tmpIn.Trim() }
    }
    
    Write-Host ''
    $wildcardIn = Read-Host 'Wildcard mi? [E/H]'
    $wildcard = ($wildcardIn -match '^[EeYy]')
    $domain = Read-Host 'Domain (Ornek: app.sirket.local)'
    
    $sanList = @()
    $sans = Read-Host 'Ek SAN listesi (DNS adlari veya IP adresleri, virgulle ayirin, yoksa bos birakin)'
    if ($sans) { $sanList = @($sans -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' }) }
    
    $friendly = Read-Host 'Friendly Name (bos birakabilirsiniz)'
    
    Write-Host 'PFX icin parola girin (Bos birakilirsa sistemdeki varsayilan parola kullanilir):'
    $pfxPass = Read-Host -AsSecureString
    if ($pfxPass -and $pfxPass.Length -eq 0) { $pfxPass = $null }
    
    try {
        $pArgs = @{ Domain = $domain; PfxPass = $pfxPass; Provider = $provider }
        if ($provider -eq 'LocalCA') { $pArgs['TemplateName'] = $templateName }
        if ($wildcard) { $pArgs['Wildcard'] = $true }
        if ($friendly) { $pArgs['FriendlyName'] = $friendly }
        if ($sanList.Count -gt 0) { $pArgs['SANList'] = $sanList }
        New-PSCertificate @pArgs
        Write-Host 'Sertifika basariyla olusturuldu.' -ForegroundColor Green
    } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
    Pause-PSCM
}

function Invoke-MenuSecuritySettings {
    $run = $true
    while ($run) {
        Show-PSCMBanner
        Write-Host '>> Guvenlik, Parola ve Kasa Ayarlari' -ForegroundColor Yellow
        Write-Host ''
        $defaultPass = Get-PSCMSecret -Name 'Certificate.DefaultPfxPassword'
        $pfxStatus = if ($defaultPass) { 'Kayitli (SecretStore)' } else { 'Belirlenmedi' }
        Write-Host ('  Varsayilan PFX Parolasi: ' + $pfxStatus) -ForegroundColor Cyan
        Write-Host ''
        Write-Host '  1) Varsayilan PFX Parolasini Degistir'
        Write-Host '  2) SecretStore Politikasini Ayarla (Session / None / Strict)'
        Write-Host '  3) SecretStore Kasasinin Kilidini Ac'
        Write-Host '  4) Ozel Parola / Gizli Anahtar Kaydet'
        Write-Host '  5) Gelismis Sistem Ayarlarini Goruntule / Duzenle'
        Write-Host ''
        Write-Host '  0) Geri Don' -ForegroundColor DarkGray
        
        $sel = Read-Host 'Secim'
        switch ($sel) {
            '1' {
                Write-Host 'Yeni varsayilan PFX parolasi girin (temizlemek icin bos birakin):'
                $val = Read-Host -AsSecureString
                try {
                    if ($val.Length -gt 0) {
                        Set-PSCMSecret -Name 'Certificate.DefaultPfxPassword' -Value $val
                        Write-Host 'Varsayilan PFX parolasi SecretStore''a kaydedildi.' -ForegroundColor Green
                    } else {
                        Remove-PSCMSecret -Name 'Certificate.DefaultPfxPassword' -EA SilentlyContinue
                        Write-Host 'Varsayilan PFX parolasi silindi.' -ForegroundColor Green
                    }
                } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
                Pause-PSCM
            }
            '2' { Invoke-MenuSecretPolicy }
            '3' { try { Unlock-PSCMSecretStore | Out-Null; Write-Host 'Kasa acildi.' -ForegroundColor Green } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }; Pause-PSCM }
            '4' {
                $name = Read-Host 'Secret Ismi'
                $val = Read-Host -AsSecureString -Prompt 'Deger'
                try { Set-PSCMSecret -Name $name -Value $val; Write-Host 'Kaydedildi.' -ForegroundColor Green }
                catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
                Pause-PSCM
            }
            '5' {
                Write-Host ''
                Get-PSSettings | Format-List | Out-String -Stream | ForEach-Object { Write-Host $_ }
                $edit = Read-Host 'Bir ayari manuel duzenlemek ister misiniz? [E/H]'
                if ($edit -match '^[EeYy]') {
                    $section = Read-Host 'Bolum'; $key = Read-Host 'Anahtar'; $value = Read-Host 'Deger'
                    try { Set-PSSettings -Section $section -Key $key -Value $value; Write-Host 'Guncellendi.' -ForegroundColor Green }
                    catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
                }
                Pause-PSCM
            }
            '0' { $run = $false }
        }
    }
}

function Invoke-MenuNotifications {
    $run = $true
    while ($run) {
        Show-PSCMBanner
        Write-Host '>> Bildirim (Notification) Kanallari' -ForegroundColor Yellow
        Write-Host ''
        
        $path = Join-Path (Get-PSCMPath -Name Config) 'settings.json'
        $obj = Read-PSCMJson -Path $path
        if (-not $obj.PSObject.Properties.Name -contains 'Notification') {
            $obj | Add-Member -NotePropertyName 'Notification' -NotePropertyValue @{
                Enabled = $false
                Smtp = @{ Server=''; Port=587; UseTls=$true; From=''; To=@(); Username='' }
                Teams = @{ Enabled=$false; WebhookRef='Teams.WebhookUrl' }
            }
        }
        $n = $obj.Notification
        
        Write-Host '  Mevcut Durum:' -ForegroundColor Cyan
        $teamsUrl = Get-PSCMSecret -Name 'Teams.WebhookUrl' -AsPlainText
        $teamsText = if ($teamsUrl -or $n.Teams.Enabled) { 'Ayarlanmis' } else { 'Yok' }
        $smtpText = if ($n.Smtp.Server) { $n.Smtp.Server } else { 'Yok' }
        Write-Host ("  - Teams Webhook: " + $teamsText)
        Write-Host ("  - SMTP Sunucu  : " + $smtpText)
        Write-Host ''
        Write-Host '  1) Teams Webhook Ayarla'
        Write-Host '  2) SMTP (E-Posta) Sunucusu Ayarla'
        Write-Host '  3) Bildirim Kanallarini Test Et'
        Write-Host ''
        Write-Host '  0) Geri Don' -ForegroundColor DarkGray
        
        $sel = Read-Host 'Secim'
        switch ($sel) {
            '1' {
                Write-Host ''
                Write-Host 'Teams Webhook URL adresinizi girin (temizlemek icin bos birakin):'
                $url = Read-Host 'Webhook URL'
                try {
                    if ($url) {
                        Set-PSCMSecret -Name 'Teams.WebhookUrl' -Value (ConvertTo-SecureString $url -AsPlainText -Force)
                        $n.Teams.Enabled = $true
                        $n.Enabled = $true
                        Write-Host 'Teams Webhook guncellendi.' -ForegroundColor Green
                    } else {
                        Remove-PSCMSecret -Name 'Teams.WebhookUrl' -EA SilentlyContinue
                        $n.Teams.Enabled = $false
                        Write-Host 'Teams Webhook temizlendi.' -ForegroundColor Green
                    }
                    $obj | Write-PSCMJson -Path $path
                } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
                Pause-PSCM
            }
            '2' {
                Write-Host ''
                Write-Host 'SMTP Sunucu adresini girin (Orn: smtp.office365.com) (temizlemek icin bos birakin):'
                $srv = Read-Host 'SMTP Sunucu'
                if (-not $srv) {
                    $n.Smtp.Server = ''
                    $n.Smtp.Username = ''
                    Write-Host 'SMTP ayarlari temizlendi.' -ForegroundColor Green
                } else {
                    $n.Smtp.Server = $srv
                    $port = Read-Host 'SMTP Port (Orn: 587)'
                    $n.Smtp.Port = [int]$port
                    $ssl = Read-Host 'SSL/TLS kullanilsin mi? [E/H]'
                    $n.Smtp.UseTls = ($ssl -match '^[EeYy]')
                    $from = Read-Host 'Gonderen (From) E-Posta Adresi (Orn: cert@sirket.com)'
                    $n.Smtp.From = $from
                    $to = Read-Host 'Alici (To) E-Posta Adresi (Orn: admin@sirket.com)'
                    $n.Smtp.To = @($to -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
                    $user = Read-Host 'SMTP Kullanici Adi (Gerekli degilse bos birakin)'
                    $n.Smtp.Username = $user
                    if ($user) {
                        Write-Host 'SMTP Parolasini girin (Guvenli kasaya kaydedilecek):'
                        $pass = Read-Host -AsSecureString
                        Set-PSCMSecret -Name 'Smtp.Password' -Value $pass
                    }
                    $n.Enabled = $true
                    Write-Host 'SMTP ayarlari basariyla guncellendi.' -ForegroundColor Green
                }
                $obj | Write-PSCMJson -Path $path
                Pause-PSCM
            }
            '3' {
                Write-Host "`nTest mesaji gonderiliyor..." -ForegroundColor Cyan
                try {
                    $testMsg = "PS-CertManager: Bu bir test mesajidir. Bildirim ayarlariniz dogru calisiyor!"
                    $sent = 0
                    if ($n.Teams.Enabled -or (Get-PSCMSecret -Name 'Teams.WebhookUrl')) {
                        Send-PSCMTeamsNotification -Title 'Test Basarili' -Message $testMsg -Level 'Basari'
                        Write-Host "Teams test mesaji gonderimi tetiklendi." -ForegroundColor Green
                        $sent++
                    }
                    if ($n.Smtp.Server) {
                        Send-PSCMMailNotification -Subject "PS-CertManager Test" -Body $testMsg
                        Write-Host "E-Posta (SMTP) test mesaji gonderimi tetiklendi." -ForegroundColor Green
                        $sent++
                    }
                    if ($sent -eq 0) {
                        Write-Host "Ayarlanmis herhangi bir bildirim kanali (Teams/SMTP) bulunamadi!" -ForegroundColor Yellow
                    }
                } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
                Pause-PSCM
            }
            '0' { $run = $false }
        }
    }
}

function Invoke-MenuLogs {
    Show-PSCMBanner
    Write-Host '>> Loglar' -ForegroundColor Yellow
    Write-Host ''
    $level = Read-Host 'Seviye (DEBUG/INFO/WARNING/ERROR/ALL) [ALL]'
    if (-not $level) { $level = 'ALL' }
    $lastIn = Read-Host 'Son kac satir? [50]'
    $last = 50
    if ($lastIn) { [int]::TryParse($lastIn,[ref]$last) | Out-Null }
    Get-PSLog -Level $level -Last $last -Days 3 | ForEach-Object { Write-Host $_ }
    Pause-PSCM
}

function Invoke-MenuHelp {
    Show-PSCMBanner
    Write-Host '>> Yardim' -ForegroundColor Yellow
    Write-Host ''
    Write-Host 'PS-CertManager v2.3.1' -ForegroundColor White
    Write-Host ''
    Write-Host 'Sertifika Menusu:' -ForegroundColor Cyan
    Write-Host '  1) Islem sec (Y/E/D/R/S/T/Q)'
    Write-Host '  2) Numara(lar) sec:'
    Write-Host '     Tekli:  2       Coklu: 1,3,5    Aralik: 2-4'
    Write-Host '     Karma:  1,3-5,7 Tumu:  A'
    Write-Host ''
    Write-Host 'Islemler: Y=Yenile E=Export D=Detay R=PFX Onar S=Sil T=Test Q=Kuyruga Ekle' -ForegroundColor DarkGray
    Pause-PSCM
}

function Invoke-MenuWizard {
    Show-PSCMBanner
    Write-Host '>> Azure Kurulum Sihirbazi' -ForegroundColor Yellow
    Write-Host ''
    try { Start-PSCMConfigWizard } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
    Pause-PSCM
}

function Invoke-MenuTest {
    Show-PSCMBanner
    Write-Host '>> Sertifika Sagligi Testi' -ForegroundColor Yellow
    Write-Host ''
    $dom = Read-Host 'Domain (bos = tumu)'
    try {
        if ($dom) { $r = Test-PSCertificate -Domain $dom -All } else { $r = Test-PSCertificate -All }
        $r | Format-Table Domain,Durum,DosyaVarMi,X509Gecerli,ThumbprintOk,SANSayisi,KalanGun -AutoSize | Out-String -Stream | ForEach-Object { Write-Host $_ }
    } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
    Pause-PSCM
}

function Invoke-MenuScheduler {
    Show-PSCMBanner
    Write-Host '>> Yenileme Gorevi (Task Scheduler)' -ForegroundColor Yellow
    Write-Host ''
    try {
        $tasks = @(Get-PSCMRenewalTask)
        if ($tasks.Count -gt 0) {
            $tasks | Format-Table Name,State,LastRunTime,NextRunTime -AutoSize | Out-String -Stream | ForEach-Object { Write-Host $_ }
        } else { Write-Host 'Kayitli gorev yok.' -ForegroundColor DarkGray }
    } catch { Write-Host ('Uyari: ' + $_.Exception.Message) -ForegroundColor Yellow }
    Write-Host ''
    Write-Host '  K) Kayit Et   I) Simdi Calistir   S) Sil   Enter) Geri' -ForegroundColor DarkGray
    $sel = Read-Host 'Islem'
    switch ($sel.ToUpper()) {
        'K' {
            $timeIn = Read-Host 'Yenileme saati (varsayilan 03:00)'
            if (-not $timeIn) { $timeIn = '03:00' }
            $qYn = Read-Host 'Action Queue gorevi de eklensin mi (her 5 dk)? [E/H]'
            $withQ = ($qYn -match '^[EeYy]')
            try {
                if ($withQ) { Register-PSCMRenewalTask -Time $timeIn -IncludeActionQueue }
                else { Register-PSCMRenewalTask -Time $timeIn }
                Write-Host 'Gorev(ler) kayit edildi.' -ForegroundColor Green
            } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
        }
        'I' {
            try { Invoke-PSCMRenewalCycle | Format-Table Domain,OncekiKalanGun,Durum,Hata -AutoSize | Out-String -Stream | ForEach-Object { Write-Host $_ } }
            catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
        }
        'S' {
            try { Unregister-PSCMRenewalTask -IncludeActionQueue -Confirm:$false; Write-Host 'Gorevler silindi.' -ForegroundColor Green }
            catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
        }
    }
    Pause-PSCM
}

function Invoke-MenuActionQueue {
    Show-PSCMBanner
    Write-Host '>> Action Queue' -ForegroundColor Yellow
    Write-Host ''
    try {
        $pend = @(Get-PSCMActionQueue -Status pending)
        $proc = @(Get-PSCMActionQueue -Status processed)
        $fail = @(Get-PSCMActionQueue -Status failed)
        Write-Host ('Pending: ' + $pend.Count + ' | Processed: ' + $proc.Count + ' | Failed: ' + $fail.Count) -ForegroundColor Cyan
        if ($pend.Count -gt 0) {
            $pend | Format-Table Action,Domain,CreatedAt,Source,User -AutoSize | Out-String -Stream | ForEach-Object { Write-Host $_ }
        }
    } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
    Write-Host ''
    Write-Host '  I) Isle   E) Ekle   T) Temizle (30gun+)   D) Dosyadan Ictimai   Enter) Geri' -ForegroundColor DarkGray
    $sel = Read-Host 'Islem'
    switch ($sel.ToUpper()) {
        'I' {
            try {
                $r = @(Invoke-PSCMActionQueue)
                if ($r.Count -gt 0) { $r | Format-Table Action,Domain,Success,Error -AutoSize | Out-String -Stream | ForEach-Object { Write-Host $_ } }
                else { Write-Host 'Kuyruk bostu.' -ForegroundColor DarkGray }
            } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
        }
        'E' {
            $act = Read-Host 'Aksiyon (renew/export/test/remove)'
            $dom = Read-Host 'Domain'
            try { Add-PSCMAction -Action $act -Domain $dom | Out-Null; Write-Host 'Eklendi.' -ForegroundColor Green }
            catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
        }
        'T' {
            try { $n = Clear-PSCMActionQueue -Status processed -OlderThanDays 30; Write-Host ('Silinen: ' + $n) -ForegroundColor Green }
            catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
        }
        'D' {
            $path = Read-Host 'JSON dosya yolu'
            try { $n = Import-PSCMActionFile -Path $path; Write-Host ('Ictimai: ' + $n) -ForegroundColor Green }
            catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
        }
    }
    Pause-PSCM
}

function Invoke-MenuDeployments {
    Show-PSCMBanner
    Write-Host '>> IIS Dagitim (Deployment) Sihirbazi' -ForegroundColor Yellow
    Write-Host ''
    try {
        Initialize-PSCMSQLite
        Import-Module PSSQLite -ErrorAction SilentlyContinue
        $dbPath = Join-Path (Get-PSCMPath -Name State) "pscm.db"
        $deploys = @(Invoke-SqliteQuery -DataSource $dbPath -Query "SELECT * FROM deployments" -ErrorAction SilentlyContinue)
        
        if ($deploys.Count -gt 0) {
            $deploys | Format-Table Id,Domain,Target,ComputerName,SiteName,HostHeader -AutoSize | Out-String -Stream | ForEach-Object { Write-Host $_ }
        } else {
            Write-Host 'Kayitli dagitim (deployment) ayari bulunamadi.' -ForegroundColor DarkGray
        }
        
        Write-Host ''
        Write-Host '  E) Yeni Kesif Ekle   S) Sil   Enter) Geri' -ForegroundColor DarkGray
        $sel = Read-Host 'Islem'
        switch ($sel.ToUpper()) {
            'E' {
                $loc = Read-Host 'Hedef IIS Sunucusu Yerel mi (Localhost) Uzak mi? [Y/U]'
                $compName = 'localhost'
                $cred = $null
                
                if ($loc -match '^[Uu]') {
                    $compName = Read-Host 'Uzak Sunucu IP veya Bilgisayar Adi'
                    
                    Write-Host "`nSunucuya erisim ve WinRM baglantisi kontrol ediliyor ($compName)..." -ForegroundColor Cyan
                    if ($compName -match '^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$') {
                        try {
                            $hostEntry = [System.Net.Dns]::GetHostEntry($compName)
                            $compName = $hostEntry.HostName
                            Write-Host "IP adresi cozumlenerek sunucu adi ($compName) olarak guncellendi (WinRM uyumlulugu icin)." -ForegroundColor Yellow
                        } catch {
                            Write-Host "UYARI: IP adresi DNS ile cozumlenemedi. IP uzerinden baglanti sorunu yasanabilir." -ForegroundColor DarkYellow
                        }
                    }
                    
                    try {
                        Test-WSMan -ComputerName $compName -ErrorAction Stop | Out-Null
                    } catch {
                        Write-Host "HATA: Hedef makine adi yanlis, cevrimdisi veya WinRM servisi ulasilamaz durumda ($compName)!" -ForegroundColor Red
                        Write-Host "Detay: $_" -ForegroundColor DarkGray
                        Pause-PSCM; return
                    }
                    
                    Write-Host "`nUzak sunucu ($compName) icin yetkili bir hesap (Orn: DOMAIN\Administrator) girin:" -ForegroundColor Cyan
                    Write-Host "Girdiginiz hesap, Task Scheduler tarafindan arka planda otomatik yenileme icin de kullanilacaktir." -ForegroundColor DarkGray
                    $cred = Get-Credential
                    if (-not $cred) { return }
                    
                    Write-Host "`nIIS uzerindeki siteler taraniyor ($compName)..." -ForegroundColor Yellow
                    try {
                        $bindings = @(Get-PSCMIISBinding -ComputerName $compName -Credential $cred)
                    } catch {
                        Write-Host "Uzak sunucuya baglanti basarisiz: $_" -ForegroundColor Red
                        Pause-PSCM; return
                    }
                } else {
                    Write-Host "`nIIS uzerindeki siteler taraniyor (localhost)..." -ForegroundColor Yellow
                    try {
                        $bindings = @(Get-PSCMIISBinding -ComputerName 'localhost')
                    } catch {
                        Write-Host "Hata: $_" -ForegroundColor Red
                        Pause-PSCM; return
                    }
                }
                
                if ($bindings.Count -eq 0) {
                    Write-Host "Bulunan IIS sitesi yok veya erisim basarisiz." -ForegroundColor Red
                    Pause-PSCM; return
                }
                
                if ($loc -match '^[Uu]') {
                    Write-Host ''
                    Write-Host 'Uzak sunucu baglantisi BASARILI!' -ForegroundColor Green
                }
                
                Write-Host "`nBulunan IIS Siteleri ve Baglamalar:" -ForegroundColor Cyan
                $i = 1
                foreach ($b in $bindings) {
                    Write-Host ("  {0,2}) Site: {1,-20} | Port: {2,-4} | Host: {3}" -f $i, $b.SiteName, $b.Port, $b.HostHeader)
                    $i++
                }
                
                Write-Host ""
                $bIdx = Read-Host "Listeden bir site numarasi secin (Iptal icin bos birakin)"
                if (-not $bIdx -or [int]$bIdx -lt 1 -or [int]$bIdx -gt $bindings.Count) { return }
                
                $selected = $bindings[[int]$bIdx - 1]
                
                Write-Host "`nSecilen Site: $($selected.SiteName) (Host: $($selected.HostHeader))" -ForegroundColor Green
                $d = Read-Host 'Hangi Domain/Sertifika icin bu siteye kurulum yapilsin? (Ornek: app.farlas.com veya *.farlas.com)'
                if (-not $d) { return }
                
                if ($loc -match '^[Uu]') {
                    Write-Host ''
                    $saveYn = Read-Host 'Bu hesabi arka plan gorevleri (Task Scheduler) icin guvenli kasaya kaydedeyim mi? [E/H] (Varsayilan: E)'
                    if ($saveYn -match '^[EeYy]' -or $saveYn -eq '') {
                        $secretName = "DeployCred_$compName"
                        Set-PSCMSecret -Name $secretName -Value $cred.Password
                        $path = Join-Path (Get-PSCMPath -Name Config) 'settings.json'
                        $obj = Read-PSCMJson -Path $path
                        if ('Deployment' -notin $obj.PSObject.Properties.Name) {
                            $obj | Add-Member -NotePropertyName 'Deployment' -NotePropertyValue ([PSCustomObject]@{})
                        }
                        $obj.Deployment | Add-Member -NotePropertyName ("User_$compName") -NotePropertyValue $cred.UserName -Force
                        $obj | Write-PSCMJson -Path $path
                        
                        Write-Host ("Hesap '$secretName' adiyla guvenli kasaya kaydedildi.") -ForegroundColor Green
                    }
                }
                
                $insert = @"
                INSERT INTO deployments (Domain, Target, ComputerName, SiteName, HostHeader, StoreLocation, StoreName, DeployUsername)
                VALUES (@Domain, @Target, @ComputerName, @SiteName, @HostHeader, @StoreLocation, @StoreName, @DeployUsername);
"@
                $p = @{
                    Domain = $d
                    Target = 'IIS'
                    ComputerName = if ($compName -ne 'localhost') { $compName } else { $null }
                    SiteName = $selected.SiteName
                    HostHeader = $selected.HostHeader
                    StoreLocation = 'LocalMachine'
                    StoreName = 'WebHosting'
                    DeployUsername = if ($compName -ne 'localhost' -and $cred) { $cred.UserName } else { $null }
                }
                Invoke-SqliteQuery -DataSource $dbPath -Query $insert -SqlParameters $p | Out-Null
                Write-Host "`nDagitim ayari BASARIYLA eklendi!" -ForegroundColor Green
            }
            'S' {
                $id = Read-Host 'Silinecek kaydin ID numarasini girin'
                if ($id -match '^\d+$') {
                    Invoke-SqliteQuery -DataSource $dbPath -Query "DELETE FROM deployments WHERE Id = @Id" -SqlParameters @{Id=$id} | Out-Null
                    Write-Host 'Dagitim ayari silindi.' -ForegroundColor Green
                } else {
                    Write-Host 'Gecersiz ID girdiniz.' -ForegroundColor Red
                }
            }
        }
    } catch { Write-Host ("Hata: " + $_.Exception.Message) -ForegroundColor Red }
    Pause-PSCM
}

function Invoke-MenuSecretPolicy {
    Show-PSCMBanner
    Write-Host '>> SecretStore Politikasi' -ForegroundColor Yellow
    Write-Host ''
    Write-Host '  1) Session   - Oturum boyu (8 saat) acik. ONERILEN.' -ForegroundColor White
    Write-Host '  2) None      - Hicbir zaman sormaz. DPAPI.' -ForegroundColor White
    Write-Host '  3) Strict    - Varsayilan (her 15 dk).' -ForegroundColor White
    Write-Host '  4) Simdi Kilidi Ac' -ForegroundColor White
    Write-Host ''
    Write-Host '  Enter) Geri' -ForegroundColor DarkGray
    $sel = Read-Host 'Secim'
    switch ($sel) {
        '1' {
            $hIn = Read-Host 'Timeout kac saat? [8]'
            $h = 8
            if ($hIn) { [int]::TryParse($hIn,[ref]$h) | Out-Null }
            try { Set-PSCMSecretStorePolicy -Policy Session -TimeoutHours $h }
            catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
        }
        '2' { try { Set-PSCMSecretStorePolicy -Policy None } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red } }
        '3' { try { Set-PSCMSecretStorePolicy -Policy Strict } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red } }
        '4' { try { Unlock-PSCMSecretStore | Out-Null } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red } }
    }
    Pause-PSCM
}

function Invoke-SubMenuOperations {
    $subRun = $true
    while ($subRun) {
        Show-PSCMBanner
        Write-Host '>> Sertifika Operasyonlari' -ForegroundColor Yellow
        Write-Host ''
        Write-Host '  1) Sertifika Listesi & Islemler'
        Write-Host '  2) Yeni Sertifika Olustur'
        Write-Host '  3) Islem Kuyrugu (Action Queue)'
        Write-Host '  4) IIS Dagitim (Deployment) Ayarlari'
        Write-Host ''
        Write-Host '  Enter) Geri Don' -ForegroundColor DarkGray
        $sub = Read-Host 'Secim'
        switch ($sub) {
            '1' { Invoke-MenuCertificates }
            '2' { Invoke-MenuNewCertificate }
            '3' { Invoke-MenuActionQueue }
            '4' { Invoke-MenuDeployments }
            ''  { $subRun = $false }
        }
    }
}

function Invoke-SubMenuSettings {
    $subRun = $true
    while ($subRun) {
        Show-PSCMBanner
        Write-Host '>> Sistem Ayarlari & Guvenlik' -ForegroundColor Yellow
        Write-Host ''
        Write-Host '  1) Wizard ile Kurulum/Onarim'
        Write-Host '  2) Guvenlik, Parola ve Kasa Ayarlari'
        Write-Host '  3) Bildirim (Notification) Kanallari ve Testi'
        Write-Host '  4) Local CA (ADCS) Izin ve Yetki Yonetimi'
        Write-Host ''
        Write-Host '  Enter) Geri Don' -ForegroundColor DarkGray
        $sub = Read-Host 'Secim'
        switch ($sub) {
            '1' { Invoke-MenuWizard }
            '2' { Invoke-MenuSecuritySettings }
            '3' { Invoke-MenuNotifications }
            '4' { Invoke-MenuLocalCAPermissions }
            ''  { $subRun = $false }
        }
    }
}

function Invoke-SubMenuMaintenance {
    $subRun = $true
    while ($subRun) {
        Show-PSCMBanner
        Write-Host '>> Bakim & Loglar' -ForegroundColor Yellow
        Write-Host ''
        Write-Host '  1) Sistem Loglarini Gor'
        Write-Host '  2) Sistem / Altyapi Kontrolu'
        Write-Host '  3) Sertifika Sagligini Test Et'
        Write-Host '  4) Sistem E2E Testini Calistir'
        Write-Host ''
        Write-Host '  Enter) Geri Don' -ForegroundColor DarkGray
        $sub = Read-Host 'Secim'
        switch ($sub) {
            '1' { Invoke-MenuLogs }
            '2' { Invoke-MenuInfrastructure }
            '3' { Invoke-MenuTest }
            '4' { 
                Show-PSCMBanner
                Write-Host '>> E2E Sistem Testleri Basliyor' -ForegroundColor Yellow
                try { Invoke-PSCMTestSuite } catch { Write-Host "Hata: $($_.Exception.Message)" -ForegroundColor Red }
                Pause-PSCM
            }
            ''  { $subRun = $false }
        }
    }
}

$running = $true
while ($running) {
    Show-PSCMMenu
    $choice = Read-Host 'Secim'
    switch ($choice) {
        '1'  { Invoke-MenuDashboard }
        '2'  { Invoke-SubMenuOperations }
        '3'  { Invoke-MenuScheduler }
        '4'  { Invoke-SubMenuSettings }
        '5'  { Invoke-SubMenuMaintenance }
        '0'  { $running = $false }
        default { Write-Host 'Gecersiz secim.' -ForegroundColor Red; Start-Sleep -Milliseconds 800 }
    }
}
Write-Host ''
Write-Host 'PS-CertManager kapatildi.' -ForegroundColor Cyan
