function Add-PSCMAction {
<#
.SYNOPSIS
Action queue'ya yeni bir aksiyon ekler.
.DESCRIPTION
JSON dosyasi Config\State\actions\pending altina yazilir.
Bir sonraki Invoke-PSCMActionQueue calismasinda islenir.
.PARAMETER Action
renew | export | test | remove
.PARAMETER Domain
Hedef domain.
.PARAMETER Params
Aksiyona ozel parametreler (hashtable). Export icin Destination gerekli.
.EXAMPLE
Add-PSCMAction -Action renew -Domain 'vle.com.tr'
Add-PSCMAction -Action export -Domain 'vle.com.tr' -Params @{ Destination='C:\Exports'; Format='pfx' }
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateSet('new','renew','export','test','remove','repair','deploy')]
        [string]$Action,
        [Parameter(Mandatory)][string]$Domain,
        [hashtable]$Params = @{}
    )
    $root = Get-PSCMActionRoot
    $pending = Join-Path $root 'pending'
    $id = [Guid]::NewGuid().ToString()
    
    # Güvenlik (SecOps): PfxPass plaintext olarak diskteki JSON'a inmemeli. SecretStore'a yaz.
    if ($Params.ContainsKey('PfxPass') -and $Params['PfxPass']) {
        $secretName = "ActionCred_$id"
        Set-PSCMSecret -Name $secretName -Value $Params['PfxPass']
        $Params.Remove('PfxPass')
        $Params['PfxPassSecretName'] = $secretName
    }
    
    $obj = [PSCustomObject]@{
        Id        = $id
        CreatedAt = (Get-Date).ToString('o')
        Action    = $Action
        Domain    = $Domain
        Params    = $Params
        Status    = 'pending'
        User      = $env:USERNAME
        Source    = 'PowerShell'
    }
    $file = Join-Path $pending ('{0}-{1}-{2}.json' -f (Get-Date -Format 'yyyyMMdd_HHmmss'),$Action,$id.Substring(0,8))
    $obj | Write-PSCMJson -Path $file
    Write-PSCMLog -Level INFO -Message ('Aksiyon kuyruga eklendi: ' + $Action + ' ' + $Domain + ' (' + $id.Substring(0,8) + ')') -Source 'ActionQueue'
    return $obj
}
