function Invoke-PSCMActionQueue {
<#
.SYNOPSIS
Pending klasorundeki tum aksiyonlari isler.
.DESCRIPTION
Her JSON dosyasini okur, ilgili PS-CertManager cmdlet'ini calistirir,
sonuca gore processed/ veya failed/ klasorune tasir.
Task Scheduler'dan her 5 dakikada bir cagirilmak uzere tasarlandi.
#>
    [CmdletBinding()]
    param()
    Write-PSCMLog -Level INFO -Message 'Action queue islenmeye baslandi.' -Source 'ActionQueue'
    $root = Get-PSCMActionRoot
    $pendingDir   = Join-Path $root 'pending'
    $processedDir = Join-Path $root 'processed'
    $failedDir    = Join-Path $root 'failed'

    $files = @(Get-ChildItem -Path $pendingDir -Filter '*.json' -EA SilentlyContinue)
    if ($files.Count -eq 0) {
        Write-PSCMLog -Level DEBUG -Message 'Pending kuyruk bos.' -Source 'ActionQueue'
        return
    }

    $lockName = 'action-queue'
    $lock = $null
    try {
        $lock = Lock-PSCMResource -Name $lockName -TimeoutSec 10

        $results = @()
        foreach ($file in $files) {
            $obj = $null
            try {
                $obj = Read-PSCMJson -Path $file.FullName
            } catch {
                Write-PSCMLog -Level ERROR -Message ('Action JSON okunamadi: ' + $file.Name) -Source 'ActionQueue'
                Move-Item -LiteralPath $file.FullName -Destination (Join-Path $failedDir $file.Name) -Force
                continue
            }
            if (-not $obj) { continue }
            $props = @($obj.PSObject.Properties.Name)
            if (-not ($props -contains 'Action') -or -not ($props -contains 'Domain')) {
                Write-PSCMLog -Level WARNING -Message ('Action dosyasi eksik alan: ' + $file.Name) -Source 'ActionQueue'
                Move-Item -LiteralPath $file.FullName -Destination (Join-Path $failedDir $file.Name) -Force
                continue
            }

            $action = [string]$obj.Action
            $domain = [string]$obj.Domain
            $params = @{}
            if ($props -contains 'Params' -and $obj.Params) {
                foreach ($p in $obj.Params.PSObject.Properties) {
                    $params[$p.Name] = $p.Value
                }
            }

            # Aksiyon tipi dogrulamasi - gecersiz tip hemen rejected
            $validActions = @('new','renew','test','export','deploy','remove','repair')
            if ($action -notin $validActions) {
                Write-PSCMLog -Level WARNING -Message ("Gecersiz aksiyon tipi: '$action' - dosya reddedildi: " + $file.Name) -Source 'ActionQueue'
                $rejObj = $obj | Select-Object *
                $rejObj | Add-Member -NotePropertyName 'ProcessedAt' -NotePropertyValue (Get-Date).ToString('o') -Force
                $rejObj | Add-Member -NotePropertyName 'Status' -NotePropertyValue 'failed' -Force
                $rejObj | Add-Member -NotePropertyName 'Error' -NotePropertyValue "Gecersiz aksiyon tipi: $action" -Force
                $rejObj | Write-PSCMJson -Path (Join-Path $failedDir $file.Name)
                Remove-Item -LiteralPath $file.FullName -Force -EA SilentlyContinue
                continue
            }

            $success = $false
            $errMsg = ''
            try {
                Write-PSCMLog -Level INFO -Message ('Aksiyon calistiriliyor: ' + $action + ' ' + $domain) -Source 'ActionQueue'
                switch ($action) {
                    'new' {
                        $pArgs = @{ Domain = $domain }
                        if ($params.ContainsKey('Wildcard') -and [bool]$params['Wildcard']) { $pArgs['Wildcard'] = $true }
                        if ($params.ContainsKey('Provider') -and $params['Provider']) { $pArgs['Provider'] = $params['Provider'] }
                        if ($params.ContainsKey('CsrPath') -and $params['CsrPath']) { $pArgs['CsrPath'] = $params['CsrPath'] }
                        if ($params.ContainsKey('TemplateName') -and $params['TemplateName']) { $pArgs['TemplateName'] = $params['TemplateName'] }
                        if ($params.ContainsKey('SANList') -and $params['SANList']) {
                            if ($params['SANList'] -is [string]) {
                                $pArgs['SANList'] = $params['SANList'] -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' }
                            } else {
                                $pArgs['SANList'] = [string[]]$params['SANList']
                            }
                        }
                        if ($params.ContainsKey('FriendlyName') -and $params['FriendlyName']) { $pArgs['FriendlyName'] = $params['FriendlyName'] }
                        # PfxPass: Yalnizca SecretStore referansi kabul edilir; duz metin desteklenmez
                        $pfxSecretName = if ($params.ContainsKey('PfxPassSecretName') -and $params['PfxPassSecretName']) { $params['PfxPassSecretName'] } else { 'Certificate.DefaultPfxPassword' }
                        $secVal = Get-PSCMSecret -Name $pfxSecretName -EA SilentlyContinue
                        if ($secVal) { $pArgs['PfxPass'] = $secVal }
                        New-PSCertificate @pArgs -Confirm:$false | Out-Null
                    }
                    'renew'  { Update-PSCertificate -Domain $domain -Confirm:$false | Out-Null }
                    'test'   { Test-PSCertificate -Domain $domain | Out-Null }
                    'export' {
                        $dest = if ($params.ContainsKey('Destination')) { [string]$params['Destination'] } else { throw 'Destination gerekli.' }
                        $fmt  = if ($params.ContainsKey('Format')) { [string]$params['Format'] } else { 'all' }
                        Export-PSCertificate -Domain $domain -Destination $dest -Format $fmt | Out-Null
                    }
                    'deploy' {
                        $pArgs = @{}
                        if ($params.ContainsKey('PfxFilePath') -and $params['PfxFilePath']) { $pArgs['PfxFilePath'] = $params['PfxFilePath'] }
                        else {
                            throw 'PfxFilePath gerekli.'
                        }
                        
                        if ($params.ContainsKey('PfxPassSecretName') -and $params['PfxPassSecretName']) {
                            $secVal = Get-PSCMSecret -Name $params['PfxPassSecretName'] -EA SilentlyContinue
                            if ($secVal) { $pArgs['PfxPassword'] = $secVal }
                        } else {
                            $defaultPass = Get-PSCMSecret -Name 'Certificate.DefaultPfxPassword' -EA SilentlyContinue
                            if ($defaultPass) { $pArgs['PfxPassword'] = $defaultPass }
                        }

                        if (-not $pArgs.ContainsKey('PfxPassword') -or -not $pArgs['PfxPassword']) {
                            if ($params.ContainsKey('PfxPass') -and $params['PfxPass']) {
                                if ($params['PfxPass'] -is [System.Security.SecureString]) {
                                    $pArgs['PfxPassword'] = $params['PfxPass']
                                } else {
                                    $pArgs['PfxPassword'] = ConvertTo-SecureString $params['PfxPass'] -AsPlainText -Force
                                }
                            } else {
                                throw "PFX parolasi cozumlenemedi ('Certificate.DefaultPfxPassword' kasada bulunamadi)."
                            }
                        }

                        if ($params.ContainsKey('SiteName') -and $params['SiteName']) { $pArgs['SiteName'] = $params['SiteName'] }
                        else { throw 'SiteName gerekli.' }
                        
                        if ($params.ContainsKey('HostHeader') -and $params['HostHeader']) { $pArgs['HostHeader'] = $params['HostHeader'] }
                        
                        $storeName = if ($params.ContainsKey('StoreName') -and $params['StoreName']) { $params['StoreName'] } else { 'WebHosting' }
                        $storeLocation = if ($params.ContainsKey('StoreLocation') -and $params['StoreLocation']) { $params['StoreLocation'] } else { 'LocalMachine' }

                        $targetSys = 'IIS'
                        if ($params.ContainsKey('Target') -and $params['Target']) { $targetSys = $params['Target'] }

                        if ($targetSys -eq 'Nginx' -or $targetSys -eq 'Apache') {
                            $h = $pArgs['HostHeader'] -split '\|'
                            if ($h.Count -lt 2) { throw "Nginx/Apache hedef yollari (Crt|Key) okunamadi." }
                            $cOut = $h[0]
                            $kOut = $h[1]
                            
                            $nArgs = @{
                                Domain = $domain
                                PfxFilePath = $pArgs['PfxFilePath']
                                PfxPassword = $pArgs['PfxPassword']
                                ServerType = $targetSys
                                CertOutPath = $cOut
                                KeyOutPath = $kOut
                                ServiceName = $pArgs['SiteName']
                            }
                            Set-NginxApacheBinding @nArgs | Out-Null
                        }
                        else {
                            if ($params.ContainsKey('ComputerName') -and $params['ComputerName']) {
                                $rArgs = @{
                                    ComputerName = $params['ComputerName']
                                    PfxFilePath = $pArgs['PfxFilePath']
                                    PfxPassword = $pArgs['PfxPassword']
                                    SiteName = $pArgs['SiteName']
                                    StoreName = $storeName
                                    StoreLocation = $storeLocation
                                }
                                if ($pArgs.ContainsKey('HostHeader') -and $pArgs['HostHeader']) {
                                    $rArgs['HostHeader'] = $pArgs['HostHeader']
                                    $rArgs['RequireSNI'] = $true
                                }
                                if ($params.ContainsKey('RequireSNI')) {
                                    $rArgs['RequireSNI'] = [bool]$params['RequireSNI']
                                }
                                
                                if ($params.ContainsKey('DeployUsername') -and $params['DeployUsername']) {
                                    $secretName = if ($params.ContainsKey('DeployPasswordSecretName') -and $params['DeployPasswordSecretName']) { $params['DeployPasswordSecretName'] } else { "DeployCred_$($params['ComputerName'])" }
                                    $credSecret = Get-PSCMSecret -Name $secretName
                                    if ($credSecret) {
                                        $cred = New-Object System.Management.Automation.PSCredential($params['DeployUsername'], $credSecret)
                                        $rArgs['Credential'] = $cred
                                        Write-PSCMLog -Level INFO -Message ("Uzak sunucu ($($params['ComputerName'])) icin $secretName kullanilarak kimlik dogrulamasi yapiliyor.") -Source 'ActionQueue'
                                    } else {
                                        Write-PSCMLog -Level WARNING -Message ("Uzak sunucu baglantisi icin '$secretName' adinda secret bulunamadi! Islem mevcut kullanici yetkisi ile denenecek.") -Source 'ActionQueue'
                                    }
                                }
                                
                                Invoke-RemoteIISDeployment @rArgs | Out-Null
                            } else {
                                $cert = Install-CertificateToStore -PfxFilePath $pArgs['PfxFilePath'] -PfxPassword $pArgs['PfxPassword'] -StoreName $storeName -StoreLocation $storeLocation
                                
                                $bArgs = @{
                                    SiteName = $pArgs['SiteName']
                                    Thumbprint = $cert.Thumbprint
                                }
                                if ($pArgs.ContainsKey('HostHeader') -and $pArgs['HostHeader']) { 
                                    $bArgs['HostHeader'] = $pArgs['HostHeader']
                                    $bArgs['RequireSNI'] = $true
                                }
                                if ($params.ContainsKey('RequireSNI')) {
                                    $bArgs['RequireSNI'] = [bool]$params['RequireSNI']
                                }
                                Set-IISCertificateBinding @bArgs | Out-Null
                            }
                        }
                    }
                    'remove' { Remove-PSCertificate -Domain $domain -Confirm:$false | Out-Null }
                    'repair' {
                        $pArgs = @{ Domain = $domain }
                        # Duz metin PfxPass artik desteklenmez; yalnizca SecretStore referansi
                        $pfxSecretName = if ($params.ContainsKey('PfxPassSecretName') -and $params['PfxPassSecretName']) { $params['PfxPassSecretName'] } else { 'Certificate.DefaultPfxPassword' }
                        $secVal = Get-PSCMSecret -Name $pfxSecretName -EA SilentlyContinue
                        if ($secVal) { $pArgs['PfxPass'] = $secVal }
                        Repair-PSCMCertificatePfx @pArgs -Confirm:$false | Out-Null
                    }
                    default  { throw ('Bilinmeyen aksiyon: ' + $action) }
                }
                $success = $true
            } catch {
                $errMsg = $_.Exception.Message
                Write-PSCMLog -Level ERROR -Message ('Aksiyon hatasi (' + $action + ' ' + $domain + '): ' + $errMsg) -Source 'ActionQueue'
            }

            $updated = $obj | Select-Object *
            $updated | Add-Member -NotePropertyName 'ProcessedAt' -NotePropertyValue (Get-Date).ToString('o') -Force
            $statusVal = if ($success) { 'processed' } else { 'failed' }
            $updated | Add-Member -NotePropertyName 'Status' -NotePropertyValue $statusVal -Force
            if (-not $success) {
                $updated | Add-Member -NotePropertyName 'Error' -NotePropertyValue $errMsg -Force
            }

            $targetDir = if ($success) { $processedDir } else { $failedDir }
            $newPath = Join-Path $targetDir $file.Name
            $updated | Write-PSCMJson -Path $newPath
            Remove-Item -LiteralPath $file.FullName -Force -EA SilentlyContinue

            $results += [PSCustomObject]@{ Action=$action; Domain=$domain; Success=$success; Error=$errMsg }
        }

        $rcount = @($results).Count
        Write-PSCMLog -Level INFO -Message "Action queue islendi: $rcount aksiyon" -Source 'ActionQueue'
        return $results
    } catch {
        Write-PSCMLog -Level ERROR -Message ('Action queue islem hatasi: ' + $_.Exception.Message) -Source 'ActionQueue'
        throw
    } finally {
        if ($lock) { Unlock-PSCMResource -Name $lockName }
    }
}
