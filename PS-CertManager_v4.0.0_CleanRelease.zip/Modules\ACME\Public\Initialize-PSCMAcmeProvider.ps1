function Initialize-PSCMAcmeProvider {
<#
.SYNOPSIS
ACME saglayici somut nesnesini olusturur (fabrika).
#>
    [CmdletBinding()]
    param()
    $s = Get-PSSettings -Section 'Acme'
    $providerName = 'LetsEncrypt'
    if ($s.PSObject.Properties.Name -contains 'Provider' -and -not [string]::IsNullOrWhiteSpace($s.Provider)) {
        $providerName = $s.Provider
    }
    
    switch ($providerName) {
        'LetsEncrypt'        { return (New-Object PSCMPoshAcmeProvider('LetsEncrypt','LE_PROD')) }
        'LetsEncryptStaging' { return (New-Object PSCMPoshAcmeProvider('LetsEncryptStaging','LE_STAGE')) }
        'ZeroSSL'            { return (New-Object PSCMPoshAcmeProvider('ZeroSSL','ZeroSSL')) }
        default { throw (New-PSCMException -Message ("Desteklenmeyen ACME saglayici: " + $providerName) -Category 'ACME' -ErrorCode 'PSCM-1010') }
    }
}
