function Invoke-PSCMTestSuite {
<#
.SYNOPSIS
PS-CertManager Bilesenleri icin E2E Otomatik Test Takimi.
#>
    [CmdletBinding()]
    param()

    # Use explicitly named variables in the parent scope to avoid scope issues
    $testResults = @{ total = 0; passed = 0; failed = 0 }

    function Assert-Result($Name, [bool]$Condition, $ErrorMsg = "") {
        $testResults.total++
        if ($Condition) {
            Write-Host "[ PASS ] $Name" -ForegroundColor Green
            $testResults.passed++
        } else {
            Write-Host "[ FAIL ] $Name - $ErrorMsg" -ForegroundColor Red
            $testResults.failed++
        }
    }

    Write-Host "=========================================" -ForegroundColor Cyan
    Write-Host " PS-CertManager Otomatik E2E Test Suiti " -ForegroundColor Cyan
    Write-Host "=========================================" -ForegroundColor Cyan
    Write-Host ""

    # Test 1: Infrastructure
    Write-Host "-> Altyapi Testleri..." -ForegroundColor Yellow
    try {
        $infra = Get-PSInfrastructure
        Assert-Result "Altyapi verisi cekilebiliyor" ($infra.Count -gt 0)
        $modError = $infra | Where-Object { $_.Durum -eq 'HATA' }
        Assert-Result "Kritik klasor hatasi yok" (-not $modError)
    } catch { Assert-Result "Altyapi testi" $false $_.Exception.Message }

    # Test 2: State (Database)
    Write-Host "`n-> Veritabani (State) Testleri..." -ForegroundColor Yellow
    try {
        $readData = @(Get-PSCMState -Table 'certificates')
        Assert-Result "State (SQLite) okuma basarili" ($null -ne $readData)
    } catch { Assert-Result "State testi" $false $_.Exception.Message }

    # Test 3: Action Queue
    Write-Host "`n-> Islem Kuyrugu (Action Queue) Testleri..." -ForegroundColor Yellow
    try {
        $testDomain = "e2etest.example.com"
        $qRoot = Join-Path (Get-PSCMPath -Name State) "actions"
        $pendPath = Join-Path $qRoot 'pending'
        # Eski pendingleri temizle
        Get-ChildItem -Path $pendPath -Filter "*.json" -ErrorAction SilentlyContinue | Remove-Item -Force
        
        Add-PSCMAction -Action new -Domain $testDomain -Params @{ Wildcard = $true; SANList = "a.com" } | Out-Null
        $pend = @(Get-PSCMActionQueue -Status pending)
        Assert-Result "Kuyruga islem eklendi" ($pend.Count -eq 1 -and $pend[0].Domain -eq $testDomain)
        
        # Test the parameters
        $hasParams = ($pend[0].Params.Wildcard -eq $true)
        Assert-Result "Kuyruk parametreleri (Params) dogru kaydedildi" $hasParams

        # Temizle
        Get-ChildItem -Path $pendPath -Filter "*.json" -ErrorAction SilentlyContinue | Remove-Item -Force
    } catch { Assert-Result "Action Queue testi" $false $_.Exception.Message }

    # Test 4: Web Server API Test
    Write-Host "`n-> Web Server API Testleri..." -ForegroundColor Yellow
    try {
        $testPort = 18080
        # Use Start-Process to ensure ExecutionPolicy Bypass is applied
        $modulePath = Join-Path (Get-PSCMPath -Name Modules) 'PSCertManager\PSCertManager.psd1'
        $cmd = "Import-Module '$modulePath' -Force; Start-PSCMWebServer -Port $testPort"
        $proc = Start-Process powershell.exe -ArgumentList "-ExecutionPolicy Bypass -WindowStyle Hidden -Command `"$cmd`"" -PassThru

        Write-Host "   Sunucu baslatiliyor, 3 saniye bekleniyor..." -ForegroundColor DarkGray
        Start-Sleep -Seconds 3

        $baseUri = "http://localhost:$testPort"
        
        # Test GET /api/actionqueue
        $resQueue = Invoke-RestMethod -Uri "$baseUri/api/actionqueue" -Method Get -ErrorAction Stop
        Assert-Result "GET /api/actionqueue API yaniti" ($null -ne $resQueue.pending)

        # Test GET /api/logs
        $resLogs = Invoke-RestMethod -Uri "$baseUri/api/logs" -Method Get -ErrorAction Stop
        Assert-Result "GET /api/logs API yaniti (Dizi formatinda)" ($resLogs -is [array])

        # Test GET /api/infrastructure
        $resInfra = Invoke-RestMethod -Uri "$baseUri/api/infrastructure" -Method Get -ErrorAction Stop
        Assert-Result "GET /api/infrastructure API yaniti" ($resInfra.Count -gt 0)

        # Stop Process
        Stop-Process -Id $proc.Id -Force
        Assert-Result "Sunucu sorunsuz kapatildi" $true
    } catch { 
        Assert-Result "Web Server testi" $false $_.Exception.Message 
        if ($proc) { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue }
    }

    Write-Host "`n=========================================" -ForegroundColor Cyan
    Write-Host " TEST SONUCLARI" -ForegroundColor Cyan
    Write-Host " Toplam  : $($testResults.total)"
    Write-Host " Basarili: $($testResults.passed)" -ForegroundColor Green
    if ($testResults.failed -gt 0) { Write-Host " Basarisiz: $($testResults.failed)" -ForegroundColor Red }
    else { Write-Host " Tum testler basariyla gecti!" -ForegroundColor Green }
    Write-Host "=========================================" -ForegroundColor Cyan
}

Export-ModuleMember -Function Invoke-PSCMTestSuite
