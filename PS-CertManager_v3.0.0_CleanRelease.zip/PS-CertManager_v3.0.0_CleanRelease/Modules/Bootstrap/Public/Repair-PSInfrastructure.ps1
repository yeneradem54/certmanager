function Repair-PSInfrastructure {
<#
.SYNOPSIS
Eksik modulleri kullanici onayi ile yukler, klasorleri olusturur.
#>
    [CmdletBinding()]
    param([switch]$Force,[switch]$NoInteractive)
    Write-PSCMLog -Level INFO -Message 'Onarim islemi baslatildi.' -Source 'Bootstrap'
    foreach ($n in @('Config','State','Certificates','Current','Archive','Logs','Dashboard','Temp')) {
        [void](Get-PSCMPath -Name $n)
    }
    
    $deployFile = Join-Path (Get-PSCMPath -Name Config) 'Deployments.json'
    if (-not (Test-Path $deployFile)) {
        @() | Write-PSCMJson -Path $deployFile
        Write-PSCMLog -Level INFO -Message 'Bos Deployments.json sablonu olusturuldu.' -Source 'Bootstrap'
    }
    foreach ($m in $script:PSCMRequiredModules) {
        if (-not (Get-Module -ListAvailable -Name $m.Name)) {
            $install = $Force -or $NoInteractive
            if (-not $install) {
                Write-Host ''
                Write-Host ('Modul bulunamadi: ' + $m.Name + ' (' + $m.Purpose + ')') -ForegroundColor Yellow
                $yn = Read-Host 'Kurulsun mu? [E/H]'
                $install = ($yn -match '^[EeYy]')
            }
            if ($install) {
                try {
                    Write-PSCMLog -Level INFO -Message ('Modul yukleniyor: ' + $m.Name) -Source 'Bootstrap'
                    Install-Module -Name $m.Name -Scope CurrentUser -Force -AllowClobber -MinimumVersion $m.MinVersion -EA Stop
                    Write-PSCMLog -Level INFO -Message ('Modul yuklendi: ' + $m.Name) -Source 'Bootstrap'
                } catch {
                    Write-PSCMLog -Level ERROR -Message ('Modul yuklenemedi: ' + $m.Name + ' - ' + $_.Exception.Message) -Source 'Bootstrap'
                }
            }
        }
    }
    Initialize-PSCMSettings
    try { Initialize-PSCMSecretStore | Out-Null } catch { Write-PSCMLog -Level WARNING -Message ('SecretStore hatasi: ' + $_.Exception.Message) -Source 'Bootstrap' }
    Write-PSCMLog -Level INFO -Message 'Onarim islemi tamamlandi.' -Source 'Bootstrap'
    return (Get-PSInfrastructure)
}
