# PS-CertManager — Proje Dosya İndeksi

> Bu belge projedeki **her dosyanın** amacını, sorumluluklarını, diğer bileşenlerle olan bağımlılık ve ilişki haritasını tek bir yerden sunar.
> Son güncelleme: 2026-08-13 (v4.0.0)

---

## Dizin Yapısı (Üst Düzey)

```
PS-CertManager/
├── Manager-Start.ps1          ← CLI giriş noktası (entry-point)
├── Build-Release.ps1          ← Temiz ZIP paketleyici
├── README.md                  ← Proje hakkında genel bilgi
├── CHANGELOG.md               ← Sürüm geçmişi
├── Config/
│   └── settings.json          ← Merkezi yapılandırma dosyası
├── Certificates/              ← Üretilen sertifikaların depolandığı alan
│   ├── Current/               ← Aktif sertifikalar (PFX)
│   └── Archive/               ← Arşivlenmiş eski sertifikalar
├── Logs/                      ← Uygulama log dosyaları
├── Temp/                      ← Geçici dosyalar (proje-yerel, sistem TEMP kullanılmaz)
├── Tests/                     ← Pester birim testleri
│   ├── Common.Tests.ps1
│   ├── PSCertManager.Tests.ps1
│   └── Settings.Tests.ps1
└── Modules/                   ← 19 bağımsız PowerShell modülü
    ├── PSCertManager/         ← Ana (Master) konteyner modül
    ├── Common/                ← Çekirdek yardımcı fonksiyonlar
    ├── Settings/              ← JSON ayar yönetimi
    ├── Logging/               ← Log yazma ve döndürme
    ├── Security/              ← SecretStore kasa yönetimi
    ├── Bootstrap/             ← İlk kurulum sihirbazı
    ├── ACME/                  ← Let's Encrypt / ZeroSSL / GoDaddy CA
    ├── Certificate/           ← Sertifika yaşam döngüsü (CRUD)
    ├── LocalCA/               ← Windows ADCS ile yerel CA
    ├── AzureDNS/              ← Azure DNS Zone yönetimi
    ├── SSLTools/              ← OpenSSL PEM/PFX/CSR araçları
    ├── Deployment/            ← IIS / Nginx / Apache dağıtım
    ├── Notification/          ← SMTP / Teams / Slack / Discord
    ├── Scheduler/             ← Windows Task Scheduler entegrasyonu
    ├── ActionQueue/           ← Dosya tabanlı asenkron kuyruk
    ├── Dashboard/             ← HTML rapor üretici
    ├── WebServer/             ← HTTP REST API + SPA Web UI
    ├── CLI/                   ← Terminal menü sistemi
    └── Testing/               ← E2E test paketi
```

---

## Modül Bağımlılık Haritası (Dependency Graph)

```mermaid
graph TD
    PSCertManager["PSCertManager<br/>(Master Konteyner)"]

    subgraph Çekirdek Katman
        Common["Common"]
        Settings["Settings"]
        Logging["Logging"]
        Security["Security"]
    end

    subgraph İş Mantığı Katmanı
        ACME["ACME"]
        Certificate["Certificate"]
        LocalCA["LocalCA"]
        AzureDNS["AzureDNS"]
        SSLTools["SSLTools"]
    end

    subgraph Altyapı Katmanı
        Deployment["Deployment"]
        Notification["Notification"]
        Scheduler["Scheduler"]
        ActionQueue["ActionQueue"]
        Dashboard["Dashboard"]
    end

    subgraph Arayüz Katmanı
        CLI["CLI"]
        WebServer["WebServer"]
        Bootstrap["Bootstrap"]
        Testing["Testing"]
    end

    PSCertManager --> Common & Settings & Logging & Security
    PSCertManager --> ACME & Certificate & LocalCA & AzureDNS & SSLTools
    PSCertManager --> Deployment & Notification & Scheduler & ActionQueue & Dashboard
    PSCertManager --> CLI & WebServer & Bootstrap & Testing

    Settings --> Common
    Logging --> Common & Settings
    ACME --> Common & Security
    Certificate --> ACME & LocalCA & Logging & Common
    AzureDNS --> Common & Settings & Security
    Deployment --> Common & Logging & SSLTools
    Notification --> Settings & Security & Logging
    Scheduler --> Certificate & Notification & Logging
    ActionQueue --> Common & Logging
    Dashboard --> Common & Certificate
    WebServer --> Common & Settings & Security & Certificate & ActionQueue & Notification & SSLTools & ACME
    CLI --> Common & Settings & Certificate & ACME & Notification & Deployment & Scheduler & ActionQueue & Security
    Bootstrap --> Common & Settings & Security
    Testing --> Common & WebServer & ActionQueue
```

---

## Dosya Detay İndeksi

### 🔹 Kök Dizin Dosyaları

| Dosya | Amaç | Bağımlılıklar |
|---|---|---|
| `Manager-Start.ps1` | **Ana giriş noktası.** Administrator kontrolü yapar, modülü yükler, ilk çalıştırmada `Start-PSCMConfigWizard` sihirbazını tetikler, ardından interaktif CLI döngüsünü başlatır. | `PSCertManager` modülü (tümü) |
| `Build-Release.ps1` | Dağıtım paketleyici. Kişisel verileri (log, DB, sertifika çıktıları) temizler, `settings.example.json` oluşturur, temiz ZIP arşivi üretir. | Dosya sistemi |
| `Config/settings.json` | Merkezi yapılandırma. Azure auth, ACME, bildirim, loglama, yollar ve varsayılanları saklar. **Gizli bilgiler (şifreler) burada değil, SecretStore'da tutulur.** | — |

---

### 🔹 Modül: `Common` — Çekirdek Altyapı

| Dosya | Dışa Aktarılan Fonksiyon(lar) | Amaç |
|---|---|---|
| `Public/Get-PSCMRootPath.ps1` | `Get-PSCMRootPath` | Projenin kök dizinini dinamik olarak çözümler |
| `Public/Get-PSCMPath.ps1` | `Get-PSCMPath` | Alt dizin yollarını (Config, Logs, Temp vb.) çözümler |
| `Public/Read-PSCMJson.ps1` | `Read-PSCMJson` | JSON dosyasını okur, yoksa boş nesne döner |
| `Public/Write-PSCMJson.ps1` | `Write-PSCMJson` | JSON dosyasına UTF-8 ile yazar |
| `Public/Test-PSCMAdmin.ps1` | `Test-PSCMAdmin` | Mevcut oturumun Administrator olup olmadığını kontrol eder |
| `Public/Get-PSCMVersion.ps1` | `Get-PSCMVersion` | Modül sürüm bilgisini döndürür |
| `Public/Lock-PSCMResource.ps1` | `Lock-PSCMResource` | Global Mutex ile kaynak kilitleme |
| `Public/Unlock-PSCMResource.ps1` | `Unlock-PSCMResource` | Mutex kilidini serbest bırakma |
| `Public/ConvertTo-PSCMSafeString.ps1` | `ConvertTo-PSCMSafeString` | Dosya adı için güvenli string dönüşümü |
| `Public/New-PSCMException.ps1` | `New-PSCMException` | Standart hata nesnesi oluşturma (kategori + hata kodu) |
| `Public/Copy-PSCMPoshAcmeOutput.ps1` | `Copy-PSCMPoshAcmeOutput` | Posh-ACME çıktı dosyalarını proje dizinine kopyalar |
| `Public/Format-PSCMCertTable.ps1` | `Format-PSCMCertTable` | Sertifika listesini renkli tablo olarak konsola yazar |
| `Public/Get-PSCMState.ps1` | `Get-PSCMState` | SQLite veritabanından sertifika/deployment durumunu okur |
| `Public/Set-PSCMState.ps1` | `Set-PSCMState` | SQLite veritabanına sertifika/deployment durumunu yazar |
| `Public/Invoke-PSCMReliableAction.ps1` | `Invoke-PSCMReliableAction` | Hata dayanıklılık çerçevesi (retry + exponential backoff) |
| `Public/Initialize-PSCMSQLite.ps1` | `Initialize-PSCMSQLite` | SQLite DB şemasını oluşturur, eski JSON verisini taşır |

> **Harici Bağımlılık:** `PSSQLite` modülü

---

### 🔹 Modül: `Settings` — Yapılandırma Yönetimi

| Dosya | Fonksiyon | Amaç |
|---|---|---|
| `Public/Get-PSSettings.ps1` | `Get-PSSettings` | `settings.json`'dan ayarları (veya belirli bir bölümü) okur |
| `Public/Set-PSSettings.ps1` | `Set-PSSettings` | Belirli bir ayar değerini günceller. Gizli alanları (Password, ApiKey, ClientSecret) engeller. |
| `Public/Initialize-PSCMSettings.ps1` | `Initialize-PSCMSettings` | Eksik settings.json oluştururken varsayılan şablonu yazar |

> **Bağımlı:** `Common`

---

### 🔹 Modül: `Logging` — Loglama Altyapısı

| Dosya | Fonksiyon | Amaç |
|---|---|---|
| `Public/Write-PSCMLog.ps1` | `Write-PSCMLog` | Thread-safe (Mutex) dosya + konsol + EventLog yazan merkezi log fonksiyonu |
| `Public/Get-PSLog.ps1` | `Get-PSLog` | Log dosyasından kayıtları filtreli/sıralı olarak okur |
| `Public/Invoke-PSCMLogRotation.ps1` | `Invoke-PSCMLogRotation` | Boyut ve yaş bazında log dosyalarını döndürür/arşivler |

> **Bağımlı:** `Common`, `Settings`

---

### 🔹 Modül: `Security` — Gizli Anahtar Kasası

| Dosya | Fonksiyon | Amaç |
|---|---|---|
| `Public/Initialize-PSCMSecretStore.ps1` | `Initialize-PSCMSecretStore` | SecretManagement vault'unu oluşturur/yapılandırır |
| `Public/Set-PSCMSecret.ps1` | `Set-PSCMSecret` | Gizli anahtarı (SecureString) kasaya yazar |
| `Public/Get-PSCMSecret.ps1` | `Get-PSCMSecret` | Kasadan gizli değeri okur |
| `Public/Remove-PSCMSecret.ps1` | `Remove-PSCMSecret` | Kasadan gizli anahtarı siler |
| `Public/Unlock-PSCMSecretStore.ps1` | `Unlock-PSCMSecretStore` | Kasa kilidini açar |
| `Public/Set-PSCMSecretStorePolicy.ps1` | `Set-PSCMSecretStorePolicy` | Kasa politikasını (Session/None/Strict) değiştirir |

> **Harici Bağımlılık:** `Microsoft.PowerShell.SecretManagement`, `Microsoft.PowerShell.SecretStore`

---

### 🔹 Modül: `Bootstrap` — İlk Kurulum

| Dosya | Fonksiyon | Amaç |
|---|---|---|
| `Public/Initialize-PSCertManager.ps1` | `Initialize-PSCertManager` | Tüm alt dizinleri oluşturur, SQLite DB başlatır |
| `Public/Get-PSInfrastructure.ps1` | `Get-PSInfrastructure` | Sistem sağlık raporu (modüller, bağımlılıklar, dizin yapısı) |
| `Public/Repair-PSInfrastructure.ps1` | `Repair-PSInfrastructure` | Eksik bağımlılıkları otomatik kurar |
| `Public/Start-PSCMConfigWizard.ps1` | `Start-PSCMConfigWizard` | İlk çalıştırma yapılandırma sihirbazı (Azure, ACME, DNS, PFX parolası) |

> **Bağımlı:** `Common`, `Settings`, `Security`

---

### 🔹 Modül: `ACME` — Sertifika Otoritesi Entegrasyonu

| Dosya | Fonksiyon | Amaç |
|---|---|---|
| `Public/Get-PSCMAcmeProviders.ps1` | `Get-PSCMAcmeProviders` | **Merkezi sağlayıcı kaydı (Single Source of Truth).** Desteklenen tüm ACME otoritelerini (Let's Encrypt, ZeroSSL, GoDaddy vb.) listeler. |
| `Public/Initialize-PSCMAcmeProvider.ps1` | `Initialize-PSCMAcmeProvider` | Seçilen sağlayıcıyı `Get-PSCMAcmeProviders`'dan çözümler ve `PSCMPoshAcmeProvider` nesnesi döner |
| `Public/New-PSCMAcmeCertificate.ps1` | `New-PSCMAcmeCertificate` | Yeni ACME sertifikası üretir (Posh-ACME wrapper) |
| `Public/Update-PSCMAcmeCertificate.ps1` | `Update-PSCMAcmeCertificate` | Mevcut ACME sertifikasını yeniler |
| `Private/PSCMAcmeContract.ps1` | — | `PSCMPoshAcmeProvider` PowerShell sınıfı. ACME sunucusuna kayıt (EAB dahil) ve sertifika sipariş mantığını barındırır. |

> **Harici Bağımlılık:** `Posh-ACME`  
> **Bağımlı:** `Common`, `Security`  
> **Yeni sağlayıcı eklemek için:** Sadece `Get-PSCMAcmeProviders.ps1` dosyasına bir satır eklemek yeterlidir.

---

### 🔹 Modül: `Certificate` — Sertifika Yaşam Döngüsü

| Dosya | Fonksiyon | Amaç |
|---|---|---|
| `Public/Get-PSCertificate.ps1` | `Get-PSCertificate` | SQLite'dan sertifika kayıtlarını sorgular |
| `Public/New-PSCertificate.ps1` | `New-PSCertificate` | **Ana üretim fonksiyonu.** ACME veya LocalCA sağlayıcısından sertifika üretir, PFX kaydeder, state günceller |
| `Public/Update-PSCertificate.ps1` | `Update-PSCertificate` | Mevcut sertifikayı yeniler |
| `Public/Remove-PSCertificate.ps1` | `Remove-PSCertificate` | Sertifika kaydını ve PFX dosyasını siler |
| `Public/Export-PSCertificate.ps1` | `Export-PSCertificate` | PFX'i PEM/Key/JKS formatlarına dönüştürür (SSLTools aracılığıyla) |
| `Public/Test-PSCertificate.ps1` | `Test-PSCertificate` | Sertifikanın geçerlilik süresini kontrol eder |
| `Public/Repair-PSCMCertificatePfx.ps1` | `Repair-PSCMCertificatePfx` | Bozuk PFX dosyasını onarmaya çalışır |

> **Bağımlı:** `ACME`, `LocalCA`, `Common`, `Logging`  
> **Bu modül projenin kalbidir** — diğer tüm sertifika işlemleri buradan orkestre edilir.

---

### 🔹 Modül: `LocalCA` — Windows ADCS

| Dosya | Fonksiyon | Amaç |
|---|---|---|
| `Public/Invoke-PSCMLocalCACertificateRequest.ps1` | `Invoke-PSCMLocalCACertificateRequest` | Active Directory Certificate Services üzerinden sertifika talep eder |
| `Public/Repair-PSCMLocalCAPermissions.ps1` | `Repair-PSCMLocalCAPermissions` | AD şablonu üzerinde Enroll iznini ayarlar |

> **Bağımlı:** `Common` (Logging)

---

### 🔹 Modül: `AzureDNS` — Azure DNS Yönetimi

| Dosya | Fonksiyon | Amaç |
|---|---|---|
| `Public/Connect-PSCMAzure.ps1` | `Connect-PSCMAzure` | Azure'a Service Principal ile bağlanır |
| `Public/Test-PSAzure.ps1` | `Test-PSAzure` | Azure bağlantısını test eder |
| `Public/Get-PSCMDnsZone.ps1` | `Get-PSCMDnsZone` | Belirli bir DNS zone'u sorgular |
| `Public/Find-PSCMDnsZone.ps1` | `Find-PSCMDnsZone` | Domain adına uygun zone'u otomatik bulur |
| `Public/Add-PSCMDnsZone.ps1` | `Add-PSCMDnsZone` | TXT kaydı ekler (DNS-01 challenge) |
| `Public/Get-PSCMDnsZones.ps1` | `Get-PSCMDnsZones` | Tüm zone'ları listeler |
| `Public/Remove-PSCMDnsZone.ps1` | `Remove-PSCMDnsZone` | TXT kaydını siler |

> **Harici Bağımlılık:** `Az.Accounts`, `Az.Dns`  
> **Bağımlı:** `Common`, `Settings`, `Security`

---

### 🔹 Modül: `SSLTools` — OpenSSL Araç Seti

| Dosya | Fonksiyon | Amaç |
|---|---|---|
| `Public/Get-PSCMSslCsrInfo.ps1` | `Get-PSCMSslCsrInfo` | CSR dosyasının içeriğini (CN, SAN vb.) okur |
| `Public/Get-PSCMSslCertInfo.ps1` | `Get-PSCMSslCertInfo` | PEM/CRT sertifikasının detaylarını okur |
| `Public/New-PSCMSslPfx.ps1` | `New-PSCMSslPfx` | Ayrı CRT + Key dosyalarından PFX oluşturur |
| `Public/Export-PSCMSslPrivateKey.ps1` | `Export-PSCMSslPrivateKey` | PFX'ten şifresiz private key çıkartır |
| `Public/Export-PSCMSslKeystore.ps1` | `Export-PSCMSslKeystore` | PFX'i Java Keystore (JKS) formatına dönüştürür |
| `Public/New-PSCMSslCsr.ps1` | `New-PSCMSslCsr` | Yeni CSR (Certificate Signing Request) oluşturur |

> **Harici Bağımlılık:** `openssl.exe` (PATH'de veya Winget ile kurulum)  
> **Bağımlı:** `Common`

---

### 🔹 Modül: `Deployment` — Sunucu Dağıtımı

| Dosya | Fonksiyon | Amaç |
|---|---|---|
| `Public/Install-CertificateToStore.ps1` | `Install-CertificateToStore` | PFX'i Windows Certificate Store'a aktarır |
| `Public/Set-IISCertificateBinding.ps1` | `Set-IISCertificateBinding` | IIS HTTPS binding'ini oluşturur/günceller (SNI destekli) |
| `Public/Set-NginxApacheBinding.ps1` | `Set-NginxApacheBinding` | PFX'ten CRT+Key çıkartarak Linux sunucuya kopyalar |
| `Public/Invoke-RemoteIISDeployment.ps1` | `Invoke-RemoteIISDeployment` | WinRM üzerinden uzak IIS sunucusuna sertifika dağıtır |
| `Public/Get-PSCMDeploymentConfig.ps1` | `Get-PSCMDeploymentConfig` | SQLite'dan deployment konfigürasyonunu okur |
| `Public/Get-PSCMIISBinding.ps1` | `Get-PSCMIISBinding` | Mevcut IIS HTTPS binding'lerini listeler |
| `Private/Write-DeployLog.ps1` | — | Deployment log yardımcı fonksiyonu |

> **Bağımlı:** `Common`, `Logging`, `SSLTools`

---

### 🔹 Modül: `Notification` — Bildirim Motoru

| Dosya | Fonksiyon | Amaç |
|---|---|---|
| `Public/Send-PSCMMailNotification.ps1` | `Send-PSCMMailNotification` | SMTP ile e-posta gönderir (şifre SecretStore'dan) |
| `Public/Send-PSCMTeamsNotification.ps1` | `Send-PSCMTeamsNotification` | Teams webhook'a MessageCard gönderir |
| `Public/Send-PSCMSlackNotification.ps1` | `Send-PSCMSlackNotification` | Slack webhook'a bildirim gönderir |
| `Public/Send-PSCMDiscordNotification.ps1` | `Send-PSCMDiscordNotification` | Discord webhook'a embed mesaj gönderir |

> **Bağımlı:** `Settings`, `Security`, `Logging`

---

### 🔹 Modül: `Scheduler` — Zamanlayıcı

| Dosya | Fonksiyon | Amaç |
|---|---|---|
| `Public/Register-PSCMRenewalTask.ps1` | `Register-PSCMRenewalTask` | Windows Task Scheduler'a yenileme görevi ekler |
| `Public/Unregister-PSCMRenewalTask.ps1` | `Unregister-PSCMRenewalTask` | Zamanlanmış görevi kaldırır |
| `Public/Get-PSCMRenewalTask.ps1` | `Get-PSCMRenewalTask` | Mevcut görevleri listeler |
| `Public/Invoke-PSCMRenewalCycle.ps1` | `Invoke-PSCMRenewalCycle` | Süresi dolmak üzere olan sertifikaları toplu yeniler |

> **Bağımlı:** `Certificate`, `Notification`, `Logging`

---

### 🔹 Modül: `ActionQueue` — İşlem Kuyruğu

| Dosya | Fonksiyon | Amaç |
|---|---|---|
| `Public/Add-PSCMAction.ps1` | `Add-PSCMAction` | Kuyruğa yeni işlem JSON dosyası ekler |
| `Public/Get-PSCMActionQueue.ps1` | `Get-PSCMActionQueue` | Kuyruk durumunu (Pending/Processed/Failed) sorgular |
| `Public/Invoke-PSCMActionQueue.ps1` | `Invoke-PSCMActionQueue` | Bekleyen işlemleri sırasıyla çalıştırır |
| `Public/Clear-PSCMActionQueue.ps1` | `Clear-PSCMActionQueue` | Kuyruğu temizler |
| `Public/Import-PSCMActionFile.ps1` | `Import-PSCMActionFile` | Harici JSON dosyasından toplu işlem yükler |

> **Bağımlı:** `Common`, `Logging`

---

### 🔹 Modül: `Dashboard` — HTML Rapor

| Dosya | Fonksiyon | Amaç |
|---|---|---|
| `Public/Get-PSDashboard.ps1` | `Get-PSDashboard` | Sertifika durumlarını toplayan veri nesnesi üretir |
| `Public/New-PSDashboard.ps1` | `New-PSDashboard` | Statik HTML rapor dosyası oluşturur |

> **Bağımlı:** `Common`, `Certificate`

---

### 🔹 Modül: `WebServer` — REST API + SPA UI

| Dosya | Amaç |
|---|---|
| `Public/Start-PSCMWebServer.ps1` | `System.Net.HttpListener` tabanlı HTTP sunucu. Token tabanlı güvenlik. REST API uç noktaları: `/api/v1/certificates`, `/api/v1/settings`, `/api/v1/secrets`, `/api/v1/acme/providers`, `/api/v1/actionqueue`, `/api/v1/logs`, `/api/v1/infrastructure`, `/api/v1/system/summary`, `/api/v1/scheduler`, `/api/v1/notifications`, `/api/v1/ssl-tools/*`, `/api/v1/secrets/status` |
| `PublicWeb/index.html` | **SPA Dashboard.** Bildirim kartları, sertifika tabloları, işlem kuyruğu, SSL araçları, dinamik CA/DNS ayar formları ve Tehlikeli Bölge (Factory Reset) içerir. |
| `PublicWeb/js/app.js` | Tüm istemci tarafı mantığı. API iletişimi, dinamik form render, otomatik yenileme (auto-refresh), toast bildirimleri. |
| `PublicWeb/css/style.css` | Koyu temalı glassmorphism UI tasarımı. Responsive grid layoutlar, durum göstergeleri. |

> **Bağımlı:** `Common`, `Settings`, `Security`, `Certificate`, `ActionQueue`, `Notification`, `SSLTools`, `ACME`

---

### 🔹 Modül: `CLI` — Terminal Menü Sistemi

| Dosya | Fonksiyon | Amaç |
|---|---|---|
| `Public/Show-PSCMBanner.ps1` | `Show-PSCMBanner` | ASCII banner ve sürüm bilgisi |
| `Public/Show-PSCMMenu.ps1` | `Show-PSCMMenu` | Ana menü döngüsü (alt menülere yönlendirme) |
| `Public/Pause-PSCM.ps1` | `Pause-PSCM` | "Devam etmek için Enter'a basın" bekleme |
| `Public/Invoke-MenuCertificates.ps1` | `Invoke-MenuCertificates` | Sertifika listesi ve toplu işlem menüsü |
| `Public/Invoke-MenuNewCertificate.ps1` | `Invoke-MenuNewCertificate` | **Yeni sertifika sihirbazı** — dinamik CA listesi (`Get-PSCMAcmeProviders`) |
| `Public/Invoke-MenuSecuritySettings.ps1` | `Invoke-MenuSecuritySettings` | **Entegrasyon & Sistem Ayarları** — dinamik CA/DNS yapılandırma, kasa yönetimi |
| `Public/Invoke-MenuInfrastructure.ps1` | `Invoke-MenuInfrastructure` | Sistem sağlık raporu |
| `Public/Invoke-MenuDashboard.ps1` | `Invoke-MenuDashboard` | Dashboard oluşturma |
| `Public/Invoke-MenuNotifications.ps1` | `Invoke-MenuNotifications` | Bildirim kanal yönetimi |
| `Public/Invoke-MenuLogs.ps1` | `Invoke-MenuLogs` | Log görüntüleme ve filtreleme |
| `Public/Invoke-MenuHelp.ps1` | `Invoke-MenuHelp` | Yardım ve komut referansı |
| `Public/Invoke-MenuWizard.ps1` | `Invoke-MenuWizard` | Yapılandırma sihirbazı tetikleyici |
| `Public/Invoke-MenuTest.ps1` | `Invoke-MenuTest` | Pester testlerini çalıştırma |
| `Public/Invoke-MenuScheduler.ps1` | `Invoke-MenuScheduler` | Zamanlayıcı görev yönetimi |
| `Public/Invoke-MenuActionQueue.ps1` | `Invoke-MenuActionQueue` | Kuyruk işlemleri |
| `Public/Invoke-MenuDeployments.ps1` | `Invoke-MenuDeployments` | Dağıtım yönetimi |
| `Public/Invoke-MenuSecretPolicy.ps1` | `Invoke-MenuSecretPolicy` | SecretStore politika yönetimi |
| `Public/Invoke-MenuLocalCAPermissions.ps1` | `Invoke-MenuLocalCAPermissions` | ADCS şablon izinleri |
| `Public/Invoke-MenuSslTools.ps1` | `Invoke-MenuSslTools` | SSL araçları (CSR, PFX, PEM) |
| `Public/Invoke-MenuDefaults.ps1` | `Invoke-MenuDefaults` | Varsayılan ayar yönetimi |
| `Public/Invoke-MenuDnsSettings.ps1` | `Invoke-MenuDnsSettings` | DNS eklenti ayarları |
| `Public/Invoke-SubMenuOperations.ps1` | `Invoke-SubMenuOperations` | İşlemler alt menüsü |
| `Public/Invoke-SubMenuSettings.ps1` | `Invoke-SubMenuSettings` | Ayarlar alt menüsü |
| `Public/Invoke-SubMenuMaintenance.ps1` | `Invoke-SubMenuMaintenance` | Bakım alt menüsü |
| `Public/ConvertFrom-PSCMRangeString.ps1` | `ConvertFrom-PSCMRangeString` | "1,3-5" gibi aralık stringini dizi olarak çözer |
| `Public/Invoke-PSCMSingleCertAction.ps1` | `Invoke-PSCMSingleCertAction` | Tek sertifika üzerinde işlem (Yenile/Sil/Export) |

---

### 🔹 Modül: `Testing` — Otomatik E2E Test

| Dosya | Fonksiyon | Amaç |
|---|---|---|
| `Public/Invoke-PSCMTestSuite.ps1` | `Invoke-PSCMTestSuite` | Altyapı, SQLite, ActionQueue ve WebServer API'lerini otomatik test eder |

> **Bağımlı:** `Common`, `WebServer`, `ActionQueue`

---

### 🔹 Test Dosyaları (`Tests/`)

| Dosya | Test Sayısı | Kapsam |
|---|---|---|
| `Common.Tests.ps1` | ~20 | `Get-PSCMRootPath`, `Get-PSCMPath`, JSON okuma/yazma, Admin kontrolü, Temp dizini yalıtımı |
| `PSCertManager.Tests.ps1` | ~30 | 19 modülün var olması, v4.0.0 sürüm doğrulaması, Public/ dizin yapısı |
| `Settings.Tests.ps1` | ~5 | `Get-PSSettings` fonksiyonel doğrulaması |

---

## Yeni Sağlayıcı Ekleme Rehberi

Yeni bir ACME sağlayıcı (örn: **Metunic**) eklemek için:

1. `Modules/ACME/Public/Get-PSCMAcmeProviders.ps1` dosyasına bir satır ekleyin:
   ```powershell
   [PSCustomObject]@{ Name = 'Metunic'; DisplayName = "Metunic CA (Ucretli)"; DirectoryUrl = 'https://acme.metunic.com/directory'; RequireEAB = $true }
   ```

2. **Başka hiçbir dosyayı değiştirmenize gerek yoktur.** CLI menüleri, Web UI dropdown'ları ve arka plan servisleri bu listeyi dinamik olarak okur.
