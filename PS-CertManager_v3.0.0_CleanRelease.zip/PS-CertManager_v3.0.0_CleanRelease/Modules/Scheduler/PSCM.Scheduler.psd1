﻿@{
    RootModule = 'PSCM.Scheduler.psm1'
    ModuleVersion = '2.2.0'
    GUID = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager Windows Task Scheduler Entegrasyon Modulu'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Register-PSCMRenewalTask','Unregister-PSCMRenewalTask','Get-PSCMRenewalTask','Invoke-PSCMRenewalCycle')
}
