function New-PSCMSslCsr {
<#
.SYNOPSIS
RSA Private Key ve CSR (Certificate Signing Request) dosyasi uretir.
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Domain,
        [string]$Organization = 'PS-CertManager',
        [int]$KeyLength = 2048,
        [string]$OutFolder = (Join-Path (Get-PSCMPath -Name Certificates) 'CSR')
    )

    if (-not (Test-Path $OutFolder)) {
        New-Item -Path $OutFolder -ItemType Directory -Force | Out-Null
    }

    $cleanDom = $Domain.Replace('*', 'wildcard')
    $keyPath = Join-Path $OutFolder "$cleanDom.key"
    $csrPath = Join-Path $OutFolder "$cleanDom.csr"

    Write-PSCMLog -Level INFO -Message "Yeni CSR uretiliyor: $Domain (Key: $keyPath, CSR: $csrPath)" -Source 'SSLTools'

    $infContent = @"
[NewRequest]
Subject = "CN=$Domain, O=$Organization"
KeyLength = $KeyLength
KeySpec = 1
KeyUsage = 0xA0
MachineKeySet = True
ProviderName = "Microsoft RSA SChannel Cryptographic Provider"
RequestType = PKCS10
[Extensions]
2.5.29.17 = "{text}dns=$Domain"
"@

    $infPath = Join-Path $OutFolder "$cleanDom.inf"
    Set-Content -Path $infPath -Value $infContent -Encoding UTF8

    try {
        & certreq -new $infPath $csrPath | Out-Null
        Remove-Item $infPath -Force -EA SilentlyContinue
        return [PSCustomObject]@{
            Domain = $Domain
            Organization = $Organization
            CsrPath = $csrPath
            KeyLength = $KeyLength
            Status = 'Basarili'
        }
    } catch {
        Write-PSCMLog -Level ERROR -Message ("CSR uretme hatasi: " + $_.Exception.Message) -Source 'SSLTools'
        throw
    }
}
