@{
    RootModule = 'PSCM.CLI.psm1'
    ModuleVersion = '4.0.0'
    GUID = 'b9e50616-a206-4788-9b39-1d3df4d9caea'
    Author = 'PS-CertManager Ekibi'
    CompanyName = 'PS-CertManager'
    Copyright = '(c) 2026 PS-CertManager. Tum haklari saklidir.'
    Description = 'PS-CertManager CLI Menu Fonksiyonlari'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @(
        'Show-PSCMBanner', 'Show-PSCMMenu', 'Pause-PSCM',
        'ConvertFrom-PSCMRangeString', 'Invoke-PSCMSingleCertAction',
        'Invoke-MenuLocalCAPermissions', 'Invoke-MenuCertificates',
        'Invoke-MenuInfrastructure', 'Invoke-MenuDashboard',
        'Invoke-MenuNewCertificate', 'Invoke-MenuSecuritySettings',
        'Invoke-MenuNotifications', 'Invoke-MenuLogs', 'Invoke-MenuHelp',
        'Invoke-MenuWizard', 'Invoke-MenuTest', 'Invoke-MenuScheduler',
        'Invoke-MenuActionQueue', 'Invoke-MenuDeployments',
        'Invoke-MenuSecretPolicy', 'Invoke-MenuSslTools', 'Invoke-MenuDefaults', 'Invoke-MenuDnsSettings',
        'Invoke-SubMenuAutomation', 'Invoke-SubMenuOperations', 'Invoke-SubMenuSettings', 'Invoke-SubMenuMaintenance'
    )
    CmdletsToExport = @()
    VariablesToExport = @()
    AliasesToExport = @()
}
