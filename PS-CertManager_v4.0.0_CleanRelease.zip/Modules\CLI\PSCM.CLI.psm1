#Requires -Version 5.1
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'

# Public fonksiyonlari yukle
Get-ChildItem -Path (Join-Path $PSScriptRoot 'Public') -Filter '*.ps1' -ErrorAction SilentlyContinue | ForEach-Object {
    . $_.FullName
}

Export-ModuleMember -Function @(
    'Show-PSCMBanner', 'Show-PSCMMenu', 'Pause-PSCM',
    'ConvertFrom-PSCMRangeString', 'Invoke-PSCMSingleCertAction',
    'Invoke-MenuLocalCAPermissions', 'Invoke-MenuCertificates',
    'Invoke-MenuInfrastructure', 'Invoke-MenuDashboard',
    'Invoke-MenuNewCertificate', 'Invoke-MenuSecuritySettings',
    'Invoke-MenuNotifications', 'Invoke-MenuLogs', 'Invoke-MenuHelp',
    'Invoke-MenuWizard', 'Invoke-MenuTest', 'Invoke-MenuScheduler',
    'Invoke-MenuActionQueue', 'Invoke-MenuDeployments',
    'Invoke-MenuSecretPolicy', 'Invoke-MenuSslTools', 'Invoke-MenuDefaults', 'Invoke-MenuDnsSettings',
    'Invoke-SubMenuAutomation', 'Invoke-SubMenuOperations', 'Invoke-SubMenuSettings', 'Invoke-SubMenuMaintenance'
)
