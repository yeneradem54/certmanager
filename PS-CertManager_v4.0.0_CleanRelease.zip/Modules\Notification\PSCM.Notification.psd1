@{
    RootModule = 'PSCM.Notification.psm1'
    ModuleVersion = '4.0.0'
    GUID = '3eecdf6a-48fe-4f10-ac36-e9712d9360f1'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager Bildirim Modulu (SMTP + Teams + Slack + Discord)'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Send-PSCMMailNotification','Send-PSCMTeamsNotification','Send-PSCMSlackNotification','Send-PSCMDiscordNotification')
}
