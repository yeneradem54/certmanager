function Get-PSCMSslCsrInfo {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$CsrPath)

    $CsrPath = $CsrPath.Trim("`"").Trim("'").Trim()
    if (-not (Test-Path $CsrPath)) { throw "CSR dosyasi bulunamadi: $CsrPath" }
    
    Write-PSCMLog -Level INFO -Message "CSR bilgileri okunuyor: $CsrPath" -Source 'SSLTools'
    $output = & certutil -dump $CsrPath 2>&1 | Out-String
    return $output
}
