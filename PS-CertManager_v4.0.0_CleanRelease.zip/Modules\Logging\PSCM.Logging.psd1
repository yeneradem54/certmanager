@{
    RootModule = 'PSCM.Logging.psm1'
    ModuleVersion = '4.0.0'
    GUID = 'af2f0592-3d0c-4ba2-8194-fd7faf601546'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager Merkezi Loglama Modulu'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Write-PSCMLog','Get-PSLog','Invoke-PSCMLogRotation')
}
