function Set-IISCertificateBinding {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]$SiteName,
        
        [Parameter(Mandatory=$true)]
        [string]$Thumbprint,
        
        [Parameter(Mandatory=$false)]
        [string]$HostHeader = "",
        
        [Parameter(Mandatory=$false)]
        [switch]$RequireSNI
    )
    
    try {
        [Reflection.Assembly]::LoadWithPartialName("Microsoft.Web.Administration") | Out-Null
        $sm = New-Object Microsoft.Web.Administration.ServerManager
        $site = $sm.Sites[$SiteName]
        if (-not $site) { throw "IIS Sitesi bulunamadi: $SiteName" }
        
        $binding = $null
        if ($HostHeader) {
            $binding = $site.Bindings | Where-Object { $_.Protocol -eq 'https' -and $_.Host -eq $HostHeader }
        } else {
            $binding = $site.Bindings | Where-Object { $_.Protocol -eq 'https' -and $_.Host -eq "" }
        }
        
        Write-DeployLog -Level INFO -Message "Sertifika IIS Binding'e ekleniyor (ServerManager)..."
        
        if (-not $binding) {
            Write-DeployLog -Level INFO -Message "Yeni HTTPS binding olusturuluyor ($SiteName : $HostHeader)..."
            $binding = $site.Bindings.CreateElement()
            $binding.Protocol = "https"
            $binding.BindingInformation = "*:443:$HostHeader"
            $site.Bindings.Add($binding)
        } else {
            Write-DeployLog -Level INFO -Message "Mevcut HTTPS binding guncelleniyor ($SiteName : $HostHeader)..."
        }
        
        if ($RequireSNI.IsPresent -and $HostHeader) {
            $binding.SetAttributeValue("sslFlags", 1)
        } else {
            $binding.SetAttributeValue("sslFlags", 0)
        }
        
        # Sertifika deposunu kontrol et (WebHosting mi My mi?)
        $storeNameFound = "My"
        if (Test-Path "cert:\LocalMachine\WebHosting\$Thumbprint") { $storeNameFound = "WebHosting" }
        elseif (-not (Test-Path "cert:\LocalMachine\My\$Thumbprint")) { throw "Sertifika bulunamadi: $Thumbprint" }
        
        $binding.CertificateStoreName = $storeNameFound
        
        # Hex string'i byte dizisine cevir
        $hashBytes = new-object byte[] ($Thumbprint.Length / 2)
        for ($i = 0; $i -lt $Thumbprint.Length; $i += 2) {
            $hashBytes[$i/2] = [convert]::ToByte($Thumbprint.Substring($i, 2), 16)
        }
        $binding.CertificateHash = $hashBytes
        
        $sm.CommitChanges()
        
        Write-DeployLog -Level INFO -Message "Sertifika basariyla siteye baglandi."
        return $true
    }
    catch {
        Write-DeployLog -Level ERROR -Message ("IIS Binding guncellenirken hata olustu: " + $_.Exception.Message)
        throw
    }
}
