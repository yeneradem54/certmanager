﻿function Send-PSCMTeamsNotification {
<#
.SYNOPSIS
Microsoft Teams webhook uzerinden bildirim gonderir.
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Title,
        [Parameter(Mandatory)][string]$Message,
        [ValidateSet('Bilgi','Uyari','Hata','Basari')][string]$Level = 'Bilgi'
    )
    $s = Get-PSSettings -Section 'Notification'
    if (-not $s.Enabled -or -not $s.Teams.Enabled) { return }
    $webhook = Get-PSCMSecret -Name $s.Teams.WebhookRef -AsPlainText
    if (-not $webhook) { return }
    $color = switch ($Level) { 'Bilgi'{'0078D4'} 'Uyari'{'F2C811'} 'Hata'{'D13438'} 'Basari'{'107C10'} default{'0078D4'} }
    $payload = @{
        '@type'='MessageCard'; '@context'='https://schema.org/extensions'
        themeColor=$color; summary=$Title; title=$Title; text=$Message
    }
    try {
        $json = $payload | ConvertTo-Json -Depth 5
        Invoke-RestMethod -Uri $webhook -Method Post -Body $json -ContentType 'application/json; charset=utf-8' -EA Stop | Out-Null
        Write-PSCMLog -Level INFO -Message ('Teams bildirimi: ' + $Title) -Source 'Notification'
    } catch {
        Write-PSCMLog -Level ERROR -Message ('Teams hatasi: ' + $_.Exception.Message) -Source 'Notification'
    }
}
