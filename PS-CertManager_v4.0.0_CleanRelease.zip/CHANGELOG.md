# Değişiklik Günlüğü (Changelog)

Bu dosya [Semantic Versioning](https://semver.org/lang/tr/) kurallarına göre tutulmaktadır.

## [4.0.0] — 2026-07-21

### Eklenenler
- **Çoklu ACME Otoritesi (Multi-CA)**: Let's Encrypt (Production/Staging) ve ZeroSSL entegrasyonu.
- **Çoklu DNS Sağlayıcısı (Multi-DNS)**: Wildcard sertifikalar için Cloudflare, AWS Route53 ve GoDaddy API entegrasyonları.
- **Cross-Platform Sunucu Desteği (Nginx & Apache)**: OpenSSL ile PFX içerisinden unencrypted PEM (Private Key) ve Fullchain sertifikası çıkartma.
- **Otomatik OpenSSL Kurulum Asistanı**: Bakım menüsünden Winget paketi ile bağımlılık kurulumu.
- **Gelişmiş Bildirim Kanalları**: Slack Webhook ve Discord Webhook bildirim entegrasyonları.
- **Gelişmiş Web UI Dashboard (v2.0)**: Glassmorphism tasarım, sidebar navigasyon, 5 ayrı pano sayfası, progress bar ile sertifika süre grafiği, anlık arama/filtreleme ve canlı settings yönetimi.
- **Pester Unit Test Paketi**: 78 adet katı mod (StrictMode 3.0) uyumlu birim testi.

### Değişenler
- Tüm 19 alt modülün versiyonları v4.0.0 ile hizalandı ve manifest export listeleri eksiksiz duruma getirildi.
- Bakım ve Sorun Giderme menüsü zorlamalı zamanlayıcı yenileme, test koşumu ve ortam değiştirici ile yenilendi.

---

## [3.0.0] — 2026-07-09

### Eklenenler
- **SPA Web Dashboard**: Sertifikaları web arayüzünden yönetme (`http://localhost:8080`)
- **REST API**: Sistem durumu, loglar ve görev zamanlayıcısı uç noktaları
- **Action Queue (İşlem Kuyruğu)**: Asenkron dosya tabanlı kuyruk mimarisi (Pending/Processed/Failed)
- **IIS Otomatik Dağıtım**: Yerel ve uzak (WinRM) IIS sunucularına sertifika dağıtımı
- **Local CA (ADCS)**: Windows Active Directory Certificate Services ile sertifika talebi
- **SQLite State Yönetimi**: Sertifika durumu ve deployment verileri SQLite ile saklanır
- **Bildirim Kanalları**: Microsoft Teams webhook ve SMTP e-posta bildirimleri
- **Network Resilience**: ACME sunucularına bağlanmadan önce bağlantı testi
- **E2E Test Suite**: Sistem genelinde otomatik entegrasyon testleri
- **Build-Release.ps1**: Kişisel verilerden arındırılmış temiz ZIP paketleyici

### Değişenler
- Modül mimarisi 17 bağımsız modüle ayrıldı (Common, Logging, Security, Settings, Bootstrap, AzureDNS, ACME, Certificate, LocalCA, Notification, Dashboard, WebServer, ActionQueue, Scheduler, Deployment, Testing)
- Tüm şifreler Microsoft.PowerShell.SecretStore (DPAPI) altyapısına taşındı
- Ana menü yapısı alt menüler ile yeniden organize edildi (Operations, Settings, Maintenance)

---

## [2.3.1] — 2026-07-01

### Düzeltmeler
- `Format-PSCMCertTable` fonksiyonundaki `PassThru` array garantisi (`@()` wrapper)
- `ConvertFrom-PSCMRangeString` fonksiyonundaki `$Input` rezerve değişken çakışması → `$RangeText` olarak yeniden adlandırıldı
- StrictMode 3.0 altında `.Count` özelliği güvenli hale getirildi

---

## [2.2.0] — 2026-06-15

### Eklenenler
- Action Queue modülü (dosya tabanlı asenkron kuyruk)
- Scheduler modülü (Windows Task Scheduler entegrasyonu)
- Sertifika sağlık testi (`Test-PSCertificate`)
- PFX onarım fonksiyonu (`Repair-PSCMCertificatePfx`)

### Değişenler
- Security modülü SecretStore politika yönetimi eklendi (Session/None/Strict)
- Certificate modülü SAN (Subject Alternative Name) desteği genişletildi

---

## [2.1.0] — 2026-05-01

### Eklenenler
- Azure DNS zone yönetimi (CRUD)
- Posh-ACME wrapper fonksiyonları
- Güvenli kasa (SecretStore) entegrasyonu
- Yapılandırma sihirbazı (`Start-PSCMConfigWizard`)
- JSON tabanlı yapılandırma sistemi

### Değişenler
- Modüler yapıya geçiş (Common, Logging, Security, Settings, Bootstrap, AzureDNS, ACME, Certificate)
- UTF-8 encoding desteği iyileştirildi

---

## [1.0.0] — 2026-03-01

### İlk Sürüm
- Temel sertifika oluşturma ve yönetim fonksiyonları
- Let's Encrypt (ACME) DNS-01 challenge desteği
- Azure DNS entegrasyonu
- PowerShell CLI arayüzü
- Dosya tabanlı sertifika depolama (Current/Archive)
