function New-PSDashboard {
<#
.SYNOPSIS
Guncel sertifika verisiyle statik HTML dashboard olusturur (v2.2 - action butonlari).
.DESCRIPTION
Her sertifika icin action butonlari (+ Yenile, + Export, Cp Y, Cp D) render eder.
Butonlar JavaScript ile localStorage'a yazar; "Kuyrugu Indir" ile JSON dosyasi indirilir.
PowerShell tarafinda Import-PSCMActionFile ile aktarilir.
#>
    Write-Host 'UYARI: New-PSDashboard ile statik HTML olusturma yontemi (v3) artik desteklenmemektedir.' -ForegroundColor Yellow
    Write-Host 'Lutfen v4.0 mimarisindeki Canli Web Sunucusunu (Start-PSCMWebServer) kullanin.' -ForegroundColor Yellow
    return $null
}
