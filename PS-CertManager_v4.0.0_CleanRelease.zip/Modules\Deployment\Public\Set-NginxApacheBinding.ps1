function Set-NginxApacheBinding {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Domain,
        [Parameter(Mandatory=$true)][string]$PfxFilePath,
        [Parameter(Mandatory=$true)][securestring]$PfxPassword,
        [Parameter(Mandatory=$true)][string]$ServerType,  # 'Nginx' veya 'Apache'
        [Parameter(Mandatory=$true)][string]$CertOutPath, # Ornek: C:\nginx\conf\ssl\domain.crt
        [Parameter(Mandatory=$true)][string]$KeyOutPath,  # Ornek: C:\nginx\conf\ssl\domain.key
        [Parameter(Mandatory=$false)][string]$ServiceName # Ornek: 'nginx'
    )

    Write-DeployLog -Level INFO -Message "$ServerType ($ServiceName) icin dagitim baslatiliyor: $Domain"

    $tempDir = $null
    try {
        if (-not (Test-Path $PfxFilePath)) {
            throw "PFX dosyasi bulunamadi: $PfxFilePath"
        }

        Write-DeployLog -Level INFO -Message "Sertifika ve Private Key dosyalari hazirlaniyor..."
        
        $pfxDir = Split-Path $PfxFilePath
        $sourceCert = $null
        $sourceKey = $null

        # 1. Oncelikle PFX dizininde onceden uretilmis fullchain/cert ve key dosyalarini kontrol et
        $candidateFullchain = Join-Path $pfxDir "fullchain.cer"
        $candidateCert = Join-Path $pfxDir "cert.cer"
        $candidateChain = Join-Path $pfxDir "chain.cer"
        $candidateKey = Join-Path $pfxDir "cert.key"
        if (-not (Test-Path $candidateKey)) {
            $candidateKey = Join-Path $pfxDir "private.key"
        }

        # 2. Gecici calisma klasoru
        $projectTempDir = Join-Path (Get-PSCMRootPath) "Temp"
        if (-not (Test-Path $projectTempDir)) {
            New-Item -ItemType Directory -Path $projectTempDir -Force | Out-Null
        }
        $tempDir = Join-Path $projectTempDir ([guid]::NewGuid().ToString())
        New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
        
        $tempCert = Join-Path $tempDir 'cert.crt'
        $tempKey  = Join-Path $tempDir 'private.key'

        # Private Key temini
        if (Test-Path $candidateKey) {
            Copy-Item -Path $candidateKey -Destination $tempKey -Force
            $sourceKey = $tempKey
        } else {
            # OpenSSL ile PFX'ten Private Key cikar
            Write-DeployLog -Level INFO -Message "PFX'ten Private Key cikariliyor..."
            Export-PSCMSslPrivateKey -PfxPath $PfxFilePath -PfxPass $PfxPassword -OutFolder $tempDir | Out-Null
            if (Test-Path (Join-Path $tempDir "private.key")) {
                $sourceKey = Join-Path $tempDir "private.key"
            } else {
                throw "Private key PFX dosyasindan cikarilamadi."
            }
        }

        # Sertifika (Fullchain) temini
        if (Test-Path $candidateFullchain) {
            Copy-Item -Path $candidateFullchain -Destination $tempCert -Force
            $sourceCert = $tempCert
        } elseif ((Test-Path $candidateCert) -and (Test-Path $candidateChain)) {
            # cert + chain birlestirerek fullchain olustur
            $fullContent = (Get-Content -Path $candidateCert -Raw).Trim() + "`r`n" + (Get-Content -Path $candidateChain -Raw).Trim()
            [System.IO.File]::WriteAllText($tempCert, $fullContent, [System.Text.Encoding]::ASCII)
            $sourceCert = $tempCert
        } elseif (Test-Path (Join-Path $tempDir "cert.pem")) {
            $sourceCert = Join-Path $tempDir "cert.pem"
        } else {
            # .NET ile fallback tekil sertifika ihraci
            $certObj = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($PfxFilePath, $PfxPassword, [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable)
            $certBytes = $certObj.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Cert)
            $b64 = [Convert]::ToBase64String($certBytes, [System.Base64FormattingOptions]::InsertLineBreaks)
            $crtPem = "-----BEGIN CERTIFICATE-----`r`n$b64`r`n-----END CERTIFICATE-----"
            [System.IO.File]::WriteAllText($tempCert, $crtPem, [System.Text.Encoding]::ASCII)
            $sourceCert = $tempCert
        }

        # Hedef dizinleri kontrol et ve kopyala
        $certDir = Split-Path $CertOutPath
        $keyDir  = Split-Path $KeyOutPath
        if (-not (Test-Path $certDir)) { New-Item -ItemType Directory -Path $certDir -Force | Out-Null }
        if (-not (Test-Path $keyDir)) { New-Item -ItemType Directory -Path $keyDir -Force | Out-Null }

        Copy-Item -Path $sourceCert -Destination $CertOutPath -Force
        Copy-Item -Path $sourceKey -Destination $KeyOutPath -Force
        Write-DeployLog -Level INFO -Message "Dosyalar hedefe kopyalandi: $CertOutPath, $KeyOutPath"

        # Servisi yeniden baslat (varsa)
        if ($ServiceName) {
            $svc = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
            if ($svc) {
                Write-DeployLog -Level INFO -Message "Servis yeniden baslatiliyor: $ServiceName"
                Restart-Service -Name $ServiceName -Force
            } else {
                Write-DeployLog -Level WARNING -Message "Belirtilen servis ($ServiceName) sistemde bulunamadi veya calismiyor, servis yeniden baslatma adimi atlandi."
            }
        }
        
        Write-DeployLog -Level INFO -Message "$ServerType dagitimi basariyla tamamlandi!"
        return $true
    } catch {
        Write-DeployLog -Level ERROR -Message ("$ServerType dagitim hatasi: " + $_.Exception.Message)
        throw
    } finally {
        if ($tempDir -and (Test-Path $tempDir)) {
            Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}
