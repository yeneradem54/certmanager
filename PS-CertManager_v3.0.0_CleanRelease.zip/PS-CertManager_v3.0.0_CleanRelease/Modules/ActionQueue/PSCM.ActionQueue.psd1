﻿@{
    RootModule = 'PSCM.ActionQueue.psm1'
    ModuleVersion = '2.2.0'
    GUID = 'cccccccc-cccc-cccc-cccc-cccccccccccc'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager Action Queue Modulu (dosya tabanli asenkron gorev kuyrugu)'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Add-PSCMAction','Get-PSCMActionQueue','Invoke-PSCMActionQueue','Clear-PSCMActionQueue','Import-PSCMActionFile')
}
