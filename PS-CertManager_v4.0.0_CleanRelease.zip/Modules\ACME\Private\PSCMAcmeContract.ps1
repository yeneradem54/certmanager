# PS-CertManager ACME saglayici soyutlamasi
# v2.2.1 - PfxPass SecureString -> plain string donusum duzeltildi.

class PSCMAcmeContract {
    [string]$Name
    [string]$DirectoryUrl
    PSCMAcmeContract([string]$name,[string]$url) { $this.Name = $name; $this.DirectoryUrl = $url }
    [object] Register([string]$email) { throw 'Register icin somut sinif gerekli.' }
    [object] NewCertificate([hashtable]$params) { throw 'NewCertificate icin somut sinif gerekli.' }
    [object] RenewCertificate([hashtable]$params) { throw 'RenewCertificate icin somut sinif gerekli.' }
}

class PSCMPoshAcmeProvider : PSCMAcmeContract {
    PSCMPoshAcmeProvider([string]$name,[string]$url) : base($name,$url) {}

    [object] Register([string]$email) {
        Import-Module Posh-ACME -EA Stop
        Set-PAServer $this.DirectoryUrl -EA Stop
        $acct = Get-PAAccount -EA SilentlyContinue
        if (-not $acct) {
            # SecretStore'dan bu sağlayıcıya özel EAB bilgilerini çekmeyi deniyoruz
            # EAB anahtar formatı: "Acme.EabKeyId.<ProviderName>" ve "Acme.EabHmacKey.<ProviderName>"
            $eabKeyId = try { Get-PSCMSecret -Name "Acme.EabKeyId.$($this.Name)" -AsPlainText } catch { $null }
            $eabHmacKey = try { Get-PSCMSecret -Name "Acme.EabHmacKey.$($this.Name)" -AsPlainText } catch { $null }
            
            $regParams = @{
                Contact = $email
                AcceptTOS = $true
            }
            if ($eabKeyId -and $eabHmacKey) {
                $regParams['EabKeyId'] = $eabKeyId
                $regParams['EabHmacKey'] = $eabHmacKey
                Write-Host "External Account Binding (EAB) kullanilarak ACME hesabi kaydediliyor ($($this.Name))..." -ForegroundColor Cyan
            }
            
            $acct = New-PAAccount @regParams -EA Stop
        }
        return $acct
    }

    # v2.2.1 FIX: SecureString -> plain text sadece Posh-ACME cagrisi icin.
    # Posh-ACME'nin -PfxPass parametresi [string] tipinde.
    # SecureString verirsek PowerShell .ToString() cagirir ve tip adini dondurur.
    [object] NewCertificate([hashtable]$params) {
        Import-Module Posh-ACME -EA Stop
        $pArgs = $params.PluginArgs
        $dnsPlugin = $params.DnsPlugin
        if ([string]::IsNullOrWhiteSpace($dnsPlugin)) { $dnsPlugin = 'Azure' }

        $csrPath = $params.CSRPath
        $pfxPlain = $null
        $bstr     = [IntPtr]::Zero
        
        if (-not $csrPath) {
            $pfxSs = $null
            if ($params.ContainsKey('PfxPass')) {
                $pfxSs = $params['PfxPass']
            } else {
                $pfxSs = Get-PSCMSecret -Name 'Certificate.DefaultPfxPassword'
            }
            
            if ($pfxSs -is [System.Security.SecureString]) {
                $bstr     = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($pfxSs)
                $pfxPlain = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
            } elseif ($pfxSs -is [string]) {
                $pfxPlain = $pfxSs
            } else {
                throw 'PfxPass parametresi SecureString veya string olmalidir.'
            }
            if ([string]::IsNullOrEmpty($pfxPlain)) { throw 'PfxPass bos olamaz.' }
        }

        try {
            Write-Host "DNS-01 dogrulamasi baslatiliyor ($dnsPlugin). Dogrulama birkac dakika surebilir. Lutfen bekleyin..." -ForegroundColor Yellow
            $paParams = @{
                DnsPlugin = $dnsPlugin
                PluginArgs = $pArgs
                AcceptTOS = $true
                Force = $true
            }
            if ($csrPath) {
                $paParams['CSRPath'] = $csrPath
            } else {
                $paParams['Domain'] = $params.Domain
                $paParams['PfxPass'] = $pfxPlain
                $paParams['Install'] = $false
            }
            return New-PACertificate @paParams
        } finally {
            if ($bstr -ne [IntPtr]::Zero) {
                [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
            }
            $pfxPlain = $null
            [System.GC]::Collect()
        }
    }

    [object] RenewCertificate([hashtable]$params) {
        Import-Module Posh-ACME -EA Stop
        Write-Host "DNS-01 yenileme dogrulamasi baslatiliyor. DNS kayitlarinin Azure DNS uzerinde yayilmasi ve ACME sunucusu (Let's Encrypt) tarafindan dogrulanmasi birkac dakika surebilir. Lutfen bekleyin..." -ForegroundColor Yellow
        try {
            return Submit-Renewal -MainDomain $params.Domain -Force
        } catch {
            Write-Host ("Submit-Renewal basarisiz oldu: " + $_.Exception.Message + ". Sifirdan alim (Fallback) deneniyor...") -ForegroundColor Yellow
            return $this.NewCertificate($params)
        }
    }
}
