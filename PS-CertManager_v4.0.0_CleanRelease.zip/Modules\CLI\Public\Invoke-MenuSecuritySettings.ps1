function Invoke-MenuSecuritySettings {
    # SecretStore durumunu renklendirerek yazdıran yardımcı fonksiyon
    function Write-SecretStatus {
        param([string]$Label, [string]$SecretName)
        Write-Host "  $Label " -NoNewline
        try {
            $secret = Get-PSCMSecret -Name $SecretName -ErrorAction Stop
            if ($secret) {
                Write-Host "[Kayitli: *****]" -ForegroundColor Green
                return
            }
        } catch {}
        Write-Host "[Kayit Yok]" -ForegroundColor Red
    }

    $run = $true
    while ($run) {
        Show-PSCMBanner
        Write-Host '  --- ENTEGRASYON VE SISTEM AYARLARI ---' -ForegroundColor Yellow
        Write-Host ''
        
        $settings = Get-PSSettings
        $caProvider = if ($settings.Acme.Provider) { $settings.Acme.Provider } else { 'LetsEncrypt' }
        $dnsPlugin = if ($settings.Acme.DnsPlugin) { $settings.Acme.DnsPlugin } else { 'Azure' }
        
        Write-Host "  Aktif Otorite (CA)     : " -NoNewline; Write-Host $caProvider -ForegroundColor Cyan
        Write-Host "  Aktif DNS Saglayicisi  : " -NoNewline; Write-Host $dnsPlugin -ForegroundColor Cyan
        Write-Host ''
        Write-Host '  [1] Sertifika Otoritesi (CA) Ayarlarini Yapilandir' -ForegroundColor White
        Write-Host '  [2] DNS Dogrulama (Challenge) Ayarlarini Yapilandir' -ForegroundColor White
        Write-Host '  [3] Guvenli Kasa (SecretStore) Islemleri' -ForegroundColor White
        Write-Host '  [4] Sistem Ayarlarini Manuel Duzenle' -ForegroundColor White
        Write-Host ''
        Write-Host '  Enter) Geri Don' -ForegroundColor DarkGray
        Write-Host ''
        
        $sel = Read-Host 'Secim'
        if (-not $sel) { $run = $false; break }
        
        switch ($sel) {
            '1' {
                Show-PSCMBanner
                Write-Host '  --- CERTIFICATE AUTHORITY (CA) YAPILANDIRMASI ---' -ForegroundColor Yellow
                Write-Host ''
                
                $providers = Get-PSCMAcmeProviders
                for ($i = 0; $i -lt $providers.Count; $i++) {
                    Write-Host "  [$($i+1)] $($providers[$i].DisplayName)" -ForegroundColor White
                }
                $localCaIdx = $providers.Count + 1
                Write-Host "  [$localCaIdx] Yerel CA (Active Directory - ADCS)" -ForegroundColor White
                Write-Host ''
                
                $caSel = Read-Host "Otorite Secin [1-$localCaIdx]"
                $newCa = $caProvider
                
                $idx = 0
                if ([int]::TryParse($caSel, [ref]$idx)) {
                    if ($idx -gt 0 -and $idx -le $providers.Count) {
                        $newCa = $providers[$idx - 1].Name
                    }
                    elseif ($idx -eq $localCaIdx) {
                        $newCa = 'LocalCA'
                    }
                }
                
                Set-PSSettings -Section Acme -Key Provider -Value $newCa
                Write-Host "  CA Otoritesi '$newCa' olarak ayarlandi." -ForegroundColor Green
                
                # Dinamik olarak CA alanlarını dolduralım
                if ($newCa -ne 'LocalCA') {
                    $curEmail = if ($settings.Acme.AccountEmail) { $settings.Acme.AccountEmail } else { '' }
                    $emailIn = Read-Host "  ACME E-Posta adresi [$curEmail]"
                    if ($emailIn) {
                        Set-PSSettings -Section Acme -Key AccountEmail -Value $emailIn.Trim()
                        Write-Host "  E-Posta adresi kaydedildi." -ForegroundColor Green
                    }
                    
                    # Eğer seçilen sağlayıcı EAB gerektiriyorsa (RequireEAB = True)
                    $matchedProv = $providers | Where-Object { $_.Name -eq $newCa } | Select-Object -First 1
                    if ($matchedProv -and $matchedProv.RequireEAB) {
                        Write-Host ''
                        Write-Host "  -- $($matchedProv.Name) CA ACME EAB Kimlik Bilgileri --" -ForegroundColor Yellow
                        Write-SecretStatus "$($matchedProv.Name) EAB Key ID" "Acme.EabKeyId.$($matchedProv.Name)"
                        $keyIdIn = Read-Host "  Yeni $($matchedProv.Name) EAB Key ID (Enter = degistirme)" -AsSecureString
                        if ($keyIdIn -and $keyIdIn.Length -gt 0) {
                            Set-PSCMSecret -Name "Acme.EabKeyId.$($matchedProv.Name)" -Value $keyIdIn
                            Write-Host '  [OK] EAB Key ID kasaya kaydedildi.' -ForegroundColor Green
                        }
                        
                        Write-SecretStatus "$($matchedProv.Name) EAB HMAC Key" "Acme.EabHmacKey.$($matchedProv.Name)"
                        $hmacIn = Read-Host "  Yeni $($matchedProv.Name) EAB HMAC Key (Enter = degistirme)" -AsSecureString
                        if ($hmacIn -and $hmacIn.Length -gt 0) {
                            Set-PSCMSecret -Name "Acme.EabHmacKey.$($matchedProv.Name)" -Value $hmacIn
                            Write-Host '  [OK] EAB HMAC Key kasaya kaydedildi.' -ForegroundColor Green
                        }
                    }
                }
                elseif ($newCa -eq 'LocalCA') {
                    $curTemplate = if ($settings.Defaults.TemplateName) { $settings.Defaults.TemplateName } else { 'WebServer5' }
                    $templateIn = Read-Host "  Varsayilan ADCS Sablon Adi [$curTemplate]"
                    if ($templateIn) {
                        Set-PSSettings -Section Defaults -Key TemplateName -Value $templateIn.Trim()
                        Write-Host "  Sablon adi kaydedildi." -ForegroundColor Green
                    }
                }
                Pause-PSCM
            }
            
            '2' {
                Show-PSCMBanner
                Write-Host '  --- DNS CHALLENGE SAGLAYICI YAPILANDIRMASI ---' -ForegroundColor Yellow
                Write-Host ''
                Write-Host '  [1] Azure DNS Zone' -ForegroundColor White
                Write-Host '  [2] GoDaddy DNS API' -ForegroundColor White
                Write-Host '  [3] Cloudflare DNS API' -ForegroundColor White
                Write-Host '  [4] AWS Route53 DNS' -ForegroundColor White
                Write-Host ''
                $dnsSel = Read-Host 'DNS Saglayici Secin [1-4]'
                $newDns = $dnsPlugin
                switch ($dnsSel) {
                    '1' { $newDns = 'Azure' }
                    '2' { $newDns = 'GoDaddy' }
                    '3' { $newDns = 'Cloudflare' }
                    '4' { $newDns = 'Route53' }
                }
                
                Set-PSSettings -Section Acme -Key DnsPlugin -Value $newDns
                Write-Host "  DNS Saglayici '$newDns' olarak ayarlandi." -ForegroundColor Green
                
                if ($newDns -eq 'Azure') {
                    $tenant = Read-Host "  Azure Tenant ID [$($settings.Azure.TenantId)]"
                    if ($tenant) { Set-PSSettings -Section Azure -Key TenantId -Value $tenant.Trim() }
                    
                    $sub = Read-Host "  Azure Subscription ID [$($settings.Azure.SubscriptionId)]"
                    if ($sub) { Set-PSSettings -Section Azure -Key SubscriptionId -Value $sub.Trim() }
                    
                    $rg = Read-Host "  Resource Group [$($settings.Azure.ResourceGroup)]"
                    if ($rg) { Set-PSSettings -Section Azure -Key ResourceGroup -Value $rg.Trim() }
                    
                    $zone = Read-Host "  DNS Zone Domain [$($settings.Azure.DnsZone)]"
                    if ($zone) { Set-PSSettings -Section Azure -Key DnsZone -Value $zone.Trim() }
                    
                    $client = Read-Host "  Application (Client) ID [$($settings.Azure.ClientId)]"
                    if ($client) { Set-PSSettings -Section Azure -Key ClientId -Value $client.Trim() }
                    
                    Write-SecretStatus 'Azure Client Secret' 'Azure.ClientSecret'
                    $secret = Read-Host '  Yeni Client Secret (Enter = degistirme)' -AsSecureString
                    if ($secret -and $secret.Length -gt 0) {
                        Set-PSCMSecret -Name 'Azure.ClientSecret' -Value $secret
                        Write-Host '  [OK] Client Secret kasaya kaydedildi.' -ForegroundColor Green
                    }
                }
                elseif ($newDns -eq 'GoDaddy') {
                    Write-SecretStatus 'GoDaddy API Key' 'GoDaddy.Key'
                    $key = Read-Host '  Yeni GoDaddy API Key (Enter = degistirme)' -AsSecureString
                    if ($key -and $key.Length -gt 0) {
                        Set-PSCMSecret -Name 'GoDaddy.Key' -Value $key
                        Write-Host '  [OK] API Key kasaya kaydedildi.' -ForegroundColor Green
                    }
                    
                    Write-SecretStatus 'GoDaddy API Secret' 'GoDaddy.Secret'
                    $sec = Read-Host '  Yeni GoDaddy API Secret (Enter = degistirme)' -AsSecureString
                    if ($sec -and $sec.Length -gt 0) {
                        Set-PSCMSecret -Name 'GoDaddy.Secret' -Value $sec
                        Write-Host '  [OK] API Secret kasaya kaydedildi.' -ForegroundColor Green
                    }
                }
                elseif ($newDns -eq 'Cloudflare') {
                    Write-SecretStatus 'Cloudflare API Token' 'Cloudflare.Token'
                    $token = Read-Host '  Yeni Cloudflare API Token (Enter = degistirme)' -AsSecureString
                    if ($token -and $token.Length -gt 0) {
                        Set-PSCMSecret -Name 'Cloudflare.Token' -Value $token
                        Write-Host '  [OK] API Token kasaya kaydedildi.' -ForegroundColor Green
                    }
                }
                elseif ($newDns -eq 'Route53') {
                    Write-SecretStatus 'AWS Access Key ID' 'Route53.AccessKey'
                    $awsKey = Read-Host '  Yeni AWS Access Key ID (Enter = degistirme)' -AsSecureString
                    if ($awsKey -and $awsKey.Length -gt 0) {
                        Set-PSCMSecret -Name 'Route53.AccessKey' -Value $awsKey
                        Write-Host '  [OK] Access Key ID kasaya kaydedildi.' -ForegroundColor Green
                    }
                    
                    Write-SecretStatus 'AWS Secret Access Key' 'Route53.SecretKey'
                    $awsSec = Read-Host '  Yeni AWS Secret Access Key (Enter = degistirme)' -AsSecureString
                    if ($awsSec -and $awsSec.Length -gt 0) {
                        Set-PSCMSecret -Name 'Route53.SecretKey' -Value $awsSec
                        Write-Host '  [OK] Secret Access Key kasaya kaydedildi.' -ForegroundColor Green
                    }
                }
                Pause-PSCM
            }
            
            '3' {
                $subRun = $true
                while ($subRun) {
                    Show-PSCMBanner
                    Write-Host '  --- GUVENLI KASA (SECRETSTORE) ISLEMLERI ---' -ForegroundColor Yellow
                    Write-Host ''
                    
                    $defaultPass = Get-PSCMSecret -Name 'Certificate.DefaultPfxPassword'
                    $pfxStatus = if ($defaultPass) { 'Kayitli (SecretStore)' } else { 'Belirlenmedi' }
                    Write-Host ('  Varsayilan PFX Parolasi: ' + $pfxStatus) -ForegroundColor Cyan
                    Write-Host ''
                    Write-Host '  [1] Varsayilan PFX Parolasini Degistir' -ForegroundColor White
                    Write-Host '  [2] SecretStore Politikasini Ayarla (Session / None / Strict)' -ForegroundColor White
                    Write-Host '  [3] SecretStore Kasasinin Kilidini Ac' -ForegroundColor White
                    Write-Host '  [4] Kasadaki Tum Anahtarlarin Durumunu Listele' -ForegroundColor White
                    Write-Host '  [5] Ozel Gizli Anahtar Ekle / Guncelle' -ForegroundColor White
                    Write-Host ''
                    Write-Host '  Enter) Geri Don' -ForegroundColor DarkGray
                    Write-Host ''
                    
                    $subSel = Read-Host 'Secim'
                    if (-not $subSel) { $subRun = $false; break }
                    
                    switch ($subSel) {
                        '1' {
                            Write-Host 'Yeni varsayilan PFX parolasi girin (temizlemek icin bos birakin):'
                            $val = Read-Host -AsSecureString
                            try {
                                if ($val.Length -gt 0) {
                                    Set-PSCMSecret -Name 'Certificate.DefaultPfxPassword' -Value $val
                                    Write-Host 'Varsayilan PFX parolasi SecretStore''a kaydedildi.' -ForegroundColor Green
                                } else {
                                    Remove-PSCMSecret -Name 'Certificate.DefaultPfxPassword' -EA SilentlyContinue
                                    Write-Host 'Varsayilan PFX parolasi silindi.' -ForegroundColor Green
                                }
                            } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
                            Pause-PSCM
                        }
                        '2' { Invoke-MenuSecretPolicy }
                        '3' { try { Unlock-PSCMSecretStore | Out-Null; Write-Host 'Kasa acildi.' -ForegroundColor Green } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }; Pause-PSCM }
                        '4' {
                            Show-PSCMBanner
                            Write-Host '  --- KASADA KAYITLI ANAHTAR DURUMLARI ---' -ForegroundColor Yellow
                            Write-Host ''
                            Write-SecretStatus 'Azure AD Application Client Secret ' 'Azure.ClientSecret'
                            Write-SecretStatus 'GoDaddy DNS API Key                 ' 'GoDaddy.Key'
                            Write-SecretStatus 'GoDaddy DNS API Secret              ' 'GoDaddy.Secret'
                            Write-SecretStatus 'GoDaddy CA ACME EAB Key ID          ' 'Acme.EabKeyId.GoDaddy'
                            Write-SecretStatus 'GoDaddy CA ACME EAB HMAC Key        ' 'Acme.EabHmacKey.GoDaddy'
                            Write-SecretStatus 'Cloudflare DNS API Token            ' 'Cloudflare.Token'
                            Write-SecretStatus 'AWS Route53 Access Key ID           ' 'Route53.AccessKey'
                            Write-SecretStatus 'AWS Route53 Secret Access Key       ' 'Route53.SecretKey'
                            Write-SecretStatus 'SMTP Sunucu E-Posta Sifresi         ' 'Smtp.Password'
                            Write-SecretStatus 'Teams Bildirim Webhook URL          ' 'Teams.WebhookUrl'
                            Write-Host ''
                            Pause-PSCM
                        }
                        '5' {
                            $name = Read-Host 'Secret Ismi (Ornek: GoDaddy.Key)'
                            $val = Read-Host -AsSecureString -Prompt 'Deger'
                            try { Set-PSCMSecret -Name $name -Value $val; Write-Host 'Kaydedildi.' -ForegroundColor Green }
                            catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
                            Pause-PSCM
                        }
                    }
                }
            }
            
            '4' {
                Write-Host ''
                Get-PSSettings | Format-List | Out-String -Stream | ForEach-Object { Write-Host $_ }
                $edit = Read-Host 'Bir ayari manuel duzenlemek ister makinesiniz? [E/H]'
                if ($edit -match '^[EeYy]') {
                    $section = Read-Host 'Bolum'; $key = Read-Host 'Anahtar'; $value = Read-Host 'Deger'
                    try { Set-PSSettings -Section $section -Key $key -Value $value; Write-Host 'Guncellendi.' -ForegroundColor Green }
                    catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
                }
                Pause-PSCM
            }
        }
    }
}
