function Invoke-PSCMLocalCACertificateRequest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Domain,
        [Parameter(Mandatory=$false)][System.Security.SecureString]$PfxPass,
        [string]$TemplateName = 'WebServer',
        [string]$FriendlyName,
        [string[]]$SANList,
        [string]$CsrPath
    )
    
    # Temp dosya yolları finally'de temizlenebilmesi için dışarıda tanımlanıyor
    $cerTempPath = $null
    $pfxTempPath = $null

    try {
        if ($CsrPath) {
            Write-PSCMLog -Level INFO -Message "Local CA (ADCS) uzerinden CSR ile sertifika talep ediliyor: $CsrPath (Template: $TemplateName)" -Source 'LocalCA'
            if (-not (Test-Path $CsrPath)) { throw "CSR dosyasi bulunamadi: $CsrPath" }
            
            $cerTempPath = Join-Path $env:TEMP "$([guid]::NewGuid()).cer"
            $argsList = "-submit -attrib `"CertificateTemplate:$TemplateName`" `"$CsrPath`" `"$cerTempPath`""
            Write-PSCMLog -Level INFO -Message "certreq args: $argsList" -Source 'LocalCA'
            
            $p = Start-Process -FilePath "certreq.exe" -ArgumentList $argsList -Wait -NoNewWindow -PassThru
            if ($p.ExitCode -ne 0 -or -not (Test-Path $cerTempPath)) {
                throw "certreq basarisiz oldu veya sertifika dosyasi olusmadi. Cikis kodu: $($p.ExitCode)"
            }
            
            $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($cerTempPath)
            Write-PSCMLog -Level INFO -Message "Sertifika alindi, Thumbprint: $($cert.Thumbprint)" -Source 'LocalCA'
            
            return [PSCustomObject]@{
                Thumbprint  = $cert.Thumbprint
                NotBefore   = $cert.NotBefore.ToString('o')
                NotAfter    = $cert.NotAfter.ToString('o')
                Issuer      = $cert.Issuer
                CerTempPath = $cerTempPath
            }
        } else {
            Write-PSCMLog -Level INFO -Message "Local CA (ADCS) uzerinden otomatik sertifika talep ediliyor: $Domain (Template: $TemplateName)" -Source 'LocalCA'
            
            $dnsEntries = @()
            $ipEntries = @()
            
            # Ana domain ayrıştırılıyor
            if ($Domain -as [ipaddress]) { $ipEntries += $Domain } else { $dnsEntries += $Domain }
            
            if ($SANList) {
                foreach ($san in $SANList) {
                    $cleanSan = $san.Trim()
                    if ($cleanSan) {
                        if ($cleanSan -as [ipaddress]) {
                            if ($cleanSan -notin $ipEntries) { $ipEntries += $cleanSan }
                        } else {
                            if ($cleanSan -notin $dnsEntries) { $dnsEntries += $cleanSan }
                        }
                    }
                }
            }

            # Eğer SAN listesinde IP adresi varsa, Get-Certificate IP desteklemediği için certreq.exe kullanıyoruz
            if ($ipEntries.Count -gt 0) {
                Write-PSCMLog -Level INFO -Message "SAN listesinde IP adresi tespit edildi. certreq.exe ve INF sablonu kullaniliyor." -Source 'LocalCA'
                
                $infPath = Join-Path $env:TEMP "$([guid]::NewGuid()).inf"
                $csrTempPath = Join-Path $env:TEMP "$([guid]::NewGuid()).csr"
                $cerTempPath = Join-Path $env:TEMP "$([guid]::NewGuid()).cer"
                $pfxTempPath = Join-Path $env:TEMP "$([guid]::NewGuid()).pfx"
                
                # SAN String oluşturuluyor (Örn: dns=domain.com&ip=192.168.1.1)
                $sanParts = @()
                foreach ($d in $dnsEntries) { $sanParts += "dns=$d" }
                foreach ($ip in $ipEntries) { $sanParts += "ip=$ip" }
                $sanString = $sanParts -join "&"

                $infContent = @"
[Version]
Signature="`$Windows NT`$"

[NewRequest]
Subject = "CN=$Domain"
KeyLength = 2048
HashAlgorithm = SHA256
Exportable = TRUE
MachineKeySet = TRUE
PrivateKeyArchive = FALSE
RequestType = PKCS10
ProviderName = "Microsoft RSA SChannel Cryptographic Provider"
ProviderType = 12
KeyUsage = 0xa0

[Extensions]
2.5.29.17 = "{text}$sanString"
"@
                try {
                    Set-Content -Path $infPath -Value $infContent -Encoding UTF8 -Force
                    
                    # 1. CSR oluştur
                    $argsNew = "-new `"$infPath`" `"$csrTempPath`""
                    $pNew = Start-Process -FilePath "certreq.exe" -ArgumentList $argsNew -Wait -NoNewWindow -PassThru
                    if ($pNew.ExitCode -ne 0 -or -not (Test-Path $csrTempPath)) {
                        throw "certreq -new basarisiz oldu. Cikis kodu: $($pNew.ExitCode)"
                    }

                    # 2. CA'e Gönder
                    $argsSubmit = "-submit -attrib `"CertificateTemplate:$TemplateName`" `"$csrTempPath`" `"$cerTempPath`""
                    $pSub = Start-Process -FilePath "certreq.exe" -ArgumentList $argsSubmit -Wait -NoNewWindow -PassThru
                    if ($pSub.ExitCode -ne 0 -or -not (Test-Path $cerTempPath)) {
                        throw "certreq -submit basarisiz oldu. Cikis kodu: $($pSub.ExitCode)"
                    }

                    # 3. Sertifikayı PFX olarak dışarı aktarmak için yerel depoya kabul et (Accept)
                    $argsAccept = "-accept `"$cerTempPath`""
                    Start-Process -FilePath "certreq.exe" -ArgumentList $argsAccept -Wait -NoNewWindow | Out-Null
                    
                    # Yerel depodan sertifikayı bul
                    $cert = Get-ChildItem -Path "cert:\LocalMachine\My" | Where-Object { 
                        $_.Subject -match "CN=$Domain" -and $_.NotBefore -ge (Get-Date).AddMinutes(-5) 
                    } | Sort-Object NotBefore -Descending | Select-Object -First 1
                    
                    if (-not $cert) {
                        throw "Sertifika yerel depoya kabul edildi ancak depoda bulunamadı."
                    }

                    Write-PSCMLog -Level INFO -Message "Sertifika alindi ve depoya kabul edildi. Thumbprint: $($cert.Thumbprint)" -Source 'LocalCA'
                    if ($FriendlyName) { $cert.FriendlyName = $FriendlyName } else { $cert.FriendlyName = $Domain }

                    # PFX aktarımı
                    Export-PfxCertificate -Cert $cert -FilePath $pfxTempPath -Password $PfxPass | Out-Null
                    
                    # Yerel depodan temizle
                    Remove-Item -Path "cert:\LocalMachine\My\$($cert.Thumbprint)" -Force -ErrorAction SilentlyContinue

                    return [PSCustomObject]@{
                        Thumbprint  = $cert.Thumbprint
                        NotBefore   = $cert.NotBefore.ToString('o')
                        NotAfter    = $cert.NotAfter.ToString('o')
                        Issuer      = $cert.Issuer
                        PfxTempPath = $pfxTempPath
                    }
                } finally {
                    # Geçici dosyaları temizle
                    if (Test-Path $infPath) { Remove-Item $infPath -Force -EA SilentlyContinue }
                    if (Test-Path $csrTempPath) { Remove-Item $csrTempPath -Force -EA SilentlyContinue }
                    if (Test-Path $cerTempPath) { Remove-Item $cerTempPath -Force -EA SilentlyContinue }
                }
            } else {
                # Sadece DNS isimleri varsa klasik Get-Certificate ile devam et
                $reqArgs = @{
                    SubjectName         = "CN=$Domain"
                    DnsName             = $dnsEntries
                    CertStoreLocation   = 'cert:\LocalMachine\My'
                    Template            = $TemplateName
                }
                
                $certInfo = Get-Certificate @reqArgs
                $cert = $certInfo.Certificate
                
                if (-not $cert) {
                    throw "Get-Certificate basarili dondu fakat sertifika nesnesi bulunamadi."
                }
                
                Write-PSCMLog -Level INFO -Message "Sertifika alindi, Thumbprint: $($cert.Thumbprint)" -Source 'LocalCA'
                
                if ($FriendlyName) { $cert.FriendlyName = $FriendlyName } else { $cert.FriendlyName = $Domain }
                
                $pfxTempPath = Join-Path $env:TEMP "$([guid]::NewGuid()).pfx"
                
                Write-PSCMLog -Level INFO -Message "Sertifika PFX olarak disari aktariliyor..." -Source 'LocalCA'
                Export-PfxCertificate -Cert $cert -FilePath $pfxTempPath -Password $PfxPass | Out-Null
                
                Remove-Item -Path "cert:\LocalMachine\My\$($cert.Thumbprint)" -Force -ErrorAction SilentlyContinue
                
                return [PSCustomObject]@{
                    Thumbprint  = $cert.Thumbprint
                    NotBefore   = $cert.NotBefore.ToString('o')
                    NotAfter    = $cert.NotAfter.ToString('o')
                    Issuer      = $cert.Issuer
                    PfxTempPath = $pfxTempPath
                }
            }
        }
    } catch {
        Write-PSCMLog -Level ERROR -Message ("Local CA sertifika talebi basarisiz: " + $_.Exception.Message) -Source 'LocalCA'
        # Hata durumunda temp dosyaları temizle
        if ($cerTempPath) { Remove-Item -Path $cerTempPath -Force -ErrorAction SilentlyContinue }
        if ($pfxTempPath) { Remove-Item -Path $pfxTempPath -Force -ErrorAction SilentlyContinue }
        throw
    }
}

