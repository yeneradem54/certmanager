function Get-PSCMPath {
<#
.SYNOPSIS
Istenen alt klasorun tam yolunu dondurur (yoksa olusturur).
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateSet('Config','State','Certificates','Current','Archive','Logs','Dashboard','Temp','Modules')]
        [string]$Name
    )
    $root = Get-PSCMRootPath
    $rel  = $script:PSCMPathMap[$Name]
    $full = Join-Path $root $rel
    if (-not (Test-Path -LiteralPath $full)) {
        New-Item -ItemType Directory -Path $full -Force | Out-Null
    }
    return $full
}
