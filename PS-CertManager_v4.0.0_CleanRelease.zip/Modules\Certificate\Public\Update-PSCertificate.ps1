function Update-PSCertificate {
<#
.SYNOPSIS
Sertifikayi yeniler (v2.1 helper tabanli).
#>
    [CmdletBinding(SupportsShouldProcess)]
    param([Parameter(Mandatory)][string]$Domain)
    $lockName = 'cert-' + ($Domain -replace '[^a-zA-Z0-9]','_')
    $lock = $null
    try {
        $lock = Lock-PSCMResource -Name $lockName
        $existing = Get-PSCertificate -Domain $Domain
        if (-not $existing) {
            throw (New-PSCMException -Message ('Sertifika bulunamadi: ' + $Domain) -Category 'Dogrulama' -ErrorCode 'PSCM-4010')
        }
        if (-not $PSCmdlet.ShouldProcess($Domain,'Sertifika yenile')) { return }
        $safe = ($Domain -replace '\*','wildcard') -replace '[^a-zA-Z0-9\.\-_]','_'
        $currentDir = Join-Path (Get-PSCMPath -Name Current) $safe
        if (Test-Path -LiteralPath $currentDir) {
            $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
            $archiveBase = Join-Path (Get-PSCMPath -Name Archive) $safe
            $archive = Join-Path $archiveBase $stamp
            New-Item -ItemType Directory -Path $archive -Force | Out-Null
            Get-ChildItem -Path $currentDir -File | ForEach-Object {
                Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $archive $_.Name) -Force
            }
            Write-PSCMLog -Level INFO -Message ('Onceki surum arsivlendi: ' + $archive) -Source 'Certificate'
        } else {
            New-Item -ItemType Directory -Path $currentDir -Force | Out-Null
        }
        $prev = @($existing)[0]
        $prevProps = @($prev.PSObject.Properties.Name)
        $friendly = $Domain
        if ($prevProps -contains 'FriendlyName' -and $prev.FriendlyName) { $friendly = $prev.FriendlyName }
        $wildcard = $Domain.StartsWith('*.')
        if ($prevProps -contains 'Wildcard') { $wildcard = [bool]$prev.Wildcard }
        $provider = 'ACME'
        if ($prevProps -contains 'Provider' -and $prev.Provider) { $provider = [string]$prev.Provider }
        
        $sanList = @()
        if ($prevProps -contains 'SANList' -and $prev.SANList) {
            $sanList = @($prev.SANList -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' -and $_ -ne $Domain })
        }
        
        $templateName = 'WebServer'
        if ($prevProps -contains 'TemplateName' -and $prev.TemplateName) { $templateName = [string]$prev.TemplateName }
        
        $createdAt = (Get-Date).ToString('o')
        $prevMetaFile = Join-Path $currentDir 'metadata.json'
        if (Test-Path $prevMetaFile) {
            try {
                $prevMetaObj = Read-PSCMJson -Path $prevMetaFile
                if ($prevMetaObj -and $prevMetaObj.PSObject.Properties.Name -contains 'CreatedAt' -and $prevMetaObj.CreatedAt) {
                    $createdAt = $prevMetaObj.CreatedAt
                }
                if ($prevMetaObj -and $prevMetaObj.PSObject.Properties.Name -contains 'Provider' -and $prevMetaObj.Provider) {
                    $provider = $prevMetaObj.Provider
                }
                if ($prevMetaObj -and $prevMetaObj.PSObject.Properties.Name -contains 'SANList' -and $prevMetaObj.SANList) {
                    $sanList = @($prevMetaObj.SANList -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' -and $_ -ne $Domain })
                }
                if ($prevMetaObj -and $prevMetaObj.PSObject.Properties.Name -contains 'TemplateName' -and $prevMetaObj.TemplateName) {
                    $templateName = $prevMetaObj.TemplateName
                }
            } catch { }
        }
        
        $copyRes = $null
        $localResult = $null
        
        if ($provider -eq 'ACME') {
            Write-PSCMLog -Level INFO -Message ("ACME sunucusu (Let's Encrypt) baglantisi test ediliyor...") -Source 'Certificate'
            $netCheck = Test-NetConnection -ComputerName "acme-v02.api.letsencrypt.org" -Port 443 -WarningAction SilentlyContinue
            if (-not $netCheck.TcpTestSucceeded) {
                throw (New-PSCMException -Message "Internet baglantiniz koptu veya Let's Encrypt sunucularina erisim saglanamiyor." -Category 'Network' -ErrorCode 'PSCM-5000')
            }

            $renewResult = Update-PSCMAcmeCertificate -Domain $Domain
            $copyRes = Copy-PSCMPoshAcmeOutput -AcmeResult $renewResult -Domain $Domain -Destination $currentDir
            Write-PSCMLog -Level INFO -Message ('Yenileme dosya kopyasi: ' + $copyRes.CopiedCount + ' / ' + $copyRes.TotalCount) -Source 'Certificate'
            
            $meta = [PSCustomObject]@{
                Domain=$Domain; Wildcard=$wildcard
                Issuer=$copyRes.Issuer; Thumbprint=$copyRes.Thumbprint
                NotBefore=$copyRes.NotBefore; NotAfter=$copyRes.NotAfter
                FriendlyName=$friendly; Path=$currentDir
                SourceFolder=$copyRes.SourceFolder
                CreatedAt=$createdAt; RenewedAt=(Get-Date).ToString('o')
                Provider=$provider
                SANList=($sanList -join ',')
                TemplateName=$templateName
            }
        } else {
            # LocalCA Yenileme islemi
            # Yenileme aslinda ayni domain icin yeni bir talep acmaktir
            $realPfxPass = Get-PSCMSecret -Name 'Certificate.DefaultPfxPassword'
            if (-not $realPfxPass) { throw "LocalCA yenilemesi icin varsayilan PFX parolasi (Certificate.DefaultPfxPassword) bulunamadi." }
            
            $localResult = Invoke-PSCMLocalCACertificateRequest -Domain $Domain -PfxPass $realPfxPass -TemplateName $templateName -FriendlyName $friendly -SANList $sanList
            
            $destPfx = Join-Path $currentDir "$Domain.pfx"
            Copy-Item -Path $localResult.PfxTempPath -Destination $destPfx -Force
            Remove-Item -Path $localResult.PfxTempPath -Force -ErrorAction SilentlyContinue
            
            Write-PSCMLog -Level INFO -Message ('LocalCA yenileme tamamlandi, kopyalanan dosya: ' + $destPfx) -Source 'Certificate'
            
            $meta = [PSCustomObject]@{
                Domain=$Domain; Wildcard=$wildcard
                Issuer=$localResult.Issuer; Thumbprint=$localResult.Thumbprint
                NotBefore=$localResult.NotBefore; NotAfter=$localResult.NotAfter
                FriendlyName=$friendly; Path=$currentDir
                SourceFolder=$currentDir
                CreatedAt=$createdAt; RenewedAt=(Get-Date).ToString('o')
                Provider=$provider
                SANList=($sanList -join ',')
                TemplateName=$templateName
            }
        }
        $meta | Write-PSCMJson -Path (Join-Path $currentDir 'metadata.json')
        $data = @(Get-PSCMState -Table 'certificates')
        $list = @($data | Where-Object { $_.Domain -ne $Domain })
        $list += $meta
        Set-PSCMState -Table 'certificates' -Data $list
        Write-PSCMLog -Level INFO -Message ('Sertifika yenilendi: ' + $Domain) -Source 'Certificate'
        
        try {
            $deploys = @(Get-PSCMDeploymentConfig -Domain $Domain)
            if ($deploys.Count -gt 0) {
                Write-PSCMLog -Level INFO -Message ("$Domain icin $($deploys.Count) adet deploy gorevi kuyruga ekleniyor.") -Source 'Certificate'
                $pfxFiles = @(Get-ChildItem -Path $currentDir -Filter '*.pfx' -File)
                if ($pfxFiles.Count -gt 0) {
                    $pfxPath = $pfxFiles[0].FullName
                    foreach ($d in $deploys) {
                        $pArgs = @{
                            PfxFilePath = $pfxPath
                            SiteName = $d.SiteName
                        }
                        $dProps = $d.psobject.Properties.Name
                        if ($dProps -contains 'Target' -and $d.Target) { $pArgs['Target'] = $d.Target }
                        if ($dProps -contains 'HostHeader' -and $d.HostHeader) { $pArgs['HostHeader'] = $d.HostHeader }
                        if ($dProps -contains 'PfxPass' -and $d.PfxPass) { $pArgs['PfxPass'] = $d.PfxPass }
                        if ($dProps -contains 'ComputerName' -and $d.ComputerName) { $pArgs['ComputerName'] = $d.ComputerName }
                        if ($dProps -contains 'DeployUsername' -and $d.DeployUsername) { $pArgs['DeployUsername'] = $d.DeployUsername }
                        
                        Add-PSCMAction -Action 'deploy' -Domain $Domain -Params $pArgs | Out-Null
                        Write-PSCMLog -Level INFO -Message ("Kuyruga deploy eklendi: $($d.SiteName)") -Source 'Certificate'
                    }
                } else {
                    Write-PSCMLog -Level WARNING -Message ("Deploy iptal edildi: PFX dosyasi bulunamadi ($currentDir).") -Source 'Certificate'
                }
            }
        } catch {
            Write-PSCMLog -Level ERROR -Message ("Deploy kuyruga eklenirken hata: " + $_.Exception.Message) -Source 'Certificate'
        }
        
        return $meta
    } catch {
        Write-PSCMLog -Level ERROR -Message ('Sertifika yenilenemedi: ' + $_.Exception.Message) -Source 'Certificate'
        # Rollback: arşivden son yedeği geri yükle
        try {
            $archiveBase = Join-Path (Get-PSCMPath -Name Archive) $safe
            if (Test-Path -LiteralPath $archiveBase) {
                $lastBackup = Get-ChildItem -Path $archiveBase -Directory | Sort-Object Name -Descending | Select-Object -First 1
                if ($lastBackup) {
                    $backupFiles = @(Get-ChildItem -Path $lastBackup.FullName -File)
                    if ($backupFiles.Count -gt 0) {
                        if (-not (Test-Path $currentDir)) { New-Item -ItemType Directory -Path $currentDir -Force | Out-Null }
                        foreach ($bf in $backupFiles) {
                            Copy-Item -LiteralPath $bf.FullName -Destination (Join-Path $currentDir $bf.Name) -Force
                        }
                        Write-PSCMLog -Level WARNING -Message ("Rollback yapildi: $Domain icin son arsiv ($($lastBackup.Name)) geri yuklendi.") -Source 'Certificate'
                    }
                }
            }
        } catch {
            Write-PSCMLog -Level ERROR -Message ('Rollback sirasinda hata: ' + $_.Exception.Message) -Source 'Certificate'
        }
        throw
    } finally {
        if ($lock) { Unlock-PSCMResource -Name $lockName }
    }
}
