function Get-PSCMState {
<#
.SYNOPSIS
Sistem durumunu okur (v3 Data Access Layer).
.DESCRIPTION
Ileride SQLite tabanli yapiya (v3) gecis icin ara katman. Su an JSON okur.
.EXAMPLE
$data = Get-PSCMState -Table 'certificates'
#>
    [CmdletBinding()]
    param(
        [string]$Table = 'certificates'
    )
    try {
        Initialize-PSCMSQLite
        $dbPath = Join-Path (Get-PSCMPath -Name State) "pscm.db"
        if ($Table -eq 'certificates') {
            $q = "SELECT * FROM certificates"
            $res = Invoke-SqliteQuery -DataSource $dbPath -Query $q -ErrorAction Stop
            $list = @()
            if ($res) {
                foreach ($r in $res) {
                    $list += [PSCustomObject]@{
                        Domain = $r.Domain
                        Wildcard = if ($r.Wildcard -eq 1) { $true } else { $false }
                        Issuer = $r.Issuer
                        Thumbprint = $r.Thumbprint
                        NotBefore = $r.NotBefore
                        NotAfter = $r.NotAfter
                        FriendlyName = $r.FriendlyName
                        Path = $r.Path
                        SourceFolder = $r.SourceFolder
                        CreatedAt = $r.CreatedAt
                        RenewedAt = $r.RenewedAt
                    }
                }
            }
            return $list
        }
        return @()
    } catch {
        Write-PSCMLog -Level ERROR -Message ("Get-PSCMState hatasi: " + $_.Exception.Message) -Source 'State'
        return @()
    }
}
