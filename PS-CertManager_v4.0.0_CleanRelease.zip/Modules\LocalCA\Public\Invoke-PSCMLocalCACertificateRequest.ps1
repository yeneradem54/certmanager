function Invoke-PSCMLocalCACertificateRequest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Domain,
        [Parameter(Mandatory=$false)][System.Security.SecureString]$PfxPass,
        [string]$TemplateName = 'WebServer',
        [string]$FriendlyName,
        [string[]]$SANList,
        [string]$CsrPath
    )
    
    try {
        if ($CsrPath) {
            Write-PSCMLog -Level INFO -Message "Local CA (ADCS) uzerinden CSR ile sertifika talep ediliyor: $CsrPath (Template: $TemplateName)" -Source 'LocalCA'
            if (-not (Test-Path $CsrPath)) { throw "CSR dosyasi bulunamadi: $CsrPath" }
            
            $cerPath = Join-Path $env:TEMP "$([guid]::NewGuid()).cer"
            $argsList = "-submit -attrib `"CertificateTemplate:$TemplateName`" `"$CsrPath`" `"$cerPath`""
            Write-PSCMLog -Level INFO -Message "certreq args: $argsList" -Source 'LocalCA'
            
            $p = Start-Process -FilePath "certreq.exe" -ArgumentList $argsList -Wait -NoNewWindow -PassThru
            if ($p.ExitCode -ne 0 -or -not (Test-Path $cerPath)) {
                throw "certreq basarisiz oldu veya sertifika dosyasi olusmadi. Cikis kodu: $($p.ExitCode)"
            }
            
            $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($cerPath)
            Write-PSCMLog -Level INFO -Message "Sertifika alindi, Thumbprint: $($cert.Thumbprint)" -Source 'LocalCA'
            
            return [PSCustomObject]@{
                Thumbprint = $cert.Thumbprint
                NotBefore = $cert.NotBefore.ToString('o')
                NotAfter = $cert.NotAfter.ToString('o')
                Issuer = $cert.Issuer
                CerTempPath = $cerPath
            }
        } else {
            Write-PSCMLog -Level INFO -Message "Local CA (ADCS) uzerinden otomatik sertifika talep ediliyor: $Domain (Template: $TemplateName)" -Source 'LocalCA'
            
            $allDns = @($Domain)
            if ($SANList) {
                foreach ($san in $SANList) {
                    $cleanSan = $san.Trim()
                    if ($cleanSan -and $cleanSan -ne $Domain) { $allDns += $cleanSan }
                }
            }
            
            $reqArgs = @{
                SubjectName = "CN=$Domain"
                DnsName = $allDns
                CertStoreLocation = 'cert:\LocalMachine\My'
                Template = $TemplateName
            }
            
            $certInfo = Get-Certificate @reqArgs
            $cert = $certInfo.Certificate
            
            if (-not $cert) {
                throw "Get-Certificate basarili dondu fakat sertifika nesnesi bulunamadi."
            }
            
            Write-PSCMLog -Level INFO -Message "Sertifika alindi, Thumbprint: $($cert.Thumbprint)" -Source 'LocalCA'
            
            if ($FriendlyName) { $cert.FriendlyName = $FriendlyName } else { $cert.FriendlyName = $Domain }
            
            $tempPath = Join-Path $env:TEMP "$([guid]::NewGuid()).pfx"
            
            Write-PSCMLog -Level INFO -Message "Sertifika PFX olarak disari aktariliyor..." -Source 'LocalCA'
            Export-PfxCertificate -Cert $cert -FilePath $tempPath -Password $PfxPass | Out-Null
            
            Remove-Item -Path "cert:\LocalMachine\My\$($cert.Thumbprint)" -Force -ErrorAction SilentlyContinue
            
            return [PSCustomObject]@{
                Thumbprint = $cert.Thumbprint
                NotBefore = $cert.NotBefore.ToString('o')
                NotAfter = $cert.NotAfter.ToString('o')
                Issuer = $cert.Issuer
                PfxTempPath = $tempPath
            }
        }
    } catch {
        Write-PSCMLog -Level ERROR -Message ("Local CA sertifika talebi basarisiz: " + $_.Exception.Message) -Source 'LocalCA'
        throw
    }
}
