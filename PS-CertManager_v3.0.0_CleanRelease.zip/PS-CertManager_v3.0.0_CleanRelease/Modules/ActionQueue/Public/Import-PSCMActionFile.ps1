﻿function Import-PSCMActionFile {
<#
.SYNOPSIS
HTML dashboard'dan indirilen action queue JSON dosyasini pending klasorune aktarir.
.DESCRIPTION
Dashboard'daki "Kuyrugu Indir" butonu bir JSON dosyasi indirir.
Bu dosya bir dizi aksiyon icerir. Import-PSCMActionFile her bir aksiyonu
Add-PSCMAction ile pending klasorune yazar.
.PARAMETER Path
JSON dosya yolu.
.EXAMPLE
Import-PSCMActionFile -Path C:\Downloads\pscm-queue-20260706.json
#>
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        throw (New-PSCMException -Message ('Dosya bulunamadi: ' + $Path) -Category 'Dogrulama' -ErrorCode 'PSCM-4020')
    }
    $data = Read-PSCMJson -Path $Path
    if ($null -eq $data) { throw (New-PSCMException -Message 'Dosya bos veya gecersiz JSON.' -Category 'Dogrulama' -ErrorCode 'PSCM-4021') }
    $actionsRaw = @()
    $props = @($data.PSObject.Properties.Name)
    if ($props -contains 'actions' -and $data.actions) {
        $actionsRaw = @($data.actions)
    } elseif ($props -contains 'Action' -and $props -contains 'Domain') {
        $actionsRaw = @($data)
    } else {
        throw (New-PSCMException -Message 'Dosya formati tanimlanamadi (actions alani veya Action/Domain kokleri bekleniyor).' -Category 'Dogrulama' -ErrorCode 'PSCM-4022')
    }
    $imported = 0
    foreach ($a in $actionsRaw) {
        $ap = @($a.PSObject.Properties.Name)
        $action = if ($ap -contains 'Action') { [string]$a.Action } elseif ($ap -contains 'action') { [string]$a.action } else { $null }
        $domain = if ($ap -contains 'Domain') { [string]$a.Domain } elseif ($ap -contains 'domain') { [string]$a.domain } else { $null }
        if (-not $action -or -not $domain) { continue }
        $params = @{}
        if ($ap -contains 'Params' -and $a.Params) {
            foreach ($p in $a.Params.PSObject.Properties) { $params[$p.Name] = $p.Value }
        } elseif ($ap -contains 'params' -and $a.params) {
            foreach ($p in $a.params.PSObject.Properties) { $params[$p.Name] = $p.Value }
        }
        Add-PSCMAction -Action $action -Domain $domain -Params $params | Out-Null
        $imported++
    }
    Write-PSCMLog -Level INFO -Message ('Action dosyasi ictimai: ' + $imported + ' aksiyon (' + $Path + ')') -Source 'ActionQueue'
    return $imported
}
