@{
    RootModule = 'PSCM.SSLTools.psm1'
    ModuleVersion = '4.0.0'
    CompatiblePSEditions = @('Desktop', 'Core')
    GUID = 'b6a289f0-412c-44a6-9f7f-bb5db5c965c6'
    Author = 'PS-CertManager'
    CompanyName = 'PS-CertManager'
    Copyright = '(c) PS-CertManager. All rights reserved.'
    Description = 'SSL Tools: CSR, PEM, PFX and Keystore management utilities.'
    PowerShellVersion = '5.1'
    RequiredModules = @('PSCM.Common')
    FunctionsToExport = @('Get-PSCMSslCsrInfo', 'Get-PSCMSslCertInfo', 'New-PSCMSslPfx', 'Export-PSCMSslPrivateKey', 'Export-PSCMSslKeystore', 'New-PSCMSslCsr')
    CmdletsToExport = @()
    VariablesToExport = @()
    AliasesToExport = @()
}
