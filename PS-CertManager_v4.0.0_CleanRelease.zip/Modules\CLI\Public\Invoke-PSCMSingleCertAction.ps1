# v2.3.1: $Input rezerve degisken -> $RangeText olarak yeniden adlandirildi.
function ConvertFrom-PSCMRangeString {
    param(
        [string]$RangeText,
        [int]$Max
    )
    if (-not $RangeText) { return @() }
    $t = $RangeText.Trim()
    if ($t -match '^[Aa]$') { return @(1..$Max) }
    $result = New-Object System.Collections.Generic.List[int]
    foreach ($part in $t.Split(',')) {
        $p = $part.Trim()
        if (-not $p) { continue }
        if ($p -match '^\s*(\d+)\s*-\s*(\d+)\s*$') {
            $s = [int]$matches[1]; $e = [int]$matches[2]
            if ($s -gt $e) { $tmp = $s; $s = $e; $e = $tmp }
            for ($i = $s; $i -le $e; $i++) {
                if ($i -ge 1 -and $i -le $Max) { [void]$result.Add($i) }
            }
        } elseif ($p -match '^\d+$') {
            $n = [int]$p
            if ($n -ge 1 -and $n -le $Max) { [void]$result.Add($n) }
        }
    }
    return @($result | Sort-Object -Unique)
}

function Invoke-PSCMSingleCertAction {
    param(
        [Parameter(Mandatory)][ValidateSet('Y','E','D','R','S','T','Q')][string]$Action,
        [Parameter(Mandatory)][PSCustomObject]$Cert,
        [string]$ExportDest,
        [System.Security.SecureString]$RepairPass
    )
    $dom = [string]$Cert.Domain
    try {
        switch ($Action) {
            'Y' {
                Write-Host ('  -> Yenile: ' + $dom) -ForegroundColor Cyan
                Update-PSCertificate -Domain $dom -Confirm:$false | Out-Null
                Write-Host ('     [OK] Yenilendi.') -ForegroundColor Green
            }
            'E' {
                Write-Host ('  -> Export: ' + $dom + ' -> ' + $ExportDest) -ForegroundColor Cyan
                Export-PSCertificate -Domain $dom -Destination $ExportDest -Format all | Out-Null
                Write-Host ('     [OK] Kopyalandi.') -ForegroundColor Green
            }
            'D' {
                Write-Host ('  -> Detay: ' + $dom) -ForegroundColor Cyan
                Get-PSCertificate -Domain $dom | Format-List * | Out-String -Stream | ForEach-Object { Write-Host $_ }
            }
            'R' {
                Write-Host ('  -> PFX Onar: ' + $dom) -ForegroundColor Cyan
                Repair-PSCMCertificatePfx -Domain $dom -PfxPass $RepairPass -Confirm:$false | Out-Null
                Write-Host ('     [OK] PFX onarildi.') -ForegroundColor Green
            }
            'S' {
                Write-Host ('  -> Sil (arsivle): ' + $dom) -ForegroundColor Cyan
                Remove-PSCertificate -Domain $dom -Confirm:$false | Out-Null
                Write-Host ('     [OK] Arsive tasindi.') -ForegroundColor Green
            }
            'T' {
                Write-Host ('  -> Test: ' + $dom) -ForegroundColor Cyan
                $r = Test-PSCertificate -Domain $dom
                $r | Format-List | Out-String -Stream | ForEach-Object { Write-Host $_ }
            }
            'Q' {
                Write-Host ('  -> Kuyruga ekle (renew): ' + $dom) -ForegroundColor Cyan
                Add-PSCMAction -Action renew -Domain $dom | Out-Null
                Write-Host ('     [OK] Kuyruga eklendi.') -ForegroundColor Green
            }
        }
    } catch {
        Write-Host ('     [HATA] ' + $_.Exception.Message) -ForegroundColor Red
    }
}
