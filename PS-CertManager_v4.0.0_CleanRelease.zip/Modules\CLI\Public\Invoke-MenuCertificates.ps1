function Invoke-MenuCertificates {
    Show-PSCMBanner
    Write-Host '  --- SERTIFIKA YONETIMI & ISLEMLER ---' -ForegroundColor Yellow
    Write-Host ''
    try { $certs = @(Get-PSCertificate) } catch {
        Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red; Pause-PSCM; return
    }
    if ($certs.Count -eq 0) {
        Write-Host 'Kayitli sertifika bulunamadi. Menuden yeni sertifika olusturabilirsiniz.' -ForegroundColor DarkGray
        Pause-PSCM; return
    }

    # v2.3.1 FIX: @() ile array garantisi (StrictMode-safe .Count)
    $indexed = @(Format-PSCMCertTable -Certificates $certs -PassThru)
    if ($indexed.Count -eq 0) { Pause-PSCM; return }

    Write-Host ''
    Write-Host '  [Y] Yenile   [E] Export   [D] Detay   [R] PFX Onar   [S] Sil   [T] Test' -ForegroundColor Cyan
    Write-Host ''
    Write-Host '  Enter) Ana Menuye Don' -ForegroundColor DarkGray
    Write-Host ''
    $sel = Read-Host 'Islem'
    if (-not $sel) { return }
    $sel = $sel.ToUpper()
    if ($sel -notmatch '^[YEDRSTQ]$') {
        Write-Host 'Gecersiz islem. Y/E/D/R/S/T/Q girin.' -ForegroundColor Red
        Pause-PSCM; return
    }

    Write-Host ''
    Write-Host ('  Numara(lar) girin. Ornek: 2   veya   1,3-5   veya   A (tumu)') -ForegroundColor DarkGray
    $nums = Read-Host 'Numara'
    if (-not $nums) { return }

    # v2.3.1 FIX: parametre adi $RangeText
    $indexes = @(ConvertFrom-PSCMRangeString -RangeText $nums -Max $indexed.Count)
    if ($indexes.Count -eq 0) {
        Write-Host 'Gecerli numara bulunamadi.' -ForegroundColor Red
        Pause-PSCM; return
    }

    $exportDest = $null
    $repairPass = $null
    switch ($sel) {
        'E' {
            $exportDest = Read-Host 'Hedef klasor'
            if (-not $exportDest) { Write-Host 'Hedef bos, iptal.' -ForegroundColor Red; Pause-PSCM; return }
        }
        'R' {
            Write-Host 'Yeni PFX parolasi girin (tum secilen sertifikalar icin ayni parola):'
            $repairPass = Read-Host -AsSecureString
        }
        'S' {
            Write-Host ''
            Write-Host ('  UYARI: ' + $indexes.Count + ' sertifika kaldirilacak (dosyalar Archive''a tasinir).') -ForegroundColor Yellow
            $onay = Read-Host 'Onaylayin [E/H]'
            if ($onay -notmatch '^[EeYy]') { Write-Host 'Iptal.' -ForegroundColor DarkGray; Pause-PSCM; return }
        }
    }

    Write-Host ''
    Write-Host ('Islem baslatiliyor: ' + $indexes.Count + ' sertifika') -ForegroundColor Cyan
    Write-Host ''
    foreach ($idx in $indexes) {
        $c = $indexed | Where-Object { $_.Index -eq $idx } | Select-Object -First 1
        if (-not $c) { continue }
        Invoke-PSCMSingleCertAction -Action $sel -Cert $c -ExportDest $exportDest -RepairPass $repairPass
    }
    Write-Host ''
    Write-Host 'Islem tamamlandi.' -ForegroundColor Green
    Pause-PSCM
}
