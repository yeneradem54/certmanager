﻿function Set-PSCMSecretStorePolicy {
<#
.SYNOPSIS
SecretStore parola politikasini ayarlar.
.DESCRIPTION
Uc secenek:
  Session      -> Password auth, PasswordTimeout uzatilir (8 saat varsayilan).
                  Oturum acildiginda bir kez sorar, gun boyu sormaz. (ONERILEN)
  None (DPAPI) -> Hicbir zaman parola sormaz. Sifreleme kullanici hesabina baglanir.
  Strict       -> Varsayilan davranis (15 dk timeout, her seferinde sorar).
.PARAMETER Policy
Session | None | Strict
.PARAMETER TimeoutHours
Session icin timeout suresi (varsayilan 8 saat).
.EXAMPLE
Set-PSCMSecretStorePolicy -Policy Session -TimeoutHours 8
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateSet('Session','None','Strict')]
        [string]$Policy,
        [int]$TimeoutHours = 8
    )
    Import-Module Microsoft.PowerShell.SecretStore -EA Stop

    switch ($Policy) {
        'Session' {
            $sec = $TimeoutHours * 3600
            Set-SecretStoreConfiguration -Authentication Password -Interaction Prompt -PasswordTimeout $sec -Confirm:$false
            Write-PSCMLog -Level INFO -Message ("SecretStore policy: Session (Timeout={0} saat)" -f $TimeoutHours) -Source 'Security'
            Write-Host ('  [OK] Politika: Session (Timeout=' + $TimeoutHours + ' saat)') -ForegroundColor Green
            Write-Host '        Oturum boyunca vault acik kalir. Manager-Start baslarken bir kez sorar.' -ForegroundColor DarkGray
        }
        'None' {
            Write-Host ''
            Write-Host '  UYARI: Authentication=None modu vault sifrelemesini kullanici hesabina baglar (DPAPI).' -ForegroundColor Yellow
            Write-Host '         Baska bir kullanici veya farkli makinede vault''a erisemez.' -ForegroundColor DarkYellow
            Write-Host '         Tek-kullanicili sunucular icin uygundur.' -ForegroundColor DarkYellow
            $yn = Read-Host '  Devam edilsin mi? [E/H]'
            if ($yn -notmatch '^[EeYy]') { Write-Host '  Iptal edildi.' -ForegroundColor DarkGray; return }
            Set-SecretStoreConfiguration -Authentication None -Interaction None -Confirm:$false
            Write-PSCMLog -Level INFO -Message 'SecretStore policy: None (DPAPI).' -Source 'Security'
            Write-Host '  [OK] Politika: None. Bir daha parola sorulmayacak.' -ForegroundColor Green
        }
        'Strict' {
            Set-SecretStoreConfiguration -Authentication Password -Interaction Prompt -PasswordTimeout 900 -Confirm:$false
            Write-PSCMLog -Level INFO -Message 'SecretStore policy: Strict (15 dk timeout).' -Source 'Security'
            Write-Host '  [OK] Politika: Strict. Varsayilan 15 dk timeout.' -ForegroundColor Green
        }
    }
}
