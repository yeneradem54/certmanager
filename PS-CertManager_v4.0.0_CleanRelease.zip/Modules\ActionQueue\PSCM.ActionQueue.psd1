@{
    RootModule = 'PSCM.ActionQueue.psm1'
    ModuleVersion = '4.0.0'
    GUID = '6e94b8d9-2af4-4bc7-958d-113c21ba100d'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager Action Queue Modulu (dosya tabanli asenkron gorev kuyrugu)'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Add-PSCMAction','Get-PSCMActionQueue','Invoke-PSCMActionQueue','Clear-PSCMActionQueue','Import-PSCMActionFile')
}
