﻿@{
    RootModule = 'PSCM.Bootstrap.psm1'
    ModuleVersion = '2.1.0'
    GUID = '55555555-5555-5555-5555-555555555555'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager Altyapi Kontrol ve Kurulum Modulu'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Initialize-PSCertManager','Get-PSInfrastructure','Repair-PSInfrastructure','Start-PSCMConfigWizard')
}
