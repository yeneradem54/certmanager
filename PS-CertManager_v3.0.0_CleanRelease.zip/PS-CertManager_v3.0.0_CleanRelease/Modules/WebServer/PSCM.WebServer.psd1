@{
    RootModule = 'PSCM.WebServer.psm1'
    ModuleVersion = '1.0.0'
    GUID = '12345678-0000-1111-2222-333333333333'
    Author = 'PS-CertManager Ekibi'
    CompanyName = 'PS-CertManager'
    Copyright = '(c) 2026 PS-CertManager. Tum haklari saklidir.'
    Description = 'PS-CertManager REST API & Dashboard Web Server Modulu'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Start-PSCMWebServer')
    CmdletsToExport = @()
    AliasesToExport = @()
    VariablesToExport = @()
}
