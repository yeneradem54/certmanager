# PS-CertManager v4.0.0

**Enterprise-Class Automated Certificate Lifecycle Management Framework**

PS-CertManager, karmaşık web altyapıları için tasarlanmış, modüler mimarisi sayesinde sınırsız genişletilebilir, Uçtan Uca (E2E) test edilen ve çoklu sağlayıcı mimarisine sahip kurumsal bir **SSL/TLS Sertifika Yönetim** otomasyonudur.

v4.0.0 sürümü ile birlikte, sistem artık sadece basit bir IIS sertifika kurucusu olmaktan çıkmış; **Nginx / Apache / IIS** ortamları için **Multi-CA** (Çoklu Sertifika Otoritesi) ve **Multi-DNS** destekli tam bir yaşam döngüsü yöneticisine dönüşmüştür.

---

## 🌟 Temel Yetenekler

| Yetenek | Açıklama |
|---|---|
| **Çoklu CA Desteği** | Let's Encrypt (Prod/Staging), ZeroSSL, GoDaddy CA, yerel ADCS — tek tuşla geçiş. Yeni CA eklemek tek satır. |
| **Çoklu DNS Doğrulama** | Azure DNS, Cloudflare, AWS Route53, GoDaddy API ile wildcard sertifika desteği |
| **İki Arayüz** | Interaktif PowerShell CLI menüsü + Glassmorphism tasarımlı SPA Web Dashboard |
| **REST API** | `System.Net.HttpListener` tabanlı dahili HTTP sunucu, token güvenlikli API uç noktaları |
| **Cross-Platform Dağıtım** | Windows IIS (otomatik PFX binding) + Linux Nginx/Apache (OpenSSL PEM/Key export) |
| **Uzak Sunucu Desteği** | WinRM (PowerShell Remoting) ile uzak IIS sunucularına sertifika dağıtımı |
| **Güvenli Kasa** | Tüm gizli bilgiler (API Key, şifreler, EAB) Microsoft SecretStore (DPAPI) ile şifreli saklanır |
| **Otomatik Yenileme** | Windows Task Scheduler ile zamanlanmış sertifika yenileme döngüsü |
| **Bildirim Ağı** | SMTP, Microsoft Teams, Slack ve Discord webhook bildirimleri |
| **SSL Araçları** | CSR oluşturma, PFX↔PEM dönüşümü, sertifika bilgi okuma, Java Keystore export |
| **İşlem Kuyruğu** | Dosya tabanlı asenkron görev kuyruğu (Pending → Processed / Failed) |
| **Veritabanı** | SQLite tabanlı durum yönetimi (eski JSON'dan otomatik migrasyon) |
| **Hata Dayanıklılığı** | Retry + exponential backoff mekanizması (Azure/ACME sunucu kesintilerine karşı) |
| **Test Güvencesi** | 55+ Pester birim testi + E2E Sandbox API test paketi |

---

## 🏗️ Mimari

PS-CertManager, **19 bağımsız PowerShell modülü** üzerine inşa edilmiş katmanlı bir mimari sunar:

```
┌──────────────────────────────────────────────────────────────┐
│                    PSCertManager (Master)                      │
├──────────────────────────────────────────────────────────────┤
│  Arayüz        │  CLI  │  WebServer (REST API + SPA UI)       │
├──────────────────────────────────────────────────────────────┤
│  Altyapı       │  Deployment │ Notification │ Scheduler       │
│                │  ActionQueue │ Dashboard   │ Testing          │
├──────────────────────────────────────────────────────────────┤
│  İş Mantığı    │  Certificate │ ACME │ LocalCA                │
│                │  AzureDNS    │ SSLTools                      │
├──────────────────────────────────────────────────────────────┤
│  Çekirdek      │  Common │ Settings │ Logging │ Security      │
│                │  Bootstrap                                   │
└──────────────────────────────────────────────────────────────┘
```

### Modül Özet Tablosu

| Katman | Modül | Sorumluluk |
|---|---|---|
| **Çekirdek** | `Common` | Yol çözümleme, JSON I/O, SQLite veri katmanı, Mutex kilitleme, hata nesneleri |
| | `Settings` | `settings.json` okuma/yazma, gizli alan engelleme |
| | `Logging` | Thread-safe dosya + konsol + EventLog loglama, log rotasyonu |
| | `Security` | SecretStore kasa yönetimi (CRUD + politika), DPAPI şifreleme |
| | `Bootstrap` | İlk kurulum sihirbazı, altyapı sağlık kontrolü ve onarımı |
| **İş Mantığı** | `ACME` | Posh-ACME wrapper, dinamik sağlayıcı kaydı, EAB desteği |
| | `Certificate` | Sertifika CRUD, PFX üretim/arşivleme, sağlık testi |
| | `LocalCA` | Windows ADCS sertifika talebi ve şablon yetkilendirmesi |
| | `AzureDNS` | Azure DNS Zone CRUD, DNS-01 challenge TXT kayıt yönetimi |
| | `SSLTools` | OpenSSL entegrasyonu (CSR, PFX, PEM, JKS) |
| **Altyapı** | `Deployment` | IIS/Nginx/Apache sertifika dağıtımı, uzak WinRM desteği |
| | `Notification` | SMTP, Teams, Slack, Discord bildirim motorları |
| | `Scheduler` | Windows Task Scheduler ile otomatik yenileme |
| | `ActionQueue` | Dosya tabanlı asenkron işlem kuyruğu |
| | `Dashboard` | Statik HTML rapor üretici |
| **Arayüz** | `CLI` | 25+ interaktif terminal menü fonksiyonu |
| | `WebServer` | HttpListener REST API + SPA Dashboard UI |
| | `Testing` | E2E test paketi |

---

## 📋 Gereksinimler

| Bileşen | Minimum Versiyon | Zorunlu |
|---|---|---|
| PowerShell | 5.1 / 7.x (Desktop + Core) | ✅ |
| Yönetici (Administrator) hakları | — | ✅ |
| `Microsoft.PowerShell.SecretManagement` | 1.1+ | ✅ |
| `Microsoft.PowerShell.SecretStore` | 1.0+ | ✅ |
| `Posh-ACME` | 4.x | ✅ (ACME sertifikaları için) |
| `PSSQLite` | 1.x | ✅ |
| OpenSSL | 3.x | ⚠️ (Nginx/Apache export için) |
| `Az.Accounts` + `Az.Dns` | — | ⚠️ (Azure DNS kullanılıyorsa) |
| IIS (`Microsoft.Web.Administration`) | — | ⚠️ (IIS dağıtımı için) |

---

## 🚀 Hızlı Başlangıç

### 1. Projeyi İndirin
```powershell
# Projeyi istediğiniz dizine kopyalayın
git clone https://github.com/your-org/PS-CertManager.git
cd PS-CertManager
```

### 2. Yönetici Olarak Başlatın
```powershell
# PowerShell'i Yönetici (Administrator) olarak açın
.\Manager-Start.ps1
```

### 3. İlk Yapılandırma
İlk çalıştırmada sistem otomatik olarak:
- Eksik bağımlılıkları kontrol eder ve kurar (`Repair-PSInfrastructure`)
- Dizin yapısını oluşturur (Config, Certificates, Logs, Temp)
- SQLite veritabanını başlatır
- `Start-PSCMConfigWizard` sihirbazını başlatır:
  - Azure DNS kimlik bilgileri
  - ACME hesap e-postası ve CA seçimi
  - DNS doğrulama eklentisi
  - Varsayılan PFX parolası (SecretStore'a şifreli kaydedilir)

### 4. Web Dashboard
```powershell
# CLI menüsünden veya doğrudan:
Start-PSCMWebServer
# Tarayıcınızda http://localhost:8080 adresini açın
```

---

## 🖥️ CLI Menü Yapısı

```
Ana Menü
├── [1] İşlemler
│   ├── Sertifika Listesi & Toplu İşlem
│   ├── Yeni Sertifika Sihirbazı
│   ├── Deployment (Sunucu Dağıtım)
│   └── İşlem Kuyruğu (ActionQueue)
├── [2] Ayarlar
│   ├── Entegrasyon & Sistem Ayarları (CA/DNS/Kasa)
│   ├── Bildirim Kanalları
│   ├── SSL Araçları (CSR/PFX/PEM)
│   └── DNS Eklenti Ayarları
├── [3] Bakım & Loglar
│   ├── Sistem Sağlık Raporu
│   ├── Dashboard Oluştur
│   ├── Log Görüntüle
│   ├── Zamanlayıcı (Scheduler)
│   ├── Yapılandırma Sihirbazı
│   ├── Pester Testleri
│   └── Yardım & Komut Referansı
└── [W] Web Dashboard Başlat
```

---

## 🌐 REST API Uç Noktaları

| Metot | Endpoint | Açıklama |
|---|---|---|
| GET | `/api/v1/certificates` | Sertifika listesi |
| POST | `/api/v1/certificates/new` | Yeni sertifika oluştur |
| POST | `/api/v1/certificates/renew` | Sertifika yenile |
| GET | `/api/v1/settings` | Sistem ayarlarını oku |
| POST | `/api/v1/settings` | Ayar değerini güncelle |
| GET | `/api/v1/secrets/status` | Kasadaki anahtarların durumu (var/yok) |
| POST | `/api/v1/secrets` | Kasaya gizli anahtar kaydet |
| GET | `/api/v1/acme/providers` | Desteklenen ACME sağlayıcı listesi |
| GET | `/api/v1/infrastructure` | Sistem sağlık raporu |
| GET | `/api/v1/logs` | Filtrelenmiş log kayıtları |
| GET | `/api/v1/actionqueue` | İşlem kuyruğu durumu |
| GET | `/api/v1/scheduler` | Zamanlanmış görevler |
| GET | `/api/v1/system/summary` | Özet istatistikler (dashboard kartları) |
| POST | `/api/v1/notifications/test` | Bildirim kanalı test et |
| POST | `/api/v1/ssl-tools/*` | CSR analiz, PFX oluştur, sertifika bilgisi oku |
| POST | `/api/v1/system/reset` | Fabrika sıfırlaması (Danger Zone) |

> Tüm POST istekleri `X-PSCM-Token` başlığı ile korunur. Token, sunucu başladığında otomatik üretilir ve `index.html`'e gömülür.

---

## 🔌 Yeni ACME Sağlayıcı Ekleme

Yeni bir ACME CA (örn. Metunic) eklemek için **yalnızca bir dosyaya tek satır** eklemeniz yeterlidir:

**`Modules/ACME/Public/Get-PSCMAcmeProviders.ps1`** dosyasına:
```powershell
[PSCustomObject]@{
    Name         = 'Metunic'
    DisplayName  = 'Metunic CA (Ucretli)'
    DirectoryUrl = 'https://acme.metunic.com/directory'
    RequireEAB   = $true
}
```

Bu tek satır eklemesi otomatik olarak şunları günceller:
- ✅ CLI Yeni Sertifika menüsü
- ✅ CLI Entegrasyon Ayarları menüsü (EAB alanları dahil)
- ✅ Web Dashboard CA dropdown'ı
- ✅ Web Dashboard Yeni Sertifika modalı
- ✅ ACME sertifika üretim fabrikası

---

## 🧪 Testler

```powershell
# Birim testlerini çalıştır (55+ test)
Invoke-Pester -Path .\Tests\

# E2E Sandbox testlerini çalıştır
Invoke-PSCMTestSuite
```

---

## 📦 Dağıtım Paketi Oluşturma

```powershell
.\Build-Release.ps1
# Çıktı: PS-CertManager-Release-vX.X.X.zip
# Kişisel veriler, loglar, veritabanı ve sertifikalar otomatik temizlenir.
```

---

## 📁 Proje Yapısı

```
PS-CertManager/
├── Manager-Start.ps1          # CLI giriş noktası
├── Build-Release.ps1          # Release paketleyici
├── Config/settings.json       # Merkezi yapılandırma
├── Certificates/              # PFX sertifika deposu
├── Logs/                      # Uygulama logları
├── Temp/                      # Proje-yerel geçici dosyalar
├── Tests/                     # Pester birim testleri
└── Modules/                   # 19 PowerShell modülü
    ├── PSCertManager/         # Ana konteyner modül
    ├── Common/                # Çekirdek altyapı (SQLite, JSON, Mutex)
    ├── Settings/              # Yapılandırma yönetimi
    ├── Logging/               # Thread-safe loglama
    ├── Security/              # SecretStore kasa yönetimi
    ├── Bootstrap/             # İlk kurulum ve sağlık kontrolü
    ├── ACME/                  # ACME protokolü (Posh-ACME)
    ├── Certificate/           # Sertifika yaşam döngüsü
    ├── LocalCA/               # Windows ADCS entegrasyonu
    ├── AzureDNS/              # Azure DNS Zone yönetimi
    ├── SSLTools/              # OpenSSL araç seti
    ├── Deployment/            # IIS/Nginx/Apache dağıtım
    ├── Notification/          # Çoklu kanal bildirim
    ├── Scheduler/             # Windows Task Scheduler
    ├── ActionQueue/           # Dosya tabanlı kuyruk
    ├── Dashboard/             # HTML rapor üretici
    ├── WebServer/             # REST API + SPA Web UI
    ├── CLI/                   # Terminal menü sistemi
    └── Testing/               # E2E test paketi
```

---

## 📜 Lisans

MIT License — Detaylar için `LICENSE` dosyasına bakın.
