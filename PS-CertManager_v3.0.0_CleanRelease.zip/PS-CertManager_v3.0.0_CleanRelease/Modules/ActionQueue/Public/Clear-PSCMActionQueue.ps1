﻿function Clear-PSCMActionQueue {
<#
.SYNOPSIS
Action queue klasorunu temizler (retention politikasi).
.PARAMETER Status
Hangi klasor temizlensin: pending, processed, failed, all
.PARAMETER OlderThanDays
Bu kadar gunden eski dosyalari sil.
#>
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [ValidateSet('pending','processed','failed','all')]
        [string]$Status = 'processed',
        [int]$OlderThanDays = 30
    )
    $root = Get-PSCMActionRoot
    $folders = if ($Status -eq 'all') { @('pending','processed','failed') } else { @($Status) }
    $cutoff = (Get-Date).AddDays(-$OlderThanDays)
    $removed = 0
    foreach ($f in $folders) {
        $dir = Join-Path $root $f
        $files = Get-ChildItem -Path $dir -Filter '*.json' -EA SilentlyContinue | Where-Object { $_.LastWriteTime -lt $cutoff }
        foreach ($file in $files) {
            if ($PSCmdlet.ShouldProcess($file.Name,'Sil')) {
                Remove-Item -LiteralPath $file.FullName -Force
                $removed++
            }
        }
    }
    Write-PSCMLog -Level INFO -Message ('Action queue temizlendi: ' + $removed + ' dosya (Status: ' + $Status + ', ' + $OlderThanDays + ' gunden eski)') -Source 'ActionQueue'
    return $removed
}
