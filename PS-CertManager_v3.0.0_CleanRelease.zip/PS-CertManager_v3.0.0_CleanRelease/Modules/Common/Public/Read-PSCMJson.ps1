﻿function Read-PSCMJson {
<#
.SYNOPSIS
JSON dosyasini guvenli sekilde okuyup PSCustomObject dondurur.
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [switch]$AsHashtable
    )
    if (-not (Test-Path -LiteralPath $Path)) {
        throw (New-Object PSCMConfigException("JSON dosyasi bulunamadi: $Path"))
    }
    try {
        $raw = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
        if ([string]::IsNullOrWhiteSpace($raw)) { return $null }
        if ($AsHashtable -and $PSVersionTable.PSVersion.Major -ge 6) {
            return ($raw | ConvertFrom-Json -AsHashtable)
        }
        return ($raw | ConvertFrom-Json)
    } catch {
        throw (New-Object PSCMConfigException("JSON okuma hatasi ($Path): $($_.Exception.Message)"))
    }
}
