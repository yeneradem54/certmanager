﻿function Get-PSLog {
<#
.SYNOPSIS
Log kayitlarini getirir.
#>
    [CmdletBinding()]
    param(
        [ValidateSet('DEBUG','INFO','WARNING','ERROR','ALL')][string]$Level = 'ALL',
        [int]$Last = 100,
        [int]$Days = 1
    )
    $logDir = Get-PSCMPath -Name Logs
    $files = @()
    for ($i = 0; $i -lt $Days; $i++) {
        $d = (Get-Date).AddDays(-$i).ToString('yyyyMMdd')
        $f = Join-Path $logDir ('pscm-{0}.log' -f $d)
        if (Test-Path -LiteralPath $f) { $files += $f }
    }
    if (-not $files) { return @() }
    $lines = foreach ($f in $files) { Get-Content -LiteralPath $f -Encoding UTF8 }
    if ($Level -ne 'ALL') {
        $lines = $lines | Where-Object { $_ -match ('\[' + [regex]::Escape($Level.PadRight(7)) + '\]') }
    }
    return $lines | Select-Object -Last $Last
}
