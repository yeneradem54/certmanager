function Initialize-PSCMAcmeProvider {
<#
.SYNOPSIS
ACME saglayici somut nesnesini olusturur (fabrika).
#>
    [CmdletBinding()]
    param(
        [string]$ProviderOverride
    )
    $s = Get-PSSettings -Section 'Acme'
    $providerName = 'LetsEncrypt'
    if ($ProviderOverride) {
        $providerName = $ProviderOverride
    } elseif ($s.PSObject.Properties.Name -contains 'Provider' -and -not [string]::IsNullOrWhiteSpace($s.Provider)) {
        $providerName = $s.Provider
    }
    
    $allProviders = Get-PSCMAcmeProviders
    $matched = $allProviders | Where-Object { $_.Name -eq $providerName } | Select-Object -First 1
    if (-not $matched) {
        throw (New-PSCMException -Message ("Desteklenmeyen ACME saglayici: " + $providerName) -Category 'ACME' -ErrorCode 'PSCM-1010')
    }
    
    return (New-Object PSCMPoshAcmeProvider($matched.Name, $matched.DirectoryUrl))
}
