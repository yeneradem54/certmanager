﻿#Requires -Version 5.1
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'
$script:PSCMVaultName = 'PSCertManagerVault'
$script:PSCMSecretModule = 'Microsoft.PowerShell.SecretManagement'
$script:PSCMSecretStoreModule = 'Microsoft.PowerShell.SecretStore'
Get-ChildItem -Path (Join-Path $PSScriptRoot 'Public') -Filter '*.ps1' -EA SilentlyContinue | ForEach-Object { . $_.FullName }
Export-ModuleMember -Function @('Initialize-PSCMSecretStore','Set-PSCMSecret','Get-PSCMSecret','Remove-PSCMSecret','Unlock-PSCMSecretStore','Set-PSCMSecretStorePolicy')
