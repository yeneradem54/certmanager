﻿function Repair-PSCMCertificatePfx {
<#
.SYNOPSIS
Mevcut bir sertifikanin PFX dosyasini dogru parolayla yeniden export eder.
.DESCRIPTION
v2.2 ve oncesinde PfxPass SecureString hatasi nedeniyle uretilen .pfx dosyalari
hatali parolayla sifrelenmisti. Bu fonksiyon Posh-ACME cache''i uzerinden
yeniden export yapar, ACME dogrulama TETIKLENMEZ (rate limit'e girmezsiniz).
.PARAMETER Domain
Onarilacak sertifikanin domain'i (wildcard icin *.ornek.com).
.PARAMETER PfxPass
Yeni PFX parola (SecureString).
.EXAMPLE
$p = Read-Host -AsSecureString 'Yeni PFX parola'
Repair-PSCMCertificatePfx -Domain 'vle.com.tr' -PfxPass $p
#>
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][string]$Domain,
        [Parameter(Mandatory)][System.Security.SecureString]$PfxPass
    )
    $lockName = 'cert-' + ($Domain -replace '[^a-zA-Z0-9]','_')
    $lock = $null
    try {
        $lock = Lock-PSCMResource -Name $lockName
        Write-PSCMLog -Level INFO -Message ('PFX onarim baslatildi: ' + $Domain) -Source 'Certificate'
        if (-not $PSCmdlet.ShouldProcess($Domain,'PFX yeniden export et')) { return }

        Import-Module Posh-ACME -EA Stop
        $paCert = Get-PACertificate -MainDomain $Domain -EA SilentlyContinue
        if (-not $paCert) {
            throw (New-PSCMException -Message ('Posh-ACME cache''inde sertifika yok: ' + $Domain + '. Yeni sertifika olusturun.') -Category 'ACME' -ErrorCode 'PSCM-1040')
        }

        $pfxPlain = $null
        $bstr     = [IntPtr]::Zero
        $result   = $null
        try {
            $bstr     = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($PfxPass)
            $pfxPlain = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
            if ([string]::IsNullOrEmpty($pfxPlain)) {
                throw (New-PSCMException -Message 'PfxPass bos olamaz.' -Category 'Dogrulama' -ErrorCode 'PSCM-4030')
            }
            $result = New-PACertificate -Domain $Domain -PfxPass $pfxPlain -Install:$false -Force
        } finally {
            if ($bstr -ne [IntPtr]::Zero) {
                [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
            }
            $pfxPlain = $null
            [System.GC]::Collect()
        }

        if (-not $result) {
            throw (New-PSCMException -Message 'Posh-ACME yeniden export basarisiz.' -Category 'ACME' -ErrorCode 'PSCM-1041')
        }

        $safe = ($Domain -replace '\*','wildcard') -replace '[^a-zA-Z0-9\.\-_]','_'
        $target = Join-Path (Get-PSCMPath -Name Current) $safe
        if (-not (Test-Path $target)) { New-Item -ItemType Directory -Path $target -Force | Out-Null }

        # Onceki (hatali) dosyalari archive'a al
        if (Test-Path -LiteralPath $target) {
            $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
            $archive = Join-Path (Join-Path (Get-PSCMPath -Name Archive) $safe) ('pfxrepair_' + $stamp)
            New-Item -ItemType Directory -Path $archive -Force | Out-Null
            Get-ChildItem -Path $target -File -EA SilentlyContinue | ForEach-Object {
                Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $archive $_.Name) -Force
            }
            Write-PSCMLog -Level INFO -Message ('Onceki (hatali parolali) dosyalar arsivlendi: ' + $archive) -Source 'Certificate'
        }

        $copyRes = Copy-PSCMPoshAcmeOutput -AcmeResult $result -Domain $Domain -Destination $target
        Write-PSCMLog -Level INFO -Message ('Onarim - kopyalanan dosya: ' + $copyRes.CopiedCount + ' / ' + $copyRes.TotalCount) -Source 'Certificate'

        $existing = @(Get-PSCertificate -Domain $Domain)[0]
        $friendly = if ($existing -and ($existing.PSObject.Properties.Name -contains 'FriendlyName') -and $existing.FriendlyName) { $existing.FriendlyName } else { $Domain }
        $wildcard = $Domain.StartsWith('*.')
        if ($existing -and ($existing.PSObject.Properties.Name -contains 'Wildcard')) { $wildcard = [bool]$existing.Wildcard }

        $createdAt = (Get-Date).ToString('o')
        $prevMetaFile = Join-Path $target 'metadata.json'
        if (Test-Path $prevMetaFile) {
            try {
                $prevObj = Read-PSCMJson -Path $prevMetaFile
                if ($prevObj -and ($prevObj.PSObject.Properties.Name -contains 'CreatedAt') -and $prevObj.CreatedAt) {
                    $createdAt = $prevObj.CreatedAt
                }
            } catch { }
        }

        $meta = [PSCustomObject]@{
            Domain       = $Domain
            Wildcard     = $wildcard
            Issuer       = $copyRes.Issuer
            Thumbprint   = $copyRes.Thumbprint
            NotBefore    = $copyRes.NotBefore
            NotAfter     = $copyRes.NotAfter
            FriendlyName = $friendly
            Path         = $target
            SourceFolder = $copyRes.SourceFolder
            CreatedAt    = $createdAt
            RepairedAt   = (Get-Date).ToString('o')
        }
        $meta | Write-PSCMJson -Path (Join-Path $target 'metadata.json')

        $idx = Join-Path (Get-PSCMPath -Name State) 'certificates.json'
        if (Test-Path $idx) { $data = Read-PSCMJson -Path $idx } else { $data = [PSCustomObject]@{ certificates = @() } }
        $list = @($data.certificates | Where-Object { $_.Domain -ne $Domain })
        $list += $meta
        [PSCustomObject]@{ certificates = $list } | Write-PSCMJson -Path $idx

        Write-PSCMLog -Level INFO -Message ('PFX onarildi: ' + $Domain + ' | Thumbprint: ' + $copyRes.Thumbprint) -Source 'Certificate'
        Write-Host ('  [OK] PFX yeniden uretildi: ' + (Join-Path $target 'fullchain.pfx')) -ForegroundColor Green
        return $meta
    } catch {
        Write-PSCMLog -Level ERROR -Message ('PFX onarim hatasi: ' + $_.Exception.Message) -Source 'Certificate'
        throw
    } finally {
        if ($lock) { Unlock-PSCMResource -Name $lockName }
    }
}
