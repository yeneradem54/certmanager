﻿function Remove-PSCMDnsZone {
<#
.SYNOPSIS
Kayitli DNS zone listesinden bir zone'u kaldirir.
#>
    [CmdletBinding(SupportsShouldProcess)]
    param([Parameter(Mandatory)][string]$Name)
    if (-not $PSCmdlet.ShouldProcess($Name,'DNS zone kaldir')) { return }
    $path = Join-Path (Get-PSCMPath -Name Config) 'settings.json'
    $data = Read-PSCMJson -Path $path
    $az = $data.Azure
    if ($az.PSObject.Properties.Name -contains 'DnsZones' -and $az.DnsZones) {
        $filtered = @($az.DnsZones | Where-Object { $_.Name -ne $Name })
        $data.Azure | Add-Member -NotePropertyName 'DnsZones' -NotePropertyValue $filtered -Force
    }
    if ($az.PSObject.Properties.Name -contains 'DnsZone' -and $az.DnsZone -eq $Name) {
        $data.Azure | Add-Member -NotePropertyName 'DnsZone' -NotePropertyValue '' -Force
    }
    $data | Write-PSCMJson -Path $path
    Write-PSCMLog -Level INFO -Message ('DNS zone kaldirildi: ' + $Name) -Source 'AzureDNS'
}
