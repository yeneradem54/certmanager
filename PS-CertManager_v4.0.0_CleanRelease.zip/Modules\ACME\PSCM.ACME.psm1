#Requires -Version 5.1
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Private\PSCMAcmeContract.ps1')
Get-ChildItem -Path (Join-Path $PSScriptRoot 'Public') -Filter '*.ps1' -EA SilentlyContinue | ForEach-Object { . $_.FullName }
Export-ModuleMember -Function @('Initialize-PSCMAcmeProvider','New-PSCMAcmeCertificate','Update-PSCMAcmeCertificate','Get-PSCMAcmeProviders')
