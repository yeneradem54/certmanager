﻿function Get-PSCMDnsZone {
<#
.SYNOPSIS
Yapilandirilmis Azure DNS Zone nesnesini dondurur.
#>
    [CmdletBinding()]
    param()
    Connect-PSCMAzure | Out-Null
    $s = Get-PSSettings -Section 'Azure'
    Import-Module Az.Dns -EA Stop
    return (Get-AzDnsZone -ResourceGroupName $s.ResourceGroup -Name $s.DnsZone)
}
