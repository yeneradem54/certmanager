﻿@{
    RootModule = 'PSCM.Logging.psm1'
    ModuleVersion = '2.1.0'
    GUID = '22222222-2222-2222-2222-222222222222'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager Merkezi Loglama Modulu'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Write-PSCMLog','Get-PSLog','Invoke-PSCMLogRotation')
}
