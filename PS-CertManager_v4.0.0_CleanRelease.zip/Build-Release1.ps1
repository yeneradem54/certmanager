<#
.SYNOPSIS
PS-CertManager uygulamasını kişisel verilerden (veritabanı, loglar, sertifikalar, ayarlar) arındırarak 
başkalarıyla paylaşılabilecek temiz bir ZIP sürümü haline getirir.
.DESCRIPTION
- Tüm özel sertifikaları, logları, SQLite veritabanını ve kişisel ayarları temizler.
- v4.0.x mimarisine uygun temiz settings.json ve Settings.example.json şablonları üretir.
- Boş olması gereken klasör hiyerarşisini (.gitkeep ile) korur (Logs, Temp, Certificates, State actions).
- .git, .gemini, .vscode, .bak, geçici ve geliştirici dosyalarını eler.
- Sıkıştırmayı [System.IO.Compression.ZipFile] ile yaparak klasör yapısının bozulmamasını garanti eder.
- Paket içeriğini güvenlik ve gizlilik denetiminden geçirerek raporlar.
.PARAMETER DestinationFolder
ZIP dosyasının oluşturulacağı klasör. Varsayılan: Kullanıcı Masaüstü.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$false)]
    [string]$DestinationFolder = [Environment]::GetFolderPath('Desktop')
)

$ErrorActionPreference = 'Stop'

Write-Host "=========================================" -ForegroundColor Cyan
Write-Host " PS-CertManager Temiz Sürüm Paketleyici  " -ForegroundColor Cyan
Write-Host "=========================================" -ForegroundColor Cyan
Write-Host ""

$ScriptRoot = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }

if (-not (Test-Path $DestinationFolder)) {
    New-Item -ItemType Directory -Path $DestinationFolder -Force | Out-Null
}

# Versiyonu manifest dosyasından dinamik olarak oku
$manifestPath = Join-Path $ScriptRoot 'Modules\PSCertManager\PSCertManager.psd1'
if (-not (Test-Path $manifestPath)) {
    Write-Host "[HATA] Modül manifest dosyası bulunamadı: $manifestPath" -ForegroundColor Red
    Write-Host "       Script'in proje kök dizininde olduğundan emin olun." -ForegroundColor Red
    return
}
$manifestData = Import-PowerShellDataFile -Path $manifestPath
$version = $manifestData.ModuleVersion

Write-Host "   Sürüm   : v$version" -ForegroundColor Gray
Write-Host "   Kaynak  : $ScriptRoot" -ForegroundColor Gray
Write-Host "   Hedef   : $DestinationFolder" -ForegroundColor Gray
Write-Host ""

$ReleaseZipPath = Join-Path $DestinationFolder "PS-CertManager_v${version}_CleanRelease.zip"

# Staging (Hazırlık) dizinini oluştur
$StagingDir = Join-Path $env:TEMP "PSCM_Staging_$([guid]::NewGuid().ToString('N').Substring(0,8))"
if (Test-Path $StagingDir) {
    Remove-Item -Path $StagingDir -Recurse -Force -ErrorAction SilentlyContinue
}
New-Item -ItemType Directory -Path $StagingDir -Force | Out-Null

try {
    Write-Host "-> 1. Kaynak dosyalar hazirlik alanina kopyalaniyor..." -ForegroundColor Yellow
    Copy-Item -Path "$ScriptRoot\*" -Destination $StagingDir -Recurse -Force

    Write-Host "-> 2. Kisisel veriler, sertifikalar ve loglar temizleniyor..." -ForegroundColor Yellow

    # 2.1 Temizlenecek klasörlerin içini tamamen boşalt
    $foldersToWipe = @(
        "Logs",
        "Temp",
        "Certificates\Current",
        "Certificates\Archive",
        "Config\State"
    )
    foreach ($folder in $foldersToWipe) {
        $targetFolder = Join-Path $StagingDir $folder
        if (Test-Path $targetFolder) {
            Remove-Item -Path "$targetFolder\*" -Recurse -Force -ErrorAction SilentlyContinue
        }
    }

    # 2.2 Gerekli boş klasör hiyerarşisini .gitkeep ile kur (Zip archiver'ların klasörleri yutmaması için)
    $requiredFolders = @(
        "Logs",
        "Temp",
        "Certificates\Current",
        "Certificates\Archive",
        "Config\State\actions\pending",
        "Config\State\actions\processed",
        "Config\State\actions\failed"
    )
    foreach ($folder in $requiredFolders) {
        $targetFolder = Join-Path $StagingDir $folder
        if (-not (Test-Path $targetFolder)) {
            New-Item -ItemType Directory -Path $targetFolder -Force | Out-Null
        }
        $keepFile = Join-Path $targetFolder ".gitkeep"
        Set-Content -Path $keepFile -Value "" -NoNewline -Encoding ASCII
    }

    # 2.3 Proje genelinde uzantı bazlı temizlik (.bak, .log, .db vb.)
    Get-ChildItem -Path $StagingDir -Filter "*.bak" -Recurse -Force -ErrorAction SilentlyContinue | Remove-Item -Force
    Get-ChildItem -Path $StagingDir -Filter "*.log" -Recurse -Force -ErrorAction SilentlyContinue | Remove-Item -Force
    Get-ChildItem -Path $StagingDir -Include "*.db", "*.db-journal", "*.db-wal", "*.db-shm" -Recurse -Force -ErrorAction SilentlyContinue | Remove-Item -Force
    Get-ChildItem -Path (Join-Path $StagingDir "Certificates") -Include "*.pfx", "*.cer", "*.crt", "*.key", "*.pem", "*.csr" -Recurse -Force -ErrorAction SilentlyContinue | Remove-Item -Force

    # 2.4 Geliştirici, IDE ve Git kalıntılarını temizle
    $dirsToRemove = @(
        ".git",
        ".history",
        ".gemini",
        ".vscode",
        ".idea"
    )
    foreach ($dir in $dirsToRemove) {
        $targetDir = Join-Path $StagingDir $dir
        if (Test-Path $targetDir) { Remove-Item -Path $targetDir -Recurse -Force }
    }

    # 2.5 Dağıtıma dahil edilmeyecek geliştirici dosyalarını temizle
    $filesToRemove = @(
        "AI-REBUILD-PROMPT.md",
        "PROJECT-INDEX.md",
        "Build-Release - Kopya.ps1",
        "Build-Release.ps1",
        "Tests\TestResults.xml"
    )
    foreach ($file in $filesToRemove) {
        $targetFile = Join-Path $StagingDir $file
        if (Test-Path $targetFile) { Remove-Item -Path $targetFile -Force }
    }

    # Staging içinde yanlışlıkla kalan zip'leri temizle
    Get-ChildItem -Path $StagingDir -Filter "*.zip" -ErrorAction SilentlyContinue | Remove-Item -Force

    # 2.6 v4.0.x uyumlu temiz settings.json ve Settings.example.json oluştur
    $cleanSettings = [ordered]@{
        Version = $version
        General = [ordered]@{
            IsConfigured = $false
        }
        Azure = [ordered]@{
            TenantId = ""
            SubscriptionId = ""
            ResourceGroup = ""
            DnsZone = ""
            ClientId = ""
            AuthMode = "Interactive"
        }
        Acme = [ordered]@{
            Provider = "LetsEncrypt"
            DnsPlugin = "Azure"
            AccountEmail = ""
            KeyLength = "2048"
            ChallengeType = "dns-01"
            Client = "Posh-ACME"
        }
        Certificate = [ordered]@{
            DefaultExportFormat = "pfx"
            RenewalThresholdDay = 30
            AutoRenew = $true
        }
        Notification = [ordered]@{
            Enabled = $false
            Smtp = [ordered]@{
                Server = ""
                Port = 587
                UseTls = $true
                From = ""
                Username = ""
                To = @()
            }
            Teams = [ordered]@{
                Enabled = $false
                WebhookRef = "Teams.WebhookUrl"
            }
            SlackWebhook = ""
            DiscordWebhook = ""
        }
        Logging = [ordered]@{
            MinimumLevel = "INFO"
            MaxSizeMB = 10
            RetentionDays = 90
        }
        Paths = [ordered]@{
            OutputFolder = "Certificates\\Current"
            ArchiveFolder = "Certificates\\Archive"
        }
        Deployment = [ordered]@{}
        Defaults = [ordered]@{
            Provider = "ACME"
            TemplateName = "WebServer"
            StoreName = "WebHosting"
        }
    }

    $cleanSettingsJson = $cleanSettings | ConvertTo-Json -Depth 6
    $configDir = Join-Path $StagingDir "Config"
    if (-not (Test-Path $configDir)) { New-Item -ItemType Directory -Path $configDir -Force | Out-Null }
    
    # Hem varsayılan settings.json hem de Settings.example.json olarak yaz
    [System.IO.File]::WriteAllText((Join-Path $configDir "settings.json"), $cleanSettingsJson, [System.Text.Encoding]::UTF8)
    [System.IO.File]::WriteAllText((Join-Path $configDir "Settings.example.json"), $cleanSettingsJson, [System.Text.Encoding]::UTF8)

    Write-Host "-> 3. ZIP paketi olusturuluyor ($ReleaseZipPath)..." -ForegroundColor Yellow
    if (Test-Path $ReleaseZipPath) {
        Remove-Item -Path $ReleaseZipPath -Force
    }

    # .NET ZipFile kullanarak boş klasörleri de içeren sağlam arşiv oluştur
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::CreateFromDirectory($StagingDir, $ReleaseZipPath, [System.IO.Compression.CompressionLevel]::Optimal, $false)

    Write-Host "-> 4. Guvenlik ve paket dogrulamasi yapiliyor..." -ForegroundColor Yellow

    # ZIP paketini açarak denetle
    $archive = [System.IO.Compression.ZipFile]::OpenRead($ReleaseZipPath)
    $entryNames = @($archive.Entries | Select-Object -ExpandProperty FullName)
    $archive.Dispose()

    $leaks = @()
    $leaks += @($entryNames | Where-Object { $_ -match '\.(db|db-wal|db-shm|log|pfx|key|bak)$' })
    $leaks += @($entryNames | Where-Object { $_ -match '(^|\\)\.git($|\\)' -or $_ -match '(\.gemini|\.vscode|\.idea|AI-REBUILD)' })

    if ($leaks.Count -gt 0) {
        Write-Host "[UYARI] Pakette istenmeyen dosyalar tespit edildi:" -ForegroundColor Red
        $leaks | ForEach-Object { Write-Host "   - $_" -ForegroundColor DarkYellow }
    } else {
        Write-Host "   [ OK ] Kisisel veri veya log sizintisi tespit edilmedi." -ForegroundColor Green
    }

    # Kritik klasör varlık denetimi
    $criticalFolders = @('Logs', 'Temp', 'Certificates\Current', 'Certificates\Archive', 'Config\State\actions\pending')
    $missingInZip = @()
    foreach ($cf in $criticalFolders) {
        $found = $entryNames | Where-Object { $_ -match ("^" + [regex]::Escape($cf)) }
        if (-not $found) { $missingInZip += $cf }
    }

    if ($missingInZip.Count -gt 0) {
        Write-Host "[UYARI] Bazi kritik klasorler ZIP icinde bulunamadi: $($missingInZip -join ', ')" -ForegroundColor DarkYellow
    } else {
        Write-Host "   [ OK ] Tum calisma klasorleri ZIP icinde eksiksiz mevcut." -ForegroundColor Green
    }

    $zipSize = (Get-Item $ReleaseZipPath).Length
    $zipSizeMB = [math]::Round($zipSize / 1MB, 2)

    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Green
    Write-Host " [ BASARILI ] Temiz surum ZIP paketi hazirlandi!           " -ForegroundColor Green
    Write-Host "============================================================" -ForegroundColor Green
    Write-Host " Dosya : $ReleaseZipPath" -ForegroundColor White
    Write-Host " Boyut : $zipSizeMB MB ($($entryNames.Count) oge)" -ForegroundColor Gray
    Write-Host ""
}
finally {
    if (Test-Path $StagingDir) {
        Remove-Item -Path $StagingDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}
