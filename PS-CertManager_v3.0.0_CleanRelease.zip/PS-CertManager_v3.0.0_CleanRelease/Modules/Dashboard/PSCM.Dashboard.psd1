﻿@{
    RootModule = 'PSCM.Dashboard.psm1'
    ModuleVersion = '2.1.0'
    GUID = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager HTML Dashboard Modulu'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Get-PSDashboard','New-PSDashboard')
}
