﻿function Initialize-PSCertManager {
<#
.SYNOPSIS
PS-CertManager platformunu ilk kez calistirmaya hazirlar.
#>
    [CmdletBinding()]
    param([switch]$Force)
    Write-PSCMLog -Level INFO -Message 'PS-CertManager baslatiliyor.' -Source 'Bootstrap'
    $report = Get-PSInfrastructure
    $missing = $report | Where-Object { $_.Durum -in @('EKSIK','HATA') }
    if ($missing) {
        Write-PSCMLog -Level WARNING -Message ('Eksik/hatali bilesen sayisi: ' + $missing.Count) -Source 'Bootstrap'
        Repair-PSInfrastructure -Force:$Force | Out-Null
    }
    Write-PSCMLog -Level INFO -Message 'PS-CertManager baslatildi.' -Source 'Bootstrap'
    return (Get-PSCMVersion)
}
