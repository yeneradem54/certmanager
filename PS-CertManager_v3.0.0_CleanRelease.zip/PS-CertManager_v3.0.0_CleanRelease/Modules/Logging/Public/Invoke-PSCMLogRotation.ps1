﻿function Invoke-PSCMLogRotation {
<#
.SYNOPSIS
Log rotasyonu.
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$LogFile,
        [int]$RetentionDays = 90
    )
    if (Test-Path -LiteralPath $LogFile) {
        $archiveDir = Join-Path (Get-PSCMPath -Name Logs) 'Archive'
        if (-not (Test-Path $archiveDir)) { New-Item -ItemType Directory -Path $archiveDir -Force | Out-Null }
        $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
        $base  = [System.IO.Path]::GetFileNameWithoutExtension($LogFile)
        $dest  = Join-Path $archiveDir ('{0}_{1}.log' -f $base,$stamp)
        Move-Item -LiteralPath $LogFile -Destination $dest -Force
    }
    $cutoff = (Get-Date).AddDays(-$RetentionDays)
    Get-ChildItem -Path (Join-Path (Get-PSCMPath -Name Logs) 'Archive') -Filter '*.log' -EA SilentlyContinue |
        Where-Object { $_.LastWriteTime -lt $cutoff } |
        Remove-Item -Force -EA SilentlyContinue
}
