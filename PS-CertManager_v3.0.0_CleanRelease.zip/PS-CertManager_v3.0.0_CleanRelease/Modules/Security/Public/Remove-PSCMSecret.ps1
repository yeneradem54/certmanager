﻿function Remove-PSCMSecret {
    [CmdletBinding(SupportsShouldProcess)]
    param([Parameter(Mandatory)][string]$Name)
    if ($PSCmdlet.ShouldProcess($Name,'Secret sil')) {
        Remove-Secret -Name $Name -Vault $script:PSCMVaultName -EA SilentlyContinue
        Write-PSCMLog -Level INFO -Message ('Secret silindi: ' + $Name) -Source 'Security'
    }
}
