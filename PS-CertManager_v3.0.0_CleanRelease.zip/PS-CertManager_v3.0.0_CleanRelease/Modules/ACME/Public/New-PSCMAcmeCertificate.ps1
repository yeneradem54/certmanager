function New-PSCMAcmeCertificate {
<#
.SYNOPSIS
ACME uzerinden yeni sertifika olusturur.
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string[]]$Domain,
        [Parameter(Mandatory)][System.Security.SecureString]$PfxPass
    )
    Write-PSCMLog -Level INFO -Message ('ACME sertifika istegi baslatildi: ' + $Domain[0]) -Source 'ACME'
    Connect-PSCMAzure | Out-Null
    $az = Get-PSSettings -Section 'Azure'
    $acme = Get-PSSettings -Section 'Acme'
    $provider = Initialize-PSCMAcmeProvider
    $provider.Register($acme.AccountEmail) | Out-Null
    $params = @{ Domain=$Domain; TenantId=$az.TenantId; SubscriptionId=$az.SubscriptionId; PfxPass=$PfxPass }
    if ($az.AuthMode -eq 'ServicePrincipal') {
        $secret = Get-PSCMSecret -Name 'Azure.ClientSecret'
        $cred   = New-Object System.Management.Automation.PSCredential($az.ClientId,$secret)
        $params['AZAppCred'] = $cred
    }
    $cert = $provider.NewCertificate($params)
    Write-PSCMLog -Level INFO -Message ('ACME sertifika basariyla alindi: ' + $Domain[0]) -Source 'ACME'
    return $cert
}
