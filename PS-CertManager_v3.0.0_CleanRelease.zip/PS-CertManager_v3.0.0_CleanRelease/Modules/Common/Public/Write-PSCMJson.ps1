function Write-PSCMJson {
<#
.SYNOPSIS
Nesneyi JSON dosyasina yazar (UTF-8 BOM'suz).
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory,ValueFromPipeline)]$InputObject,
        [int]$Depth = 8
    )
    begin {
        $data = New-Object System.Collections.ArrayList
    }
    process {
        if ($InputObject -ne $null) {
            [void]$data.Add($InputObject)
        }
    }
    end {
        $dir = Split-Path -Parent $Path
        if ($dir -and -not (Test-Path -LiteralPath $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
        }
        
        $finalObj = if ($data.Count -eq 1) { $data[0] } else { @($data) }
        # Eger bilerek bos array gonderildiyse (Count 0), o zaman bos array olarak tut
        if ($data.Count -eq 0) { $finalObj = @() }
        
        $json = $finalObj | ConvertTo-Json -Depth $Depth
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($Path, $json, $utf8NoBom)
    }
}
