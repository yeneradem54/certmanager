<#
.SYNOPSIS
Local CA (Windows ADCS) Entegrasyon Modülü
#>

$ErrorActionPreference = "Stop"

function Invoke-PSCMLocalCACertificateRequest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Domain,
        [Parameter(Mandatory)][System.Security.SecureString]$PfxPass,
        [string]$TemplateName = 'WebServer',
        [string]$FriendlyName,
        [string[]]$SANList
    )
    
    Write-PSCMLog -Level INFO -Message "Local CA (ADCS) uzerinden sertifika talep ediliyor: $Domain (Template: $TemplateName)" -Source 'LocalCA'
    
    $allDns = @($Domain)
    if ($SANList) {
        foreach ($san in $SANList) {
            $cleanSan = $san.Trim()
            if ($cleanSan -and $cleanSan -ne $Domain) { $allDns += $cleanSan }
        }
    }
    
    $reqArgs = @{
        DnsName = $allDns
        CertStoreLocation = 'cert:\LocalMachine\My'
        Template = $TemplateName
    }
    
    try {
        $certInfo = Get-Certificate @reqArgs
        $cert = $certInfo.Certificate
        
        if (-not $cert) {
            throw "Get-Certificate basarili dondu fakat sertifika nesnesi bulunamadi."
        }
        
        Write-PSCMLog -Level INFO -Message "Sertifika alindi, Thumbprint: $($cert.Thumbprint)" -Source 'LocalCA'
        
        if ($FriendlyName) {
            $cert.FriendlyName = $FriendlyName
        } else {
            $cert.FriendlyName = $Domain
        }
        
        $tempPath = Join-Path $env:TEMP "$([guid]::NewGuid()).pfx"
        
        Write-PSCMLog -Level INFO -Message "Sertifika PFX olarak disari aktariliyor..." -Source 'LocalCA'
        Export-PfxCertificate -Cert $cert -FilePath $tempPath -Password $PfxPass | Out-Null
        
        # Orijinal sertifikayi depodan temizle (Sadece PFX olarak saklamak icin)
        Remove-Item -Path "cert:\LocalMachine\My\$($cert.Thumbprint)" -Force -ErrorAction SilentlyContinue
        
        return [PSCustomObject]@{
            Thumbprint = $cert.Thumbprint
            NotBefore = $cert.NotBefore.ToString('o')
            NotAfter = $cert.NotAfter.ToString('o')
            Issuer = $cert.Issuer
            PfxTempPath = $tempPath
        }
    } catch {
        Write-PSCMLog -Level ERROR -Message ("Local CA sertifika talebi basarisiz: " + $_.Exception.Message) -Source 'LocalCA'
        throw
    }
}

function Repair-PSCMLocalCAPermissions {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$TemplateName,
        [Parameter(Mandatory=$false)][pscredential]$Credential
    )

    Write-PSCMLog -Level INFO -Message "Sertifika sablonu ($TemplateName) icin Active Directory baglantisi kuruluyor..." -Source 'LocalCA'

    try {
        # RootDSE uzerinden Configuration Naming Context bulunuyor
        $rootDsePath = "LDAP://RootDSE"
        if ($Credential) {
            $rootDse = New-Object System.DirectoryServices.DirectoryEntry($rootDsePath, $Credential.UserName, $Credential.GetNetworkCredential().Password)
        } else {
            $rootDse = New-Object System.DirectoryServices.DirectoryEntry($rootDsePath)
        }
        $configContext = $rootDse.Properties["configurationNamingContext"].Value
        if (-not $configContext) {
            throw "Configuration Naming Context bulunamadi. RootDSE erisimi basarisiz."
        }

        $templateLdap = "LDAP://CN=$TemplateName,CN=Certificate Templates,CN=Public Key Services,CN=Services,$configContext"
        if ($Credential) {
            $templateEntry = New-Object System.DirectoryServices.DirectoryEntry($templateLdap, $Credential.UserName, $Credential.GetNetworkCredential().Password)
        } else {
            $templateEntry = New-Object System.DirectoryServices.DirectoryEntry($templateLdap)
        }
        
        # Sablonun var olup olmadigini dogrula (Object name bos mu diye kontrol et)
        if (-not $templateEntry.Name) {
            throw "Belirtilen sertifika sablonu ($TemplateName) Active Directory'de bulunamadi veya erisim izniniz yok."
        }

        Write-PSCMLog -Level INFO -Message "Sablon bulundu, Authenticated Users icin Enroll (Kayit) izinleri ayarlaniyor..." -Source 'LocalCA'

        # Guvenlik tanimlayicilarini (Security Descriptor) al
        $security = $templateEntry.ObjectSecurity
        
        # Authenticated Users (Dogrulanmis Kullanicilar) well-known SID'si: S-1-5-11
        $identity = New-Object System.Security.Principal.SecurityIdentifier("S-1-5-11")

        # Certificate-Enroll Extended Right GUID
        $guid = [guid]"0e10c968-78fb-11d2-90d4-00c04f79dc55"
        
        $accessRule = New-Object System.DirectoryServices.ActiveDirectoryAccessRule(
            $identity,
            [System.DirectoryServices.ActiveDirectoryRights]::ExtendedRight,
            [System.Security.AccessControl.AccessControlType]::Allow,
            $guid
        )

        $security.AddAccessRule($accessRule)
        $templateEntry.CommitChanges()

        Write-PSCMLog -Level INFO -Message "Yetkilendirme basarili. Tum child domain bilgisayarlari artik sertifika talep edebilir." -Source 'LocalCA'
        return $true
    } catch {
        Write-PSCMLog -Level ERROR -Message ("ADCS sablon yetkilendirmesi basarisiz: " + $_.Exception.Message) -Source 'LocalCA'
        throw
    }
}

Export-ModuleMember -Function Invoke-PSCMLocalCACertificateRequest, Repair-PSCMLocalCAPermissions
