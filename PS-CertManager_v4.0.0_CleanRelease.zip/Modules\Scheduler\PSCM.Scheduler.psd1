@{
    RootModule = 'PSCM.Scheduler.psm1'
    ModuleVersion = '4.0.0'
    GUID = '84583347-8441-4f23-8c5d-d96355c9e85d'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager Windows Task Scheduler Entegrasyon Modulu'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Register-PSCMRenewalTask','Unregister-PSCMRenewalTask','Get-PSCMRenewalTask','Invoke-PSCMRenewalCycle')
}
