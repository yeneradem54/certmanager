﻿function Set-PSSettings {
<#
.SYNOPSIS
settings.json'da alan gunceller.
#>
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][string]$Section,
        [Parameter(Mandatory)][string]$Key,
        [Parameter(Mandatory)][object]$Value
    )
    $secretKeys = @('ClientSecret','Password','ApiKey','Token','WebhookUrl')
    if ($secretKeys -contains $Key) {
        throw (New-PSCMException -Message ("Bu anahtar JSON'a yazilamaz: " + $Key + ". Set-PSCMSecret kullanin.") -Category 'Guvenlik' -ErrorCode 'PSCM-5002')
    }
    $path = Join-Path (Get-PSCMPath -Name Config) 'settings.json'
    if (-not (Test-Path -LiteralPath $path)) { Initialize-PSCMSettings }
    $obj = Read-PSCMJson -Path $path
    if (-not ($obj.PSObject.Properties.Name -contains $Section)) {
        throw (New-PSCMException -Message ("Ayar bolumu bulunamadi: " + $Section) -Category 'Yapilandirma' -ErrorCode 'PSCM-3003')
    }
    if ($PSCmdlet.ShouldProcess(("$Section.$Key"),'Ayar guncelle')) {
        $obj.$Section | Add-Member -NotePropertyName $Key -NotePropertyValue $Value -Force
        $obj | Write-PSCMJson -Path $path
        Write-PSCMLog -Level INFO -Message ("Ayar guncellendi: {0}.{1}" -f $Section,$Key) -Source 'Settings'
    }
}
