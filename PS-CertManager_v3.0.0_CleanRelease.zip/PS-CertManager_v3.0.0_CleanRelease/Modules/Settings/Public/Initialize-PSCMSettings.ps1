function Initialize-PSCMSettings {
<#
.SYNOPSIS
Varsayilan settings.json olusturur.
#>
    [CmdletBinding()]
    param([switch]$Force)
    $path = Join-Path (Get-PSCMPath -Name Config) $script:PSCMSettingsFile
    if ((Test-Path -LiteralPath $path) -and (-not $Force)) { return }
    $default = [ordered]@{
        Version = '3.0.0'
        General = @{ IsConfigured = $false }
        Azure = @{ TenantId=''; SubscriptionId=''; ResourceGroup=''; DnsZone=''; AuthMode='Interactive'; ClientId='' }
        Acme = @{ Provider='LetsEncrypt'; AccountEmail=''; KeyLength='2048'; ChallengeType='dns-01'; Client='Posh-ACME' }
        Certificate = @{ DefaultExportFormat='pfx'; RenewalThresholdDay=30; AutoRenew=$true }
        Notification = @{
            Enabled = $false
            Smtp = @{ Server=''; Port=587; UseTls=$true; From=''; To=@(); Username='' }
            Teams = @{ Enabled=$false; WebhookRef='Teams.WebhookUrl' }
        }
        Logging = @{ MinimumLevel='INFO'; MaxSizeMB=10; RetentionDays=90 }
        Paths = @{ OutputFolder='Certificates\Current'; ArchiveFolder='Certificates\Archive' }
    }
    $default | Write-PSCMJson -Path $path
    Write-PSCMLog -Level INFO -Message ('settings.json olusturuldu: ' + $path) -Source 'Settings'
}
