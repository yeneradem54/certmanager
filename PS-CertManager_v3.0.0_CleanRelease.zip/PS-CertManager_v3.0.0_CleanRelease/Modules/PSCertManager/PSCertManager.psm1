#Requires -Version 5.1
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'
if (-not $env:PSCM_ROOT) { $env:PSCM_ROOT = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..\..')).Path }
try {
    [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new()
    $OutputEncoding = [System.Text.UTF8Encoding]::new()
} catch { }
Write-Verbose 'PS-CertManager v2.1 yuklendi.'
