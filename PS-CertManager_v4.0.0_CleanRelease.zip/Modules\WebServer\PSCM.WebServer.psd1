@{
    RootModule = 'PSCM.WebServer.psm1'
    ModuleVersion = '4.0.0'
    GUID = '287ddc6e-f96d-417c-8317-3c23429ed951'
    Author = 'PS-CertManager Ekibi'
    CompanyName = 'PS-CertManager'
    Copyright = '(c) 2026 PS-CertManager. Tum haklari saklidir.'
    Description = 'PS-CertManager REST API & Dashboard Web Server Modulu'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Start-PSCMWebServer')
    CmdletsToExport = @()
    AliasesToExport = @()
    VariablesToExport = @()
}
