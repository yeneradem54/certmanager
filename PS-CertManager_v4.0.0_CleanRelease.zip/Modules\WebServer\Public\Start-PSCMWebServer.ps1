function Start-PSCMWebServer {
<#
.SYNOPSIS
Localhost uzerinde calisan ve REST API/Dashboard sunan hafif bir HTTP sunucusu baslatir.
#>
    [CmdletBinding()]
    param(
        [int]$Port = 8080
    )
    
    $listener = New-Object System.Net.HttpListener
    $url = "http://localhost:$($Port)/"
    $listener.Prefixes.Add($url)
    
    try {
        $listener.Start()
        Write-Host "=====================================================" -ForegroundColor Cyan
        Write-Host " PS-CertManager Canli Dashboard & API Sunucusu Calisiyor" -ForegroundColor Green
        Write-Host "=====================================================" -ForegroundColor Cyan
        Write-Host " Tarayicinizda acin: " -NoNewline; Write-Host $url -ForegroundColor Yellow
        Write-Host " Durdurmak icin 'Q' veya 'ESC' tusuna basin..." -ForegroundColor Gray
        Write-Host ""
        
        Write-PSCMLog -Level INFO -Message "WebServer baslatildi: $url" -Source 'WebServer'

        while ($listener.IsListening) {
            # Kullanici Q veya ESC tusuna basarsa sunucuyu durdur
            if ([Console]::KeyAvailable) {
                $key = [Console]::ReadKey($true)
                if ($key.Key -eq 'Q' -or $key.Key -eq 'Escape') {
                    Write-Host "`n[BILGI] Sunucu durduruluyor..." -ForegroundColor Yellow
                    break
                }
            }

            $asyncResult = $listener.BeginGetContext($null, $null)
            while (-not $asyncResult.IsCompleted) {
                if ([Console]::KeyAvailable) {
                    $key = [Console]::ReadKey($true)
                    if ($key.Key -eq 'Q' -or $key.Key -eq 'Escape') {
                        Write-Host "`n[BILGI] Sunucu durduruluyor..." -ForegroundColor Yellow
                        $listener.Stop()
                        break
                    }
                }
                Start-Sleep -Milliseconds 200
            }
            if (-not $listener.IsListening) { break }
            $context = $listener.EndGetContext($asyncResult)
            $request = $context.Request
            $response = $context.Response
            
            # CORS Headers
            $response.AppendHeader("Access-Control-Allow-Origin", "*")
            $response.AppendHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            $response.AppendHeader("Access-Control-Allow-Headers", "Content-Type")

            if ($request.HttpMethod -eq 'OPTIONS') {
                $response.StatusCode = 204
                $response.Close()
                continue
            }
            
            $path = $request.Url.LocalPath.ToLower()
            $responseBytes = New-Object byte[] 0
            
            try {
                if ($path -eq '/' -or $path -eq '/index.html' -or $path.StartsWith('/css/') -or $path.StartsWith('/js/')) {
                    if ($path -eq '/') { $path = '/index.html' }
                    $path = $path.Replace('/', '\')
                    $filePath = Join-Path (Get-PSCMRootPath) "Modules\WebServer\PublicWeb$path"
                    if (Test-Path -LiteralPath $filePath -PathType Leaf) {
                        $content = [System.IO.File]::ReadAllBytes($filePath)
                        $responseBytes = $content
                        if ($path.EndsWith('.html')) { $response.ContentType = "text/html; charset=utf-8" }
                        elseif ($path.EndsWith('.css')) { $response.ContentType = "text/css; charset=utf-8" }
                        elseif ($path.EndsWith('.js')) { $response.ContentType = "application/javascript; charset=utf-8" }
                        else { $response.ContentType = "application/octet-stream" }
                    } else {
                        $response.StatusCode = 404
                        $responseBytes = [System.Text.Encoding]::UTF8.GetBytes("Dosya bulunamadi: $path")
                    }
                }
                elseif ($path -eq '/api/v1/certificates' -and $request.HttpMethod -eq 'GET') {
                    $data = Get-PSCMState -Table 'certificates'
                    if ($data -and $data.Count -gt 0) {
                        $json = ConvertTo-Json -InputObject @($data) -Depth 5 -Compress
                    } else {
                        $json = '[]'
                    }
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes($json)
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/v1/action' -and $request.HttpMethod -eq 'POST') {
                    $reader = New-Object System.IO.StreamReader($request.InputStream, $request.ContentEncoding)
                    $body = $reader.ReadToEnd()
                    $payload = $body | ConvertFrom-Json
                    
                    if ($payload -and $payload.Action -and $payload.Domain) {
                        $pHash = @{}
                        if ($payload.psobject.Properties.Match('Params').Count -gt 0) {
                            if ($payload.Params) {
                                $payload.Params.psobject.Properties | ForEach-Object { $pHash[$_.Name] = $_.Value }
                            }
                        }
                        Add-PSCMAction -Action $payload.Action -Domain $payload.Domain -Params $pHash
                        $resObj = @{ success = $true; message = "Aksiyon kuyruga eklendi: $($payload.Action) $($payload.Domain)" }
                        $json = ConvertTo-Json -InputObject $resObj -Compress
                        $responseBytes = [System.Text.Encoding]::UTF8.GetBytes($json)
                        $response.ContentType = "application/json; charset=utf-8"
                    } else {
                        $response.StatusCode = 400
                        $resObj = @{ success = $false; message = "Gecersiz istek (Action veya Domain eksik)." }
                        $responseBytes = [System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $resObj -Compress))
                    }
                }
                elseif ($path -eq '/api/v1/actionqueue' -and $request.HttpMethod -eq 'GET') {
                    $pend = @(Get-PSCMActionQueue -Status pending)
                    $proc = @(Get-PSCMActionQueue -Status processed)
                    $fail = @(Get-PSCMActionQueue -Status failed)
                    $qData = @{ pending = $pend; processed = $proc; failed = $fail }
                    $json = ConvertTo-Json -InputObject $qData -Depth 5 -Compress
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes($json)
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/v1/actionqueue/process' -and $request.HttpMethod -eq 'POST') {
                    $res = @(Invoke-PSCMActionQueue)
                    $resObj = @{ success = $true; message = "$($res.Count) islem kuyruktan islendi."; results = $res }
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $resObj -Depth 5 -Compress))
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/v1/actionqueue/clear' -and $request.HttpMethod -eq 'POST') {
                    $n = Clear-PSCMActionQueue -Status processed -OlderThanDays 30
                    $resObj = @{ success = $true; message = "$n eski islem temizlendi." }
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $resObj -Compress))
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/v1/logs' -and $request.HttpMethod -eq 'GET') {
                    $logs = @(Get-PSLog -Level ALL -Last 100 -Days 3 | ForEach-Object { [string]$_ })
                    if ($logs.Count -gt 0) { $json = ConvertTo-Json -InputObject $logs -Compress } else { $json = '[]' }
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes($json)
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/v1/infrastructure' -and $request.HttpMethod -eq 'GET') {
                    $infra = @(Get-PSInfrastructure)
                    if ($infra.Count -gt 0) { $json = ConvertTo-Json -InputObject $infra -Compress } else { $json = '[]' }
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes($json)
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/v1/infrastructure/repair' -and $request.HttpMethod -eq 'POST') {
                    $rep = @(Repair-PSInfrastructure)
                    $resObj = @{ success = $true; message = "$($rep.Count) altyapi bileseni kontrol edildi ve eksikler onarildi."; data = $rep }
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $resObj -Depth 5 -Compress))
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/v1/system/summary' -and $request.HttpMethod -eq 'GET') {
                    $isAdmin = try {
                        $id = [System.Security.Principal.WindowsIdentity]::GetCurrent()
                        $p  = New-Object System.Security.Principal.WindowsPrincipal($id)
                        $p.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
                    } catch { $false }
                    
                    $vaultStatus = try {
                        $v = Get-SecretVault -Name 'PSCertManagerVault' -EA SilentlyContinue
                        if ($v) { 'Aktif / Acik' } else { 'Hazir Degil' }
                    } catch { 'Kilitli' }
                    
                    $resObj = @{
                        isAdmin = $isAdmin
                        vaultStatus = $vaultStatus
                        psVersion = "$($PSVersionTable.PSVersion.Major).$($PSVersionTable.PSVersion.Minor)"
                        os = 'Windows'
                        port = $Port
                    }
                    $json = ConvertTo-Json -InputObject $resObj -Compress
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes($json)
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/v1/ssl/tools' -and $request.HttpMethod -eq 'POST') {
                    $reader = New-Object System.IO.StreamReader($request.InputStream, $request.ContentEncoding)
                    $body = $reader.ReadToEnd()
                    $payload = $body | ConvertFrom-Json
                    
                    try {
                        switch ($payload.Action) {
                            'read_csr' {
                                $csrInfo = Get-PSCMSslCsrInfo -CsrPath $payload.CsrPath
                                $resObj = @{ success = $true; message = "CSR dökümü alındı."; data = $csrInfo }
                            }
                            'read_cert' {
                                $certInfo = Get-PSCMSslCertInfo -CertPath $payload.CertPath
                                $resObj = @{ success = $true; message = "Sertifika dökümü alındı."; data = $certInfo }
                            }
                            'make_pfx' {
                                $secPass = ConvertTo-SecureString $payload.PfxPass -AsPlainText -Force
                                New-PSCMSslPfx -CertPath $payload.CertPath -KeyPath $payload.KeyPath -DestinationPfx $payload.DestinationPfx -PfxPass $secPass
                                $resObj = @{ success = $true; message = "PFX dosyası başarıyla oluşturuldu: $($payload.DestinationPfx)" }
                            }
                            'export_pfx' {
                                $secPass = ConvertTo-SecureString $payload.PfxPass -AsPlainText -Force
                                $res = Export-PSCMSslPrivateKey -PfxPath $payload.PfxPath -PfxPass $secPass -OutFolder $payload.OutFolder
                                $resObj = @{ success = $true; message = "Key ve Cert dosyaları çıkarıldı: $($payload.OutFolder)"; data = $res }
                            }
                            'export_jks' {
                                $secPass = ConvertTo-SecureString $payload.PfxPass -AsPlainText -Force
                                $res = Export-PSCMSslKeystore -PfxPath $payload.PfxPath -PfxPass $secPass -DestinationJks $payload.DestinationJks
                                $resObj = @{ success = $true; message = "Java Keystore oluşturuldu: $($payload.DestinationJks)"; data = @{ Path = "$res" } }
                            }
                            'new_csr' {
                                $csrArgs = @{ Domain = $payload.Domain }
                                if ($payload.Organization) { $csrArgs['Organization'] = $payload.Organization }
                                if ($payload.OutFolder) { $csrArgs['OutFolder'] = $payload.OutFolder }
                                $res = New-PSCMSslCsr @csrArgs
                                $resObj = @{ success = $true; message = "Yeni CSR ve Private Key oluşturuldu: $($res.CsrPath)"; data = $res }
                            }
                            default {
                                $resObj = @{ success = $false; message = "Bilinmeyen SSL aracı aksiyonu." }
                            }
                        }
                    } catch {
                        Write-PSCMLog -Level ERROR -Message "SSL Tools API Hatasi: $($_.Exception.Message)" -Source 'WebServer'
                        $resObj = @{ success = $false; message = $_.Exception.Message }
                    }
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $resObj -Depth 5 -Compress))
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/v1/system/dir' -and $request.HttpMethod -eq 'GET') {
                    $targetPath = $request.QueryString['path']
                    if (-not $targetPath) { $targetPath = "C:\" }
                    
                    $items = @()
                    $drives = @([System.IO.DriveInfo]::GetDrives() | Where-Object { $_.IsReady } | ForEach-Object { $_.Name })
                    
                    if (Test-Path $targetPath) {
                        try {
                            $dirItems = Get-ChildItem -Path $targetPath -ErrorAction SilentlyContinue | Select-Object -First 200
                            foreach ($item in $dirItems) {
                                $items += [PSCustomObject]@{
                                    name = $item.Name
                                    fullPath = $item.FullName
                                    isDir = $item.PSIsContainer
                                    size = if (-not $item.PSIsContainer) { $item.Length } else { 0 }
                                    extension = if (-not $item.PSIsContainer) { $item.Extension.ToLower() } else { "" }
                                }
                            }
                        } catch {}
                    }
                    
                    $parentPath = try { Split-Path -Parent $targetPath } catch { "" }
                    $resObj = @{
                        currentPath = $targetPath
                        parentPath = $parentPath
                        drives = $drives
                        items = $items
                    }
                    $json = ConvertTo-Json -InputObject $resObj -Depth 3 -Compress
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes($json)
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/v1/system/filedialog' -and $request.HttpMethod -eq 'POST') {
                    $reader = New-Object System.IO.StreamReader($request.InputStream, $request.ContentEncoding)
                    $body = $reader.ReadToEnd()
                    $payload = $body | ConvertFrom-Json
                    
                    $selectedPath = ""
                    $scriptBlock = {
                        param($p)
                        Add-Type -AssemblyName System.Windows.Forms
                        [System.Windows.Forms.Application]::EnableVisualStyles()
                        
                        # Add user32 Signature to force foreground focus
                        $signature = @'
[DllImport("user32.dll")]
[return: MarshalAs(UnmanagedType.Bool)]
public static extern bool SetForegroundWindow(IntPtr hWnd);

[DllImport("user32.dll")]
public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
'@
                        $user32 = Add-Type -MemberDefinition $signature -Name "Win32Util" -Namespace "Win32" -PassThru
                        
                        $top = New-Object System.Windows.Forms.Form
                        $top.TopMost = $true
                        $top.Width = 1
                        $top.Height = 1
                        $top.Opacity = 0
                        $top.FormBorderStyle = 'None'
                        $top.StartPosition = 'CenterScreen'
                        $top.ShowInTaskbar = $false
                        $top.Show()
                        
                        # Force handle creation and bring form to absolute front
                        $handle = $top.Handle
                        [void]$user32::SetForegroundWindow($handle)
                        
                        # HWND_TOPMOST = -1, SWP_NOSIZE = 0x0001, SWP_NOMOVE = 0x0002, SWP_SHOWWINDOW = 0x0040
                        [void]$user32::SetWindowPos($handle, [IntPtr]-1, 0, 0, 0, 0, 0x0043)
                        
                        $sel = ""
                        if ($p.Mode -eq 'folder') {
                            # Compile ModernFolderPicker on the fly inside STA runspace
                            $pickerCode = @'
using System;
using System.Runtime.InteropServices;

namespace Win32 {
    [ComImport]
    [Guid("DC1C5A9C-E88A-4dde-A5A1-60F82A20AEF7")]
    public class FileOpenDialog {}

    [ComImport]
    [Guid("42f85136-db7e-439c-8506-7577d16d9b5c")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IFileOpenDialog {
        [PreserveSig] int Show(IntPtr parent);
        [PreserveSig] int SetFileTypes();
        [PreserveSig] int SetFileTypeIndex();
        [PreserveSig] int GetFileTypeIndex();
        [PreserveSig] int Advise();
        [PreserveSig] int Unadvise();
        [PreserveSig] int SetOptions(int options);
        [PreserveSig] int GetOptions(out int options);
        [PreserveSig] int SetDefaultFolder();
        [PreserveSig] int SetFolder(IntPtr shellItem);
        [PreserveSig] int GetFolder(out IntPtr shellItem);
        [PreserveSig] int GetCurrentSelection();
        [PreserveSig] int SetFileName([MarshalAs(UnmanagedType.LPWStr)] string name);
        [PreserveSig] int GetFileName();
        [PreserveSig] int SetTitle([MarshalAs(UnmanagedType.LPWStr)] string title);
        [PreserveSig] int SetOkButtonLabel();
        [PreserveSig] int SetFileNameLabel();
        [PreserveSig] int GetResult(out IntPtr shellItem);
        [PreserveSig] int AddPlace();
        [PreserveSig] int SetDefaultExtension();
        [PreserveSig] int Close();
        [PreserveSig] int SetClientGuid();
        [PreserveSig] int ClearClientData();
        [PreserveSig] int SetFilter();
    }

    [ComImport]
    [Guid("43826d1e-e718-42ee-bc55-a1e261c37bfe")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IShellItem {
        [PreserveSig] int BindToHandler();
        [PreserveSig] int GetParent();
        [PreserveSig] int GetDisplayName(uint sigdnName, out IntPtr ppszName);
        [PreserveSig] int GetAttributes();
        [PreserveSig] int Compare();
    }

    public class ModernFolderPicker {
        public static string Show(IntPtr parent, string title) {
            try {
                var dialog = (IFileOpenDialog)new FileOpenDialog();
                dialog.SetOptions(0x00000020); // FOS_PICKFOLDERS
                if (!string.IsNullOrEmpty(title)) {
                    dialog.SetTitle(title);
                }
                int hr = dialog.Show(parent);
                if (hr == 0) { // S_OK
                    IntPtr shellItemPtr;
                    dialog.GetResult(out shellItemPtr);
                    var shellItem = (IShellItem)Marshal.GetObjectForIUnknown(shellItemPtr);
                    IntPtr pathPtr;
                    shellItem.GetDisplayName(0x80058000U, out pathPtr); // SIGDN_FILESYSPATH
                    string path = Marshal.PtrToStringUni(pathPtr);
                    Marshal.FreeCoTaskMem(pathPtr);
                    return path;
                }
            } catch {}
            return "";
        }
    }
}
'@
                            $type = Add-Type -TypeDefinition $pickerCode -PassThru -ErrorAction SilentlyContinue
                            $sel = [Win32.ModernFolderPicker]::Show($handle, "Klasor Secin")
                        } elseif ($p.Mode -eq 'save') {
                            # Set topmost window wrapper
                            $wrapper = New-Object System.Windows.Forms.NativeWindow
                            $wrapper.AssignHandle($handle)
                            $dialog = New-Object System.Windows.Forms.SaveFileDialog
                            $dialog.Title = "Hedef Dosya Secin"
                            if ($p.Filter) { $dialog.Filter = $p.Filter } else { $dialog.Filter = "Tum Dosyalar (*.*)|*.*" }
                            if ($p.DefaultFileName) { $dialog.FileName = $p.DefaultFileName }
                            $dialog.OverwritePrompt = $true
                            if ($dialog.ShowDialog($wrapper) -eq [System.Windows.Forms.DialogResult]::OK) {
                                $sel = $dialog.FileName
                            }
                            $wrapper.ReleaseHandle()
                        } else {
                            # Set topmost window wrapper
                            $wrapper = New-Object System.Windows.Forms.NativeWindow
                            $wrapper.AssignHandle($handle)
                            $dialog = New-Object System.Windows.Forms.OpenFileDialog
                            $dialog.Title = "Dosya Secin"
                            if ($p.Filter) { $dialog.Filter = $p.Filter } else { $dialog.Filter = "Tum Dosyalar (*.*)|*.*" }
                            if ($dialog.ShowDialog($wrapper) -eq [System.Windows.Forms.DialogResult]::OK) {
                                $sel = $dialog.FileName
                            }
                            $wrapper.ReleaseHandle()
                        }
                        $top.Close()
                        $top.Dispose()
                        return $sel
                    }
                    
                    try {
                        $iss = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
                        $staRunspace = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace($iss)
                        $staRunspace.ApartmentState = 'STA'
                        $staRunspace.ThreadOptions = 'ReuseThread'
                        $staRunspace.Open()
                        
                        $ps = [powershell]::Create()
                        $ps.Runspace = $staRunspace
                        $null = $ps.AddScript($scriptBlock).AddArgument($payload)
                        $res = $ps.Invoke()
                        if ($res -and $res.Count -gt 0 -and $res[0]) { $selectedPath = $res[0].ToString() }
                        $ps.Dispose()
                        $staRunspace.Close()
                        $staRunspace.Dispose()
                    } catch {
                        Write-PSCMLog -Level ERROR -Message "FileDialog hatasi: $($_.Exception.Message)" -Source 'WebServer'
                    }
                    
                    $resObj = @{ success = [bool]$selectedPath; selectedPath = $selectedPath }
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $resObj -Compress))
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/v1/scheduler' -and $request.HttpMethod -eq 'GET') {
                    $tasks = @(Get-PSCMRenewalTask)
                    $json = $tasks | ConvertTo-Json -Compress
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes($json)
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/v1/settings' -and $request.HttpMethod -eq 'GET') {
                    $settings = Get-PSSettings
                    $json = ConvertTo-Json -InputObject $settings -Depth 5 -Compress
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes($json)
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/v1/settings' -and $request.HttpMethod -eq 'POST') {
                    $reader = New-Object System.IO.StreamReader($request.InputStream, $request.ContentEncoding)
                    $body = $reader.ReadToEnd()
                    $payload = $body | ConvertFrom-Json
                    if ($payload -and $payload.Section -and $payload.Key -and $payload.Value -ne $null) {
                        Set-PSSettings -Section $payload.Section -Key $payload.Key -Value $payload.Value
                        $resObj = @{ success = $true; message = "$($payload.Section).$($payload.Key) ayari guncellendi." }
                    } else {
                        $response.StatusCode = 400
                        $resObj = @{ success = $false; message = "Gecersiz istek (Section, Key veya Value eksik)." }
                    }
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $resObj -Compress))
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/v1/notifications' -and $request.HttpMethod -eq 'GET') {
                    $settingsPath = Join-Path (Get-PSCMPath -Name Config) 'settings.json'
                    $obj = Read-PSCMJson -Path $settingsPath
                    $n = if ($obj.PSObject.Properties.Name -contains 'Notification') { $obj.Notification } else { $null }
                    
                    $teamsUrl = try { Get-PSCMSecret -Name 'Teams.WebhookUrl' -AsPlainText } catch { '' }
                    $slackUrl = if ($n -and $n.PSObject.Properties.Name -contains 'SlackWebhook') { $n.SlackWebhook } else { '' }
                    $discordUrl = if ($n -and $n.PSObject.Properties.Name -contains 'DiscordWebhook') { $n.DiscordWebhook } else { '' }
                    $smtpData = if ($n -and $n.PSObject.Properties.Name -contains 'Smtp') { $n.Smtp } else { $null }
                    
                    $resObj = @{
                        teams = @{ url = if ($teamsUrl) { $teamsUrl } else { '' }; enabled = [bool]($teamsUrl -or ($n -and $n.Teams -and $n.Teams.Enabled)) }
                        slack = @{ url = if ($slackUrl) { $slackUrl } else { '' }; enabled = [bool]$slackUrl }
                        discord = @{ url = if ($discordUrl) { $discordUrl } else { '' }; enabled = [bool]$discordUrl }
                        smtp = @{
                            server = if ($smtpData -and $smtpData.PSObject.Properties.Name -contains 'Server') { $smtpData.Server } else { '' }
                            port = if ($smtpData -and $smtpData.PSObject.Properties.Name -contains 'Port') { $smtpData.Port } else { 587 }
                            useTls = if ($smtpData -and $smtpData.PSObject.Properties.Name -contains 'UseTls') { $smtpData.UseTls } else { $true }
                            from = if ($smtpData -and $smtpData.PSObject.Properties.Name -contains 'From') { $smtpData.From } else { '' }
                            to = if ($smtpData -and $smtpData.PSObject.Properties.Name -contains 'To') { ($smtpData.To -join ', ') } else { '' }
                            username = if ($smtpData -and $smtpData.PSObject.Properties.Name -contains 'Username') { $smtpData.Username } else { '' }
                        }
                    }
                    $json = ConvertTo-Json -InputObject $resObj -Depth 5 -Compress
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes($json)
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/v1/notifications' -and $request.HttpMethod -eq 'POST') {
                    $reader = New-Object System.IO.StreamReader($request.InputStream, $request.ContentEncoding)
                    $body = $reader.ReadToEnd()
                    $payload = $body | ConvertFrom-Json
                    
                    $settingsPath = Join-Path (Get-PSCMPath -Name Config) 'settings.json'
                    $obj = Read-PSCMJson -Path $settingsPath
                    if ($obj.PSObject.Properties.Name -notcontains 'Notification' -or -not $obj.Notification) {
                        $obj | Add-Member -NotePropertyName 'Notification' -NotePropertyValue ([PSCustomObject]@{
                            Enabled = $true
                            SlackWebhook = ''
                            DiscordWebhook = ''
                            Smtp = [PSCustomObject]@{ Server=''; Port=587; UseTls=$true; From=''; To=@(); Username='' }
                            Teams = [PSCustomObject]@{ Enabled=$false; WebhookRef='Teams.WebhookUrl' }
                        }) -Force
                    }
                    $n = $obj.Notification
                    
                    if ($payload.Channel -eq 'teams') {
                        if ($payload.Url) {
                            Set-PSCMSecret -Name 'Teams.WebhookUrl' -Value (ConvertTo-SecureString $payload.Url -AsPlainText -Force)
                            if ($n.PSObject.Properties.Name -contains 'Teams') { $n.Teams.Enabled = $true }
                            $n.Enabled = $true
                        } else {
                            Remove-PSCMSecret -Name 'Teams.WebhookUrl' -EA SilentlyContinue
                            if ($n.PSObject.Properties.Name -contains 'Teams') { $n.Teams.Enabled = $false }
                        }
                    }
                    elseif ($payload.Channel -eq 'slack') {
                        if ($n.PSObject.Properties.Name -notcontains 'SlackWebhook') { $n | Add-Member -NotePropertyName 'SlackWebhook' -NotePropertyValue '' -Force }
                        $n.SlackWebhook = $payload.Url
                        if ($payload.Url) { $n.Enabled = $true }
                    }
                    elseif ($payload.Channel -eq 'discord') {
                        if ($n.PSObject.Properties.Name -notcontains 'DiscordWebhook') { $n | Add-Member -NotePropertyName 'DiscordWebhook' -NotePropertyValue '' -Force }
                        $n.DiscordWebhook = $payload.Url
                        if ($payload.Url) { $n.Enabled = $true }
                    }
                    elseif ($payload.Channel -eq 'smtp') {
                        if ($n.PSObject.Properties.Name -notcontains 'Smtp' -or -not $n.Smtp) {
                            $n | Add-Member -NotePropertyName 'Smtp' -NotePropertyValue ([PSCustomObject]@{ Server=''; Port=587; UseTls=$true; From=''; To=@(); Username='' }) -Force
                        }
                        $n.Smtp.Server = $payload.Server
                        if ($payload.Port) { $n.Smtp.Port = [int]$payload.Port }
                        $n.Smtp.UseTls = [bool]$payload.UseTls
                        $n.Smtp.From = $payload.From
                        if ($payload.To) {
                            $n.Smtp.To = @($payload.To -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
                        }
                        $n.Smtp.Username = $payload.Username
                        if ($payload.Password) {
                            Set-PSCMSecret -Name 'Smtp.Password' -Value (ConvertTo-SecureString $payload.Password -AsPlainText -Force)
                        }
                        if ($payload.Server) { $n.Enabled = $true }
                    }
                    
                    $obj | Write-PSCMJson -Path $settingsPath
                    $resObj = @{ success = $true; message = "$($payload.Channel.ToUpper()) bildirim ayarlari kaydedildi." }
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $resObj -Compress))
                    $response.ContentType = "application/json; charset=utf-8"
                }
                elseif ($path -eq '/api/v1/notifications/test' -and $request.HttpMethod -eq 'POST') {
                    $reader = New-Object System.IO.StreamReader($request.InputStream, $request.ContentEncoding)
                    $body = $reader.ReadToEnd()
                    $payload = $body | ConvertFrom-Json
                    $ch = if ($payload -and $payload.Channel) { $payload.Channel.ToLower() } else { 'all' }
                    $testMsg = "PS-CertManager Web Dashboard: Bu bir canli test mesajidir. Bildirim kanaliniz ($ch) aktif ve calisiyor!"
                    $messages = @()
                    $errors = @()
                    
                    if ($ch -eq 'teams' -or $ch -eq 'all') {
                        try {
                            Send-PSCMTeamsNotification -Title 'Dashboard Test' -Message $testMsg -Level 'Basari'
                            $messages += "Teams: Basarili"
                        } catch { $errors += "Teams Hatasi: $($_.Exception.Message)" }
                    }
                    if ($ch -eq 'slack' -or $ch -eq 'all') {
                        try {
                            Send-PSCMSlackNotification -Title 'Dashboard Test' -Message $testMsg -Level 'Basari'
                            $messages += "Slack: Basarili"
                        } catch { $errors += "Slack Hatasi: $($_.Exception.Message)" }
                    }
                    if ($ch -eq 'discord' -or $ch -eq 'all') {
                        try {
                            Send-PSCMDiscordNotification -Title 'Dashboard Test' -Message $testMsg -Level 'Basari'
                            $messages += "Discord: Basarili"
                        } catch { $errors += "Discord Hatasi: $($_.Exception.Message)" }
                    }
                    if ($ch -eq 'smtp' -or $ch -eq 'all') {
                        try {
                            Send-PSCMMailNotification -Subject "PS-CertManager Dashboard Test" -Body $testMsg
                            $messages += "E-Posta (SMTP): Basarili"
                        } catch { $errors += "SMTP Hatasi: $($_.Exception.Message)" }
                    }
                    
                    $hasError = ($errors.Count -gt 0)
                    $outMsg = if ($hasError) { ($errors + $messages) -join " | " } else { $messages -join " | " }
                    $resObj = @{ success = (-not $hasError); message = $outMsg }
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $resObj -Compress))
                    $response.ContentType = "application/json; charset=utf-8"
                }
                else {
                    $response.StatusCode = 404
                    $responseBytes = [System.Text.Encoding]::UTF8.GetBytes("Bulunamadi")
                }
            } catch {
                $response.StatusCode = 500
                $resObj = @{ success = $false; message = $_.Exception.Message }
                $responseBytes = [System.Text.Encoding]::UTF8.GetBytes(($resObj | ConvertTo-Json -Compress))
            }
            
            if ($responseBytes.Length -gt 0) {
                $response.ContentLength64 = $responseBytes.Length
                $output = $response.OutputStream
                $output.Write($responseBytes, 0, $responseBytes.Length)
                $output.Close()
            } else {
                $response.Close()
            }
        }
    } catch {
        if ($_.Exception.Message -match "Erişim engellendi") {
            Write-Host "[HATA] Sunucuyu baslatmak icin Administrator yetkisi gerekebilir, ya da port kullanimda." -ForegroundColor Red
        } else {
            Write-Host "[HATA] WebServer Hatasi: $($_.Exception.Message)" -ForegroundColor Red
        }
    } finally {
        if ($listener) {
            $listener.Stop()
            $listener.Close()
        }
    }
}
