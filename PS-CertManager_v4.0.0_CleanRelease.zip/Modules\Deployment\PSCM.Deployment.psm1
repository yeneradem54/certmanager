#Requires -Version 5.1
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'

# Private helper fonksiyonlari yukle
$privatePath = Join-Path $PSScriptRoot 'Private'
if (Test-Path $privatePath) {
    Get-ChildItem -Path $privatePath -Filter '*.ps1' -ErrorAction SilentlyContinue | ForEach-Object {
        . $_.FullName
    }
}

# Public fonksiyonlari yukle
Get-ChildItem -Path (Join-Path $PSScriptRoot 'Public') -Filter '*.ps1' -ErrorAction SilentlyContinue | ForEach-Object {
    . $_.FullName
}

Export-ModuleMember -Function @(
    'Install-CertificateToStore',
    'Set-IISCertificateBinding',
    'Invoke-RemoteIISDeployment',
    'Get-PSCMDeploymentConfig',
    'Get-PSCMIISBinding',
    'Set-NginxApacheBinding'
)
