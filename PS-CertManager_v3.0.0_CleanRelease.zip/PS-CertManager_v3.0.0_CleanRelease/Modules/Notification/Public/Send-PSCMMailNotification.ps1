﻿function Send-PSCMMailNotification {
<#
.SYNOPSIS
SMTP uzerinden bildirim mail'i gonderir.
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Subject,
        [Parameter(Mandatory)][string]$Body,
        [switch]$Html
    )
    $s = Get-PSSettings -Section 'Notification'
    if (-not $s.Enabled) { return }
    $smtp = $s.Smtp
    if (-not $smtp.Server -or -not $smtp.From -or -not $smtp.To) {
        Write-PSCMLog -Level WARNING -Message 'SMTP yapilandirmasi eksik.' -Source 'Notification'
        return
    }
    try {
        $client = New-Object System.Net.Mail.SmtpClient($smtp.Server,[int]$smtp.Port)
        $client.EnableSsl = [bool]$smtp.UseTls
        if ($smtp.Username) {
            $pass = Get-PSCMSecret -Name 'Smtp.Password' -AsPlainText
            if (-not $pass) { throw (New-PSCMException -Message 'Smtp.Password bulunamadi.' -Category 'Guvenlik' -ErrorCode 'PSCM-5020') }
            $client.Credentials = New-Object System.Net.NetworkCredential($smtp.Username,$pass)
        }
        $msg = New-Object System.Net.Mail.MailMessage
        $msg.From = New-Object System.Net.Mail.MailAddress($smtp.From,'PS-CertManager')
        foreach ($to in @($smtp.To)) { if ($to) { $msg.To.Add($to) } }
        $msg.Subject = $Subject; $msg.Body = $Body; $msg.IsBodyHtml = [bool]$Html
        $msg.SubjectEncoding = [System.Text.Encoding]::UTF8
        $msg.BodyEncoding    = [System.Text.Encoding]::UTF8
        $client.Send($msg); $msg.Dispose(); $client.Dispose()
        Write-PSCMLog -Level INFO -Message ('Mail gonderildi: ' + $Subject) -Source 'Notification'
    } catch {
        Write-PSCMLog -Level ERROR -Message ('Mail hatasi: ' + $_.Exception.Message) -Source 'Notification'
    }
}
