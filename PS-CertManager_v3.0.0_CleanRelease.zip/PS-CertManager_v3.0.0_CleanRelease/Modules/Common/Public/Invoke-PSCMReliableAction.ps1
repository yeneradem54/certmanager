function Invoke-PSCMReliableAction {
<#
.SYNOPSIS
Belirtilen ScriptBlock'u hatalara karsi otomatik tekrar deneyerek (Retry) calistirir. (v3 Resilience)
.DESCRIPTION
Transient (gecici) hatalara karsi (ornegin Azure DNS timeout, API kesintileri) eylemleri Polly benzeri bir yaklasimla belirli araliklarla tekrar dener.
.PARAMETER Action
Calistirilacak ScriptBlock.
.PARAMETER MaxRetries
Maksimum deneme sayisi (varsayilan: 3).
.PARAMETER DelaySeconds
Denemeler arasindaki bekleme suresi saniye cinsinden (varsayilan: 5).
.PARAMETER ActionName
Loglara yansiyacak islem adi.
.EXAMPLE
Invoke-PSCMReliableAction -ActionName "AzureDNSKayit" -MaxRetries 3 -DelaySeconds 5 -Action { Add-PSCMDnsZone -Name 'test.com' }
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][scriptblock]$Action,
        [int]$MaxRetries = 3,
        [int]$DelaySeconds = 5,
        [string]$ActionName = "BilinmeyenIslem"
    )

    $attempt = 1
    $success = $false
    $lastError = $null

    while ($attempt -le $MaxRetries -and -not $success) {
        try {
            if ($attempt -gt 1) {
                Write-PSCMLog -Level WARNING -Message ("[$ActionName] Tekrar deneniyor... (Deneme: $attempt / $MaxRetries)") -Source 'Resilience'
            }
            $result = & $Action
            $success = $true
            return $result
        } catch {
            $lastError = $_
            Write-PSCMLog -Level ERROR -Message ("[$ActionName] Hata olustu: " + $_.Exception.Message) -Source 'Resilience'
            if ($attempt -lt $MaxRetries) {
                Start-Sleep -Seconds $DelaySeconds
            }
            $attempt++
        }
    }

    if (-not $success) {
        throw (New-PSCMException -Message ("[$ActionName] $MaxRetries deneme sonrasi basarisiz oldu. Son Hata: " + $lastError.Exception.Message) -Category 'Resilience' -ErrorCode 'PSCM-8001')
    }
}
