﻿function Test-PSCertificate {
<#
.SYNOPSIS
Sertifikanin sagligini kapsamli test eder (v2.3.4 - maximum defense).
.DESCRIPTION
StrictMode 3.0 uyumlu, .NET method invocation'lari try/catch ile korunmustur.
#>
    [CmdletBinding()]
    param(
        [string]$Domain,
        [switch]$All
    )

    $results = New-Object 'System.Collections.ArrayList'

    $certs = @()
    if ($Domain) {
        try { $certs = @(Get-PSCertificate -Domain $Domain) } catch { $certs = @() }
    } else {
        try { $certs = @(Get-PSCertificate) } catch { $certs = @() }
    }

    if ($certs.Count -eq 0) {
        return [PSCustomObject]@{ Durum='HATA'; Aciklama='Sertifika bulunamadi.' }
    }

    foreach ($c in $certs) {
        if (-not $c) { continue }

        $props = @()
        try { $props = @($c.PSObject.Properties.Name) } catch { $props = @() }

        $domainVal = '(bos)'
        try { if ($props -contains 'Domain' -and $c.Domain) { $domainVal = [string]$c.Domain } } catch {}

        $certPath = ''
        try { if ($props -contains 'Path' -and $c.Path) { $certPath = [string]$c.Path } } catch {}

        $metaThumb = ''
        try { if ($props -contains 'Thumbprint' -and $c.Thumbprint) { $metaThumb = [string]$c.Thumbprint } } catch {}

        $statusVal = 'Bilinmiyor'
        try { if ($props -contains 'Status' -and $c.Status) { $statusVal = [string]$c.Status } } catch {}

        $kalanGun = -1
        try {
            if ($props -contains 'DaysRemaining' -and $null -ne $c.DaysRemaining) {
                $kalanGun = [int]$c.DaysRemaining
            }
        } catch { $kalanGun = -1 }

        $notAfterVal = $null
        try { if ($props -contains 'NotAfter') { $notAfterVal = $c.NotAfter } } catch {}

        $sorunlar = New-Object 'System.Collections.ArrayList'

        $pfx = ''; $cert = ''; $key = ''
        if ($certPath) {
            try {
                $pfx  = Join-Path $certPath 'fullchain.pfx'
                $cert = Join-Path $certPath 'cert.cer'
                $key  = Join-Path $certPath 'cert.key'
            } catch {}
        }
        $filesOk = $false
        try {
            $pfxOk  = ($pfx  -and (Test-Path -LiteralPath $pfx))
            $certOk = ($cert -and (Test-Path -LiteralPath $cert))
            $keyOk  = ($key  -and (Test-Path -LiteralPath $key))
            $filesOk = ($pfxOk -and $certOk -and $keyOk)
        } catch { $filesOk = $false }
        if (-not $filesOk) {
            [void]$sorunlar.Add('Bir veya daha fazla sertifika dosyasi eksik.')
        }

        $x509Ok = $false
        $thumbMatch = $false
        $sanCount = 0

        if ($cert -and (Test-Path -LiteralPath $cert)) {
            $x = $null
            try {
                $x = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList @([string]$cert)
                $x509Ok = $true
            } catch {
                [void]$sorunlar.Add('X509 acilamadi: ' + $_.Exception.Message)
                $x = $null
            }

            if ($x) {
                try {
                    if ($metaThumb) {
                        $fileThumb = [string]$x.Thumbprint
                        if ($fileThumb -eq $metaThumb) {
                            $thumbMatch = $true
                        } else {
                            [void]$sorunlar.Add('Thumbprint metadata ile dosya farkli.')
                        }
                    }
                } catch {
                    [void]$sorunlar.Add('Thumbprint kontrol hatasi: ' + $_.Exception.Message)
                }

                try {
                    $exts = $x.Extensions
                    if ($exts) {
                        foreach ($ext in $exts) {
                            if (-not $ext) { continue }
                            $oidVal = $null
                            try {
                                if ($ext.Oid) { $oidVal = [string]$ext.Oid.Value }
                            } catch {}
                            if ($oidVal -eq '2.5.29.17') {
                                try {
                                    $formatted = [string]($ext.Format($true))
                                    if ($formatted) {
                                        $matches2 = [regex]::Matches($formatted, 'DNS')
                                        if ($matches2) { $sanCount = $matches2.Count }
                                    }
                                } catch {
                                    Write-Verbose ('SAN parse: ' + $_.Exception.Message)
                                }
                            }
                        }
                    }
                } catch {
                    Write-Verbose ('Extensions loop: ' + $_.Exception.Message)
                }
            }
        }

        $durum = $statusVal
        if ($sorunlar.Count -gt 0) { $durum = 'HATA' }

        $item = [PSCustomObject]@{
            Domain       = $domainVal
            Durum        = $durum
            DosyaVarMi   = $filesOk
            X509Gecerli  = $x509Ok
            ThumbprintOk = $thumbMatch
            SANSayisi    = [int]$sanCount
            KalanGun     = [int]$kalanGun
            NotAfter     = $notAfterVal
            Sorunlar     = @($sorunlar)
        }
        [void]$results.Add($item)
    }

    $arr = @($results.ToArray())
    if ($arr.Count -eq 0) {
        return [PSCustomObject]@{ Durum='HATA'; Aciklama='Sonuc uretilemedi.' }
    }
    if ($arr.Count -eq 1 -and -not $All) { return $arr[0] }
    return $arr
}
