﻿function Get-PSCMDnsZones {
<#
.SYNOPSIS
Settings'te kayitli tum DNS zone'lari listeler.
#>
    [CmdletBinding()]
    param()
    $az = Get-PSSettings -Section 'Azure'
    $zones = New-Object System.Collections.ArrayList
    if ($az.PSObject.Properties.Name -contains 'DnsZone' -and $az.DnsZone) {
        $rg = if ($az.PSObject.Properties.Name -contains 'ResourceGroup') { [string]$az.ResourceGroup } else { '' }
        [void]$zones.Add([PSCustomObject]@{ Name = [string]$az.DnsZone; ResourceGroup = $rg; Kaynak = 'DnsZone (legacy)' })
    }
    if ($az.PSObject.Properties.Name -contains 'DnsZones' -and $az.DnsZones) {
        foreach ($z in @($az.DnsZones)) {
            if (-not $z) { continue }
            $p = @($z.PSObject.Properties.Name)
            $name = if ($p -contains 'Name') { [string]$z.Name } else { $null }
            if (-not $name) { continue }
            if ($zones | Where-Object { $_.Name -eq $name }) { continue }
            $rg = if ($p -contains 'ResourceGroup') { [string]$z.ResourceGroup } else { '' }
            [void]$zones.Add([PSCustomObject]@{ Name = $name; ResourceGroup = $rg; Kaynak = 'DnsZones' })
        }
    }
    return ,$zones.ToArray()
}
