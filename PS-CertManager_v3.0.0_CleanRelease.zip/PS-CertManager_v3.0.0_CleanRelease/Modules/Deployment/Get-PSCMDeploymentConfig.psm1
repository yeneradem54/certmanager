function Get-PSCMDeploymentConfig {
<#
.SYNOPSIS
SQLite veritabanından (deployments tablosu) dağıtım ayarlarını okur.
#>
    [CmdletBinding()]
    param([string]$Domain)
    
    try {
        Initialize-PSCMSQLite
        $dbPath = Join-Path (Get-PSCMPath -Name State) "pscm.db"
        if (-not (Test-Path $dbPath)) { return @() }
        
        Import-Module PSSQLite -ErrorAction SilentlyContinue
        
        $q = "SELECT * FROM deployments"
        $p = @{}
        if ($Domain) {
            $q += " WHERE Domain = @Domain"
            $p['Domain'] = $Domain
        }
        
        $res = @(Invoke-SqliteQuery -DataSource $dbPath -Query $q -SqlParameters $p -ErrorAction SilentlyContinue)
        return $res
    } catch {
        Write-PSCMLog -Level ERROR -Message ("Deployments SQLite okunamadi: " + $_.Exception.Message) -Source "Deployment"
        return @()
    }
}
