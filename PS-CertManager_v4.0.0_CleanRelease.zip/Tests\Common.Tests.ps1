#Requires -Modules Pester
<#
.SYNOPSIS
    Common Modul Birim Testleri
#>

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$env:PSCM_ROOT = $ProjectRoot
$commonManifest = Join-Path $ProjectRoot 'Modules\Common\PSCM.Common.psd1'
Import-Module $commonManifest -Force -DisableNameChecking -ErrorAction Stop

Describe 'Get-PSCMRootPath' {
    It 'Proje kok dizinini dondurmeli' {
        $root = Get-PSCMRootPath
        $root | Should -Not -BeNullOrEmpty
        Test-Path $root | Should -BeTrue
    }
}

Describe 'Get-PSCMPath' {
    It 'Config yolunu dondurmeli' {
        $p = Get-PSCMPath -Name Config
        $p | Should -Not -BeNullOrEmpty
    }
    
    It 'Logs yolunu dondurmeli' {
        $p = Get-PSCMPath -Name Logs
        $p | Should -Not -BeNullOrEmpty
    }
    
    It 'Certificates yolunu dondurmeli' {
        $p = Get-PSCMPath -Name Certificates
        $p | Should -Not -BeNullOrEmpty
    }
}

Describe 'Get-PSCMVersion' {
    It 'Versiyon bilgisi dondurmeli' {
        $v = Get-PSCMVersion
        $v | Should -Not -BeNullOrEmpty
    }
}

Describe 'Read-PSCMJson / Write-PSCMJson' {
    It 'JSON dosyasi okuyup yazabilmeli' {
        $tempFile = Join-Path $env:TEMP "pscm_test_$([guid]::NewGuid()).json"
        try {
            $testObj = [PSCustomObject]@{ Test = 'Value'; Number = 42 }
            Write-PSCMJson -Path $tempFile -InputObject $testObj
            
            Test-Path $tempFile | Should -BeTrue
            
            $readBack = Read-PSCMJson -Path $tempFile
            $readBack.Test | Should -Be 'Value'
            $readBack.Number | Should -Be 42
        } finally {
            Remove-Item -Path $tempFile -Force -ErrorAction SilentlyContinue
        }
    }
}

Describe 'Test-PSCMAdmin' {
    It 'Boolean dondurmeli' {
        $result = Test-PSCMAdmin
        $result | Should -BeOfType [bool]
    }
}

Remove-Module PSCM.Common -Force -ErrorAction SilentlyContinue
