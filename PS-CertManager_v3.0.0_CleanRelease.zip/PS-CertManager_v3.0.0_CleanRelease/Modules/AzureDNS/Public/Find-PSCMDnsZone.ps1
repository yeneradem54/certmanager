﻿function Find-PSCMDnsZone {
<#
.SYNOPSIS
Azure aboneligindeki tum DNS zone'lari kesfeder.
.DESCRIPTION
Get-AzDnsZone wrapper. Belirli bir ResourceGroup verilirse yalnizca oradaki
zone'lari, aksi halde abonelikteki tumunu dondurur.
.PARAMETER ResourceGroup
Opsiyonel filtre.
.EXAMPLE
Find-PSCMDnsZone | Format-Table Name, ResourceGroupName, NumberOfRecordSets
#>
    [CmdletBinding()]
    param([string]$ResourceGroup)
    Connect-PSCMAzure | Out-Null
    Import-Module Az.Dns -EA Stop
    if ($ResourceGroup) {
        $zones = Get-AzDnsZone -ResourceGroupName $ResourceGroup -EA SilentlyContinue
    } else {
        $zones = Get-AzDnsZone -EA SilentlyContinue
    }
    if (-not $zones) { return @() }
    return $zones | ForEach-Object {
        [PSCustomObject]@{
            Name              = $_.Name
            ResourceGroupName = $_.ResourceGroupName
            ZoneType          = $_.ZoneType
            NumberOfRecordSets = $_.NumberOfRecordSets
            Id                = $_.ResourceId
        }
    }
}
