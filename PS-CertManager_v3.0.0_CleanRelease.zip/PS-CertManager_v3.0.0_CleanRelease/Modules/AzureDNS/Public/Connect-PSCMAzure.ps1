﻿function Connect-PSCMAzure {
<#
.SYNOPSIS
Azure baglantisini ayarlanan yontemle kurar.
#>
    [CmdletBinding()]
    param([switch]$Force)
    $s = Get-PSSettings -Section 'Azure'
    if (-not $s.TenantId -or -not $s.SubscriptionId) {
        throw (New-PSCMException -Message 'Azure ayarlari eksik (TenantId/SubscriptionId).' -Category 'Yapilandirma' -ErrorCode 'PSCM-3010')
    }
    if (-not (Get-Module -ListAvailable Az.Accounts)) {
        throw (New-PSCMException -Message 'Az.Accounts modulu bulunamadi.' -Category 'Yapilandirma' -ErrorCode 'PSCM-3011')
    }
    Import-Module Az.Accounts -EA Stop
    $ctx = Get-AzContext -EA SilentlyContinue
    if ($ctx -and -not $Force -and $ctx.Tenant.Id -eq $s.TenantId) {
        Write-PSCMLog -Level INFO -Message 'Mevcut Azure oturumu kullaniliyor.' -Source 'AzureDNS'
        return $ctx
    }
    switch ($s.AuthMode) {
        'ServicePrincipal' {
            if (-not $s.ClientId) { throw (New-PSCMException -Message 'ClientId eksik.' -Category 'Yapilandirma' -ErrorCode 'PSCM-3012') }
            $secret = Get-PSCMSecret -Name 'Azure.ClientSecret'
            if (-not $secret) { throw (New-PSCMException -Message 'Azure.ClientSecret bulunamadi.' -Category 'Guvenlik' -ErrorCode 'PSCM-5010') }
            $cred = New-Object System.Management.Automation.PSCredential($s.ClientId, $secret)
            Connect-AzAccount -ServicePrincipal -Tenant $s.TenantId -Credential $cred -Subscription $s.SubscriptionId -EA Stop | Out-Null
        }
        'ManagedIdentity' {
            Connect-AzAccount -Identity -Tenant $s.TenantId -Subscription $s.SubscriptionId -EA Stop | Out-Null
        }
        default {
            Connect-AzAccount -Tenant $s.TenantId -Subscription $s.SubscriptionId -EA Stop | Out-Null
        }
    }
    $ctx = Get-AzContext
    Write-PSCMLog -Level INFO -Message ('Azure baglantisi kuruldu: ' + $ctx.Subscription.Name) -Source 'AzureDNS'
    return $ctx
}
