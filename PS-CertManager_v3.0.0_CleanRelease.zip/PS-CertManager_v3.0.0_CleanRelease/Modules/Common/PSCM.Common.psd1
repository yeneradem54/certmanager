@{
    RootModule = 'PSCM.Common.psm1'
    ModuleVersion = '2.1.0'
    GUID = '11111111-1111-1111-1111-111111111111'
    Author = 'PS-CertManager Ekibi'
    CompanyName = 'PS-CertManager'
    Copyright = '(c) 2026 PS-CertManager. Tum haklari saklidir.'
    Description = 'PS-CertManager Ortak Kutuphane Modulu (Common)'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @(
        'Get-PSCMRootPath','Get-PSCMPath','Read-PSCMJson','Write-PSCMJson',
        'Test-PSCMAdmin','Get-PSCMVersion','Lock-PSCMResource','Unlock-PSCMResource',
        'ConvertTo-PSCMSafeString','New-PSCMException',
        'Copy-PSCMPoshAcmeOutput','Format-PSCMCertTable',
        'Get-PSCMState','Set-PSCMState','Invoke-PSCMReliableAction','Initialize-PSCMSQLite'
    )
    CmdletsToExport = @()
    AliasesToExport = @()
    VariablesToExport = @()
    PrivateData = @{ PSData = @{ Tags = @('PKI','ACME','Certificate','LetsEncrypt') } }
}
