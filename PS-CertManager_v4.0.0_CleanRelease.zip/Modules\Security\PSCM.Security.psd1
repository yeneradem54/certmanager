@{
    RootModule = 'PSCM.Security.psm1'
    ModuleVersion = '4.0.0'
    GUID = '30652bbe-70c9-4e05-a409-cb802e45a802'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager Guvenlik ve Secret Yonetim Modulu'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Initialize-PSCMSecretStore','Set-PSCMSecret','Get-PSCMSecret','Remove-PSCMSecret','Unlock-PSCMSecretStore','Set-PSCMSecretStorePolicy')
}
