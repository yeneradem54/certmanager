@{
    RootModule = 'PSCM.Settings.psm1'
    ModuleVersion = '4.0.0'
    GUID = 'dde06f8c-a74b-410a-a270-4fe24fb74539'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager Yapilandirma Modulu'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Get-PSSettings','Set-PSSettings','Initialize-PSCMSettings')
}
