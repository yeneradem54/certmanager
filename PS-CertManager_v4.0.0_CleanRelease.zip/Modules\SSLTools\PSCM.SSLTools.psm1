#Requires -Version 5.1
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'

Get-ChildItem -Path (Join-Path $PSScriptRoot 'Public') -Filter '*.ps1' -ErrorAction SilentlyContinue | ForEach-Object {
    . $_.FullName
}

Export-ModuleMember -Function @(
    'Get-PSCMSslCsrInfo',
    'Get-PSCMSslCertInfo',
    'New-PSCMSslPfx',
    'Export-PSCMSslPrivateKey',
    'Export-PSCMSslKeystore',
    'New-PSCMSslCsr'
)
