@{
    RootModule = 'PSCM.ACME.psm1'
    ModuleVersion = '4.0.0'
    GUID = 'f950087f-dacc-4cad-9828-ca5bb00065c9'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager ACME (Posh-ACME) Modulu'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Initialize-PSCMAcmeProvider','New-PSCMAcmeCertificate','Update-PSCMAcmeCertificate')
}
