function Invoke-PSCMRenewalCycle {
<#
.SYNOPSIS
Threshold altindaki tum sertifikalari yeniler ve bildirim gonderir.
.DESCRIPTION
Get-PSSettings ile RenewalThresholdDay okunur. Bu esik altindaki sertifikalar
Update-PSCertificate ile yenilenir. Basari/hata bildirim (SMTP + Teams) gonderilir.
.PARAMETER Force
Threshold'a bakmadan tum sertifikalari yeniler.
.EXAMPLE
Invoke-PSCMRenewalCycle
#>
    [CmdletBinding(SupportsShouldProcess)]
    param([switch]$Force)

    Write-PSCMLog -Level INFO -Message 'Yenileme dongusu baslatildi.' -Source 'Scheduler'
    $lockName = 'renewal-cycle'
    $lock = $null
    try {
        $lock = Lock-PSCMResource -Name $lockName -TimeoutSec 60
        $certs = @(Get-PSCertificate)
        if ($certs.Count -eq 0) {
            Write-PSCMLog -Level INFO -Message 'Kayitli sertifika yok, dongu atlandi.' -Source 'Scheduler'
            return
        }
        $threshold = 30
        try {
            $cs = Get-PSSettings -Section 'Certificate'
            if ($cs -and $cs.PSObject.Properties.Name -contains 'RenewalThresholdDay') {
                $threshold = [int]$cs.RenewalThresholdDay
            }
        } catch { }

        $targets = @()
        if ($Force) { $targets = $certs }
        else { $targets = $certs | Where-Object { $_.Status -in @('Warning','Critical','Expired') } }

        Write-PSCMLog -Level INFO -Message ('Toplam sertifika: ' + $certs.Count + ' / Yenilenecek: ' + @($targets).Count + ' / Esik: ' + $threshold + ' gun') -Source 'Scheduler'

        $summary = New-Object System.Collections.Generic.List[object]
        foreach ($c in $targets) {
            $item = [PSCustomObject]@{ Domain=$c.Domain; OncekiKalanGun=$c.DaysRemaining; Durum='-'; Hata='' }
            if ($PSCmdlet.ShouldProcess($c.Domain,'Yenile')) {
                try {
                    Update-PSCertificate -Domain $c.Domain -Confirm:$false | Out-Null
                    $item.Durum = 'BASARILI'
                    Write-PSCMLog -Level INFO -Message ('Yenilendi: ' + $c.Domain) -Source 'Scheduler'
                } catch {
                    $item.Durum = 'HATA'
                    $item.Hata  = $_.Exception.Message
                    Write-PSCMLog -Level ERROR -Message ('Yenileme hatasi (' + $c.Domain + '): ' + $_.Exception.Message) -Source 'Scheduler'
                }
            } else {
                $item.Durum = 'ATLANDI (WhatIf)'
            }
            $summary.Add($item)
        }

        if ($summary.Count -gt 0) {
            $okCount = 0
            $errCount = 0
            foreach ($item in $summary) {
                if ($item.Durum -eq 'BASARILI') { $okCount++ }
                elseif ($item.Durum -eq 'HATA') { $errCount++ }
            }
            $subject = ('PS-CertManager Yenileme Raporu: {0} basari, {1} hata' -f $okCount, $errCount)
            $bodyLines = @('PS-CertManager Yenileme Dongusu','',
                ('Zaman: ' + (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')),
                ('Toplam kayitli sertifika: ' + $certs.Count),
                ('Yenilenecek: ' + $targets.Count),
                ('Basarili: ' + $okCount),
                ('Hata: ' + $errCount),'','Detay:')
            foreach ($s in $summary) {
                $bodyLines += ('  {0,-30} {1,-12} {2}' -f $s.Domain,$s.Durum,$s.Hata)
            }
            $body = $bodyLines -join "`r`n"
            try { Send-PSCMMailNotification -Subject $subject -Body $body } catch { }
            $level = if ($errCount -gt 0) { 'Hata' } elseif ($okCount -gt 0) { 'Basari' } else { 'Bilgi' }
            try { Send-PSCMTeamsNotification -Title $subject -Message $body -Level $level } catch { }
            try { Send-PSCMSlackNotification -Title $subject -Message $body -Level $level } catch { }
            try { Send-PSCMDiscordNotification -Title $subject -Message $body -Level $level } catch { }
            
            # Yenileme islemi yapildiysa HTML Dashboard'u otomatik guncelle
            try {
                New-PSDashboard -EA SilentlyContinue | Out-Null
                Write-PSCMLog -Level INFO -Message 'HTML Dashboard guncellendi.' -Source 'Scheduler'
            } catch { }

            # Yenileme sonrasi bekleyen deploy/aksiyon kuyrugunu hemen isle
            try {
                Write-PSCMLog -Level INFO -Message 'Yenileme sonrasi bekleyen aksiyon kuyrugu isleniyor...' -Source 'Scheduler'
                Invoke-PSCMActionQueue -EA SilentlyContinue | Out-Null
            } catch {
                Write-PSCMLog -Level WARNING -Message ("Aksiyon kuyrugu islenirken uyari: " + $_.Exception.Message) -Source 'Scheduler'
            }
        }

        Write-PSCMLog -Level INFO -Message 'Yenileme dongusu tamamlandi.' -Source 'Scheduler'
        return $summary
    } catch {
        Write-PSCMLog -Level ERROR -Message ('Yenileme dongusu hatasi: ' + $_.Exception.Message) -Source 'Scheduler'
        throw
    } finally {
        if ($lock) { Unlock-PSCMResource -Name $lockName }
    }
}
