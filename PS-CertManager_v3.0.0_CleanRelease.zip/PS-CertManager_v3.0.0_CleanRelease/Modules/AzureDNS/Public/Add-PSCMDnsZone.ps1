﻿function Add-PSCMDnsZone {
<#
.SYNOPSIS
Kayitli DNS zone listesine yeni bir zone ekler.
.DESCRIPTION
Settings.json'da Azure.DnsZones dizisini kullanir.
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Name,
        [string]$ResourceGroup
    )
    $s = Get-PSSettings
    $az = $s.Azure
    if (-not $ResourceGroup) {
        if ($az.PSObject.Properties.Name -contains 'ResourceGroup' -and $az.ResourceGroup) {
            $ResourceGroup = $az.ResourceGroup
        } else {
            throw (New-PSCMException -Message 'ResourceGroup gerekli.' -Category 'Yapilandirma' -ErrorCode 'PSCM-3050')
        }
    }
    $zones = @()
    if ($az.PSObject.Properties.Name -contains 'DnsZones' -and $az.DnsZones) {
        $zones = @($az.DnsZones)
    } elseif ($az.PSObject.Properties.Name -contains 'DnsZone' -and $az.DnsZone) {
        $rg = if ($az.PSObject.Properties.Name -contains 'ResourceGroup') { [string]$az.ResourceGroup } else { $ResourceGroup }
        $zones = @([PSCustomObject]@{ Name = [string]$az.DnsZone; ResourceGroup = $rg })
    }
    if ($zones | Where-Object { $_.Name -eq $Name }) {
        Write-PSCMLog -Level WARNING -Message ('Zone zaten kayitli: ' + $Name) -Source 'AzureDNS'
        return
    }
    $newList = @($zones) + @([PSCustomObject]@{ Name = $Name; ResourceGroup = $ResourceGroup })
    $path = Join-Path (Get-PSCMPath -Name Config) 'settings.json'
    $data = Read-PSCMJson -Path $path
    $data.Azure | Add-Member -NotePropertyName 'DnsZones' -NotePropertyValue $newList -Force
    $data | Write-PSCMJson -Path $path
    Write-PSCMLog -Level INFO -Message ('DNS zone eklendi: ' + $Name + ' (' + $ResourceGroup + ')') -Source 'AzureDNS'
}
