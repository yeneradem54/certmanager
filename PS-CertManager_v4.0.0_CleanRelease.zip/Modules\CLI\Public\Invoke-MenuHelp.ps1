function Invoke-MenuHelp {
    Show-PSCMBanner
    Write-Host '>> Yardim' -ForegroundColor Yellow
    Write-Host ''
    Write-Host 'PS-CertManager v3.0.0' -ForegroundColor White
    Write-Host ''
    Write-Host 'Sertifika Menusu:' -ForegroundColor Cyan
    Write-Host '  1) Islem sec (Y/E/D/R/S/T/Q)'
    Write-Host '  2) Numara(lar) sec:'
    Write-Host '     Tekli:  2       Coklu: 1,3,5    Aralik: 2-4'
    Write-Host '     Karma:  1,3-5,7 Tumu:  A'
    Write-Host ''
    Write-Host 'Islemler: Y=Yenile E=Export D=Detay R=PFX Onar S=Sil T=Test Q=Kuyruga Ekle' -ForegroundColor DarkGray
    Pause-PSCM
}
