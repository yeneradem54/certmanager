function New-PSCertificate {
<#
.SYNOPSIS
Yeni ACME sertifikasi olusturur ve metadata kaydeder (v2.1 helper tabanli).
#>
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][string]$Domain,
        [switch]$Wildcard,
        [Parameter(Mandatory=$false)][System.Security.SecureString]$PfxPass,
        [string]$FriendlyName,
        [string[]]$SANList,
        [ValidateSet('ACME','LocalCA')][string]$Provider = 'ACME',
        [string]$AcmeProvider,
        [string]$TemplateName = 'WebServer',
        [string]$CsrPath
    )
    $lock = $null

    # Defaults.TemplateName (settings.json) kontrolü ve fallback
    $finalTemplateName = $TemplateName
    if ($TemplateName -eq 'WebServer') {
        try {
            $settings = Get-PSSettings
            if ($settings -and $settings.PSObject.Properties['Defaults'] -and $settings.Defaults.TemplateName) {
                $finalTemplateName = $settings.Defaults.TemplateName
            }
        } catch {}
    }
    
    if ($CsrPath -and (Test-Path -LiteralPath $CsrPath)) {
        try {
            $dump = & certutil -dump $CsrPath 2>&1 | Out-String
            if ($dump -match 'CN\s*=\s*([a-zA-Z0-9\.\-\*_]+)') {
                $extractedDomain = $Matches[1].Trim()
                Write-PSCMLog -Level INFO -Message "CSR dosyasindan Domain otomatik okundu: $extractedDomain" -Source 'Certificate'
                $Domain = $extractedDomain
            }
        } catch {
            Write-PSCMLog -Level WARNING -Message "CSR dosyasindan domain okunamadi: $($_.Exception.Message)" -Source 'Certificate'
        }
    }

    $lockName = 'cert-' + ($Domain -replace '[^a-zA-Z0-9]','_')
    try {
        $lock = Lock-PSCMResource -Name $lockName
        $realDomain = if ($Wildcard) { '*.' + ($Domain -replace '^\*\.','') } else { $Domain }
        Write-PSCMLog -Level INFO -Message ('Yeni sertifika istegi: ' + $realDomain) -Source 'Certificate'
        if (-not $PSCmdlet.ShouldProcess($realDomain,'ACME sertifika olustur')) { return }
        
        $realPfxPass = $PfxPass
        if (-not $realPfxPass -and -not $CsrPath) {
            $realPfxPass = Get-PSCMSecret -Name 'Certificate.DefaultPfxPassword'
            if (-not $realPfxPass) {
                throw (New-PSCMException -Message 'PFX parolasi belirtilmedi ve varsayilan bir PFX parolasi da bulunamadi.' -Category 'Dogrulama' -ErrorCode 'PSCM-4015')
            }
        }
        
        $acmeDomains = @($realDomain)
        if ($SANList) {
            foreach ($san in $SANList) {
                $cleanSan = $san.Trim()
                if ($cleanSan -and $cleanSan -ne $realDomain) { $acmeDomains += $cleanSan }
            }
        }
        
        $safeName = ($realDomain -replace '\*','wildcard') -replace '[^a-zA-Z0-9\.\-_]','_'
        $target = Join-Path (Get-PSCMPath -Name Current) $safeName
        
        $meta = $null
        $friendly = if ($FriendlyName) { $FriendlyName } else { $realDomain }
        
        if ($Provider -eq 'ACME') {
            Write-PSCMLog -Level INFO -Message ("ACME sunucusu (Let's Encrypt) baglantisi test ediliyor...") -Source 'Certificate'
            $netCheck = Test-NetConnection -ComputerName "acme-v02.api.letsencrypt.org" -Port 443 -WarningAction SilentlyContinue
            if (-not $netCheck.TcpTestSucceeded) {
                throw (New-PSCMException -Message "Internet baglantiniz koptu veya Let's Encrypt sunucularina erisim saglanamiyor." -Category 'Network' -ErrorCode 'PSCM-5000')
            }

            $result = New-PSCMAcmeCertificate -Domain $acmeDomains -PfxPass $realPfxPass -CsrPath $CsrPath -AcmeProvider $AcmeProvider
            if (-not $result) {
                throw (New-PSCMException -Message 'Posh-ACME bos sonuc dondu.' -Category 'ACME' -ErrorCode 'PSCM-1020')
            }
            
            $copyRes = Copy-PSCMPoshAcmeOutput -AcmeResult $result -Domain $realDomain -Destination $target
            Write-PSCMLog -Level INFO -Message ('Kopyalanan dosya: ' + $copyRes.CopiedCount + ' / ' + $copyRes.TotalCount) -Source 'Certificate'
            
            $meta = [PSCustomObject]@{
                Domain=$realDomain; Wildcard=[bool]$Wildcard
                Issuer=$copyRes.Issuer; Thumbprint=$copyRes.Thumbprint
                NotBefore=$copyRes.NotBefore; NotAfter=$copyRes.NotAfter
                FriendlyName=$friendly; Path=$target
                SourceFolder=$copyRes.SourceFolder; CreatedAt=(Get-Date).ToString('o')
                Provider=$Provider
                SANList=($acmeDomains -join ',')
                TemplateName=$finalTemplateName
            }
        } else {
            # LocalCA provider
            $result = Invoke-PSCMLocalCACertificateRequest -Domain $realDomain -PfxPass $realPfxPass -TemplateName $finalTemplateName -FriendlyName $friendly -SANList $SANList -CsrPath $CsrPath
            
            if (-not (Test-Path $target)) { New-Item -ItemType Directory -Path $target -Force | Out-Null }
            
            if ($CsrPath) {
                $destCer = Join-Path $target "cert.cer"
                Copy-Item -Path $result.CerTempPath -Destination $destCer -Force
                Remove-Item -Path $result.CerTempPath -Force -ErrorAction SilentlyContinue
                Write-PSCMLog -Level INFO -Message ('Sertifika kopyalandi: ' + $destCer) -Source 'Certificate'
            } else {
                # ACME ile uyumluluk icin PFX adını fullchain.pfx yapıyoruz
                $destPfx = Join-Path $target "fullchain.pfx"
                Copy-Item -Path $result.PfxTempPath -Destination $destPfx -Force
                Remove-Item -Path $result.PfxTempPath -Force -ErrorAction SilentlyContinue
                
                # CER dosyasını kopyalayalım
                if ($result.CerTempPath -and (Test-Path $result.CerTempPath)) {
                    Copy-Item -Path $result.CerTempPath -Destination (Join-Path $target "cert.cer") -Force
                    Remove-Item -Path $result.CerTempPath -Force -ErrorAction SilentlyContinue
                }
                
                # Eğer sistemde OpenSSL varsa PFX'ten Private Key dosyasını (cert.key) çıkartalım
                if (Get-Command openssl -ErrorAction SilentlyContinue) {
                    try {
                        Export-PSCMSslPrivateKey -PfxPath $destPfx -PfxPass $realPfxPass -OutFolder $target | Out-Null
                        
                        # Çıkan private.key dosyasını ACME uyumluluğu için cert.key olarak adlandıralım
                        $osKey = Join-Path $target "private.key"
                        if (Test-Path $osKey) {
                            Rename-Item -Path $osKey -NewName "cert.key" -Force
                        }
                    } catch {
                        Write-PSCMLog -Level WARNING -Message "LocalCA PFX dosyasindan cert.key cikarilamadi: $($_.Exception.Message)" -Source 'Certificate'
                    }
                }
                
                Write-PSCMLog -Level INFO -Message ('Sertifika PFX, CER ve KEY (varsa) kopyalandi: ' + $target) -Source 'Certificate'
            }
            
            $meta = [PSCustomObject]@{
                Domain=$realDomain; Wildcard=[bool]$Wildcard
                Issuer=$result.Issuer; Thumbprint=$result.Thumbprint
                NotBefore=$result.NotBefore; NotAfter=$result.NotAfter
                FriendlyName=$friendly; Path=$target
                SourceFolder=$target; CreatedAt=(Get-Date).ToString('o')
                Provider=$Provider
                SANList=($acmeDomains -join ',')
                TemplateName=$finalTemplateName
                IsCsrBased=[bool]$CsrPath
            }
        }
        $meta | Write-PSCMJson -Path (Join-Path $target 'metadata.json')
        $data = Get-PSCMState -Table 'certificates'
        $list = @($data | Where-Object { $_.Domain -ne $realDomain })
        $list += $meta
        Set-PSCMState -Table 'certificates' -Data $list
        Write-PSCMLog -Level INFO -Message ('Sertifika kayit edildi: ' + $realDomain) -Source 'Certificate'
        
        if (-not $CsrPath) {
            try {
                $deploys = @(Get-PSCMDeploymentConfig -Domain $realDomain)
                if ($deploys.Count -gt 0) {
                    Write-PSCMLog -Level INFO -Message ("$realDomain icin $($deploys.Count) adet deploy gorevi kuyruga ekleniyor.") -Source 'Certificate'
                    $pfxFiles = @(Get-ChildItem -Path $target -Filter '*.pfx' -File)
                    if ($pfxFiles.Count -gt 0) {
                        $pfxPath = $pfxFiles[0].FullName
                        foreach ($d in $deploys) {
                            $pArgs = @{
                                PfxFilePath = $pfxPath
                                SiteName = $d.SiteName
                            }
                            $dProps = $d.psobject.Properties.Name
                            if ($dProps -contains 'HostHeader' -and $d.HostHeader) { $pArgs['HostHeader'] = $d.HostHeader }
                            if ($dProps -contains 'PfxPass' -and $d.PfxPass) { $pArgs['PfxPass'] = $d.PfxPass }
                            if ($dProps -contains 'ComputerName' -and $d.ComputerName) { $pArgs['ComputerName'] = $d.ComputerName }
                            if ($dProps -contains 'DeployUsername' -and $d.DeployUsername) { $pArgs['DeployUsername'] = $d.DeployUsername }
                            
                            Add-PSCMAction -Action 'deploy' -Domain $realDomain -Params $pArgs | Out-Null
                            Write-PSCMLog -Level INFO -Message ("Kuyruga deploy eklendi: $($d.SiteName)") -Source 'Certificate'
                        }
                    } else {
                        Write-PSCMLog -Level WARNING -Message ("Deploy iptal edildi: PFX dosyasi bulunamadi ($target).") -Source 'Certificate'
                    }
                }
            } catch {
                Write-PSCMLog -Level ERROR -Message ("Deploy kuyruga eklenirken hata: " + $_.Exception.Message) -Source 'Certificate'
            }
        } else {
            Write-PSCMLog -Level INFO -Message ("CSR islemi: Private Key barinmadigi icin deploy gorevi atlanmistir.") -Source 'Certificate'
        }
        
        return $meta
    } catch {
        Write-PSCMLog -Level ERROR -Message ('Sertifika olusturulamadi: ' + $_.Exception.Message) -Source 'Certificate'
        throw
    } finally {
        if ($lock) { Unlock-PSCMResource -Name $lockName }
    }
}
