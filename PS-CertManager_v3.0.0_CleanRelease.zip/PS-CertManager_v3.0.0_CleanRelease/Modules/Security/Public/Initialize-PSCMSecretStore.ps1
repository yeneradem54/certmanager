﻿function Initialize-PSCMSecretStore {
<#
.SYNOPSIS
SecretStore vault'unu hazirlar.
#>
    [CmdletBinding()]
    param([switch]$AllowClobber)
    Write-PSCMLog -Level INFO -Message 'SecretStore hazirlaniyor.' -Source 'Security'
    $modules = @($script:PSCMSecretModule, $script:PSCMSecretStoreModule)
    foreach ($m in $modules) {
        if (-not (Get-Module -ListAvailable -Name $m)) {
            throw (New-PSCMException -Message ("Gerekli modul bulunamadi: {0}. Once Bootstrap calistirin." -f $m) -Category 'Guvenlik' -ErrorCode 'PSCM-5001')
        }
        Import-Module $m -Force -EA Stop
    }
    $existing = Get-SecretVault -Name $script:PSCMVaultName -EA SilentlyContinue
    if (-not $existing) {
        Register-SecretVault -Name $script:PSCMVaultName -ModuleName $script:PSCMSecretStoreModule -DefaultVault -AllowClobber:$AllowClobber
        Write-PSCMLog -Level INFO -Message ('Vault olusturuldu: ' + $script:PSCMVaultName) -Source 'Security'
    } else {
        Write-PSCMLog -Level INFO -Message ('Vault zaten kayitli: ' + $script:PSCMVaultName) -Source 'Security'
    }
    return $true
}
