<#
.SYNOPSIS
PS-CertManager uygulamasını kişisel verilerden (veritabanı, loglar, sertifikalar, ayarlar) arındırarak 
başkalarıyla paylaşılabilecek temiz bir ZIP sürümü haline getirir.
#>

$ErrorActionPreference = 'Stop'

Write-Host "=========================================" -ForegroundColor Cyan
Write-Host " PS-CertManager Temiz Sürüm Paketleyici  " -ForegroundColor Cyan
Write-Host "=========================================" -ForegroundColor Cyan
Write-Host ""

$PSScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$DesktopPath = [Environment]::GetFolderPath('Desktop')
$ReleaseZipPath = Join-Path $DesktopPath "PS-CertManager_v3.0.0_CleanRelease.zip"

# Staging (Hazırlık) dizinini oluştur
$StagingDir = Join-Path $env:TEMP "PSCM_Staging"
if (Test-Path $StagingDir) {
    Remove-Item -Path $StagingDir -Recurse -Force
}
New-Item -ItemType Directory -Path $StagingDir -Force | Out-Null

Write-Host "-> 1. Kaynak dosyalar hazirlik alanina kopyalaniyor..." -ForegroundColor Yellow
Copy-Item -Path "$PSScriptRoot\*" -Destination $StagingDir -Recurse -Force

Write-Host "-> 2. Kisisel veriler ve loglar temizleniyor..." -ForegroundColor Yellow

# Temizlenecek klasörlerin içini boşalt
$foldersToClean = @(
    "Logs",
    "Temp",
    "Certificates\Current",
    "Certificates\Archive",
    "Config\State"
)

foreach ($folder in $foldersToClean) {
    $targetFolder = Join-Path $StagingDir $folder
    if (Test-Path $targetFolder) {
        Remove-Item -Path "$targetFolder\*" -Recurse -Force -ErrorAction SilentlyContinue
    }
}

# Gerekli boş klasör hiyerarşisini (Özellikle Action Queue için) yeniden kur
$requiredFolders = @(
    "Logs",
    "Temp",
    "Certificates\Current",
    "Certificates\Archive",
    "Config\State\actions\pending",
    "Config\State\actions\processed",
    "Config\State\actions\failed"
)

foreach ($folder in $requiredFolders) {
    $targetFolder = Join-Path $StagingDir $folder
    if (-not (Test-Path $targetFolder)) {
        New-Item -ItemType Directory -Path $targetFolder -Force | Out-Null
    }
}

# Settings.json dosyasını şablona çevir
$settingsPath = Join-Path $StagingDir "Config\Settings.json"
if (Test-Path $settingsPath) {
    Remove-Item -Path $settingsPath -Force
}

$exampleSettings = @"
{
    "Certificate": {
        "RenewalThresholdDay": 30,
        "CAEndpoint": "https://acme-v02.api.letsencrypt.org/directory",
        "PoshACMEAccount": ""
    },
    "Azure": {
        "TenantId": "",
        "SubscriptionId": ""
    },
    "Notification": {
        "Smtp": {
            "Enabled": false,
            "Host": "",
            "Port": 587,
            "EnableSSL": true,
            "Username": "",
            "FromAddress": "",
            "ToAddresses": []
        },
        "Teams": {
            "Enabled": false,
            "WebhookRef": "Teams.Webhook"
        }
    }
}
"@
Set-Content -Path (Join-Path $StagingDir "Config\Settings.example.json") -Value $exampleSettings -Encoding UTF8

# Gizli dosyaları temizle (.git vb.)
$gitDir = Join-Path $StagingDir ".git"
if (Test-Path $gitDir) { Remove-Item -Path $gitDir -Recurse -Force }
$historyDir = Join-Path $StagingDir ".history"
if (Test-Path $historyDir) { Remove-Item -Path $historyDir -Recurse -Force }

# Eğer staging içinde ZIP dosyası kopyalanmışsa (yanlışlıkla), sil
Get-ChildItem -Path $StagingDir -Filter "*.zip" | Remove-Item -Force

Write-Host "-> 3. ZIP paketi olusturuluyor ($ReleaseZipPath)..." -ForegroundColor Yellow
if (Test-Path $ReleaseZipPath) {
    Remove-Item -Path $ReleaseZipPath -Force
}

# PowerShell Compress-Archive kullanarak Sıkıştır
Compress-Archive -Path "$StagingDir\*" -DestinationPath $ReleaseZipPath -Force

Write-Host "-> 4. Gecici hazirlik dizini siliniyor..." -ForegroundColor Yellow
Remove-Item -Path $StagingDir -Recurse -Force

Write-Host "`n[ OK ] Basarili! Temiz surum ZIP dosyasi masaustunuzde hazir:" -ForegroundColor Green
Write-Host "       $ReleaseZipPath" -ForegroundColor White
Write-Host ""
