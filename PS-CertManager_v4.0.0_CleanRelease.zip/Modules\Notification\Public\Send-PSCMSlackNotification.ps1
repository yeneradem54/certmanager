function Send-PSCMSlackNotification {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Title,
        [Parameter(Mandatory)][string]$Message,
        [ValidateSet('Bilgi','Uyari','Hata','Basari')][string]$Level = 'Bilgi'
    )
    $s = Get-PSSettings -Section 'Notification'
    if (-not $s.Enabled -or [string]::IsNullOrWhiteSpace($s.SlackWebhook)) { throw "Slack bildirimi pasif veya Webhook URL girilmemiş." }
    $webhook = $s.SlackWebhook
    
    $color = switch ($Level) { 'Bilgi'{'#0078D4'} 'Uyari'{'#F2C811'} 'Hata'{'#D13438'} 'Basari'{'#107C10'} default{'#0078D4'} }
    
    $payload = @{
        attachments = @(
            @{
                color = $color
                title = $Title
                text = $Message
            }
        )
    }
    
    try {
        $json = $payload | ConvertTo-Json -Depth 5
        Invoke-RestMethod -Uri $webhook -Method Post -Body $json -ContentType 'application/json; charset=utf-8' -EA Stop | Out-Null
        Write-PSCMLog -Level INFO -Message ('Slack bildirimi basarili: ' + $Title) -Source 'Notification'
    } catch {
        Write-PSCMLog -Level ERROR -Message ('Slack bildirim hatasi: ' + $_.Exception.Message) -Source 'Notification'
        throw
    }
}
