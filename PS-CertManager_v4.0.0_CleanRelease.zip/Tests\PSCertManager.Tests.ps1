#Requires -Modules Pester
<#
.SYNOPSIS
    PS-CertManager Modul Yukleme ve Altyapi Testleri
.DESCRIPTION
    Tum modullerin dogru yuklendigini ve temel fonksiyonlarin mevcut oldugunu dogrular.
#>

Describe 'PS-CertManager Test Suite' {
    BeforeAll {
        $script:ProjectRoot = (Get-Item $PSScriptRoot).Parent.FullName
        $script:ManifestPath = Join-Path $script:ProjectRoot 'Modules\PSCertManager\PSCertManager.psd1'
    }

    Context 'PSCertManager Ana Modul Testleri' {
        It 'Manifest dosyasi mevcut olmali' {
            Test-Path $script:ManifestPath | Should -Be $true
        }
        
        It 'Manifest gecerli bir PowerShell Data dosyasi olmali' {
            { Import-PowerShellDataFile -Path $script:ManifestPath } | Should -Not -Throw
        }
        
        It 'Manifest versiyonu 4.0.0 olmali' {
            $manifest = Import-PowerShellDataFile -Path $script:ManifestPath
            $manifest.ModuleVersion | Should -Be '4.0.0'
        }
        
        It 'Manifest GUID placeholder olmamali' {
            $manifest = Import-PowerShellDataFile -Path $script:ManifestPath
            $manifest.GUID | Should -Not -Be 'ffffffff-0000-1111-2222-333333333333'
            $manifest.GUID | Should -Not -BeNullOrEmpty
        }
        
        It 'Manifest en az 20 fonksiyon export etmeli' {
            $manifest = Import-PowerShellDataFile -Path $script:ManifestPath
            $manifest.FunctionsToExport.Count | Should -BeGreaterOrEqual 20
        }
        
        It 'Tum NestedModules dosyalari mevcut olmali' {
            $manifest = Import-PowerShellDataFile -Path $script:ManifestPath
            $modulesRoot = Split-Path -Parent $script:ManifestPath
            foreach ($nested in $manifest.NestedModules) {
                $nestedPath = Join-Path $modulesRoot $nested
                Test-Path $nestedPath | Should -Be $true
            }
        }
    }

    Context 'Alt Modul Manifest Testleri' {
        $moduleNames = @(
            'Common', 'Logging', 'Security', 'Settings', 'Bootstrap',
            'AzureDNS', 'ACME', 'Certificate', 'LocalCA', 'Notification',
            'Dashboard', 'Scheduler', 'ActionQueue', 'WebServer', 'Testing', 'Deployment', 'CLI', 'SSLTools'
        )
        
        foreach ($moduleName in $moduleNames) {
            It "<moduleName> manifest dosyasi mevcut ve gecerli 4.0.0 olmali" -TestCases @(@{ moduleName = $moduleName }) {
                param($moduleName)
                $modRoot = Join-Path $script:ProjectRoot "Modules\$moduleName"
                $psd1Files = @(Get-ChildItem -Path $modRoot -Filter '*.psd1' -ErrorAction SilentlyContinue)
                $psd1Files.Count | Should -BeGreaterOrEqual 1
                
                $data = Import-PowerShellDataFile -Path $psd1Files[0].FullName
                $data.ModuleVersion | Should -Be '4.0.0'
                ($data.GUID -notmatch '12345678|eeeeeeee|aaaaaaaa') | Should -Be $true
            }
        }
    }

    Context 'Proje Yapisal Butunluk Testleri' {
        It 'README.md mevcut olmali' {
            Test-Path (Join-Path $script:ProjectRoot 'README.md') | Should -Be $true
        }
        
        It 'CHANGELOG.md mevcut olmali' {
            Test-Path (Join-Path $script:ProjectRoot 'CHANGELOG.md') | Should -Be $true
        }
        
        It 'Manager-Start.ps1 mevcut olmali' {
            Test-Path (Join-Path $script:ProjectRoot 'Manager-Start.ps1') | Should -Be $true
        }
        
        It 'Config klasoru mevcut olmali' {
            Test-Path (Join-Path $script:ProjectRoot 'Config') | Should -Be $true
        }
    }

    Context 'Modul Mimari Uygunluk Testleri' {
        $standardModules = @(
            'Common', 'Logging', 'Security', 'Settings', 'Bootstrap',
            'AzureDNS', 'ACME', 'Certificate', 'Notification',
            'Dashboard', 'Scheduler', 'ActionQueue', 'WebServer', 'Testing',
            'LocalCA', 'Deployment', 'CLI', 'SSLTools'
        )
        
        foreach ($moduleName in $standardModules) {
            It "<moduleName> modulunde Public/ klasoru olmali" -TestCases @(@{ moduleName = $moduleName }) {
                param($moduleName)
                $pubPath = Join-Path $script:ProjectRoot "Modules\$moduleName\Public"
                Test-Path $pubPath | Should -Be $true
            }
        }
    }
}
