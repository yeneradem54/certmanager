function Invoke-SubMenuAutomation {
    $subRun = $true
    while ($subRun) {
        Show-PSCMBanner
        Write-Host '  --- OTOMASYON & ZAMANLAYICI YONETIMI ---' -ForegroundColor Yellow
        Write-Host ''
        Write-Host '  [1] Islem Kuyrugu (Action Queue) - Bekleyen Islemleri Gorutule & Isle' -ForegroundColor White
        Write-Host '  [2] Windows Gorev Zamanlayicisi (Task Scheduler) Kurulumu & Durumu' -ForegroundColor White
        Write-Host ''
        Write-Host '  Enter) Ana Menuye Don' -ForegroundColor DarkGray
        Write-Host ''
        $sub = Read-Host 'Secim'
        switch ($sub) {
            '1' { Invoke-MenuActionQueue }
            '2' { Invoke-MenuScheduler }
            ''  { $subRun = $false }
        }
    }
}

function Invoke-SubMenuOperations {
    $subRun = $true
    while ($subRun) {
        Show-PSCMBanner
        Write-Host '>> Sertifika Operasyonlari' -ForegroundColor Yellow
        Write-Host ''
        Write-Host '  1) Sertifika Listesi & Islemler'
        Write-Host '  2) Yeni Sertifika Olustur'
        Write-Host '  3) Islem Kuyrugu (Action Queue)'
        Write-Host '  4) IIS Dagitim (Deployment) Ayarlari'
        Write-Host '  5) SSL Araclari (CSR, PEM, PFX, Keystore)'
        Write-Host ''
        Write-Host '  Enter) Geri Don' -ForegroundColor DarkGray
        $sub = Read-Host 'Secim'
        switch ($sub) {
            '1' { Invoke-MenuCertificates }
            '2' { Invoke-MenuNewCertificate }
            '3' { Invoke-MenuActionQueue }
            '4' { Invoke-MenuDeployments }
            '5' { Invoke-MenuSslTools }
            ''  { $subRun = $false }
        }
    }
}

function Invoke-SubMenuSettings {
    $subRun = $true
    while ($subRun) {
        Show-PSCMBanner
        Write-Host '  --- GUVENLIK & YAPILANDIRMA AYARLARI ---' -ForegroundColor Yellow
        Write-Host ''
        Write-Host '  [1] Wizard ile Kurulum / Onarim Sihirbazi' -ForegroundColor White
        Write-Host '  [2] Guvenlik, Parola ve Kasa (SecretStore) Ayarlari' -ForegroundColor White
        Write-Host '  [3] Bildirim (Notification) Kanallari ve Testi (Slack/Teams/SMTP)' -ForegroundColor White
        Write-Host '  [4] Local CA (ADCS) Izin ve Yetki Yonetimi' -ForegroundColor White
        Write-Host '  [5] Global Varsayilan Degerler (Defaults) Yonetimi' -ForegroundColor White
        Write-Host '  [6] DNS & ACME Provider Ayarlari' -ForegroundColor White
        Write-Host ''
        Write-Host '  Enter) Ana Menuye Don' -ForegroundColor DarkGray
        Write-Host ''
        $sub = Read-Host 'Secim'
        switch ($sub) {
            '1' { Invoke-MenuWizard }
            '2' { Invoke-MenuSecuritySettings }
            '3' { Invoke-MenuNotifications }
            '4' { Invoke-MenuLocalCAPermissions }
            '5' { Invoke-MenuDefaults }
            '6' { Invoke-MenuDnsSettings }
            ''  { $subRun = $false }
        }
    }
}

function Invoke-SubMenuMaintenance {
    $subRun = $true
    while ($subRun) {
        Show-PSCMBanner
        Write-Host '  --- BAKIM, TEST & SORUN GIDERME ---' -ForegroundColor Yellow
        Write-Host ''
        Write-Host '  --- LOGLAR & ALTYAPI ---' -ForegroundColor Cyan
        Write-Host '  [1] Sistem Loglarini Goruntule' -ForegroundColor White
        Write-Host '  [2] Altyapi ve Klasor Butunlugunu Kontrol Et' -ForegroundColor White
        Write-Host ''
        Write-Host '  --- TEST OTOMASYONLARI ---' -ForegroundColor Cyan
        Write-Host '  [3] Sertifika Sagligini Test Et (Sure / Eslesme)' -ForegroundColor White
        Write-Host '  [4] Sistem E2E ve API Entegrasyon Testini Calistir' -ForegroundColor White
        Write-Host '  [5] Pester Birim Testlerini (Unit Tests) Calistir' -ForegroundColor White
        Write-Host ''
        Write-Host '  --- OTOMASYON & BAGIMLILIKLAR ---' -ForegroundColor Cyan
        Write-Host '  [6] Zamanlayiciyi (Scheduler) Zorla Calistir (-Force)' -ForegroundColor White
        Write-Host '  [7] Bekleyen Islem Kuyrugunu (Action Queue) Temizle' -ForegroundColor White
        
        $acme = Get-PSSettings -Section 'Acme'
        $currentProvider = if ($acme.PSObject.Properties.Name -contains 'Provider' -and $acme.Provider) { $acme.Provider } else { 'LetsEncrypt' }
        $oppositeProvider = if ($currentProvider -eq 'LetsEncrypt') { 'LetsEncryptStaging' } else { 'LetsEncrypt' }
        Write-Host "  [8] ACME Ortamini Degistir (Su an: $currentProvider -> $oppositeProvider Yap)" -ForegroundColor White
        Write-Host '  [9] Eksik Bagimliliklari Kur (OpenSSL vb.)' -ForegroundColor White
        Write-Host '  [10] Klasordeki Sertifikalari Veritabanina Senkronize Et (Import/Sync)' -ForegroundColor Cyan
        Write-Host ''
        Write-Host '  Enter) Ana Menuye Don' -ForegroundColor DarkGray
        Write-Host ''
        
        $sub = Read-Host 'Secim'
        switch ($sub) {
            '1' { Invoke-MenuLogs }
            '2' { Invoke-MenuInfrastructure }
            '3' { Invoke-MenuTest }
            '4' { 
                Show-PSCMBanner
                Write-Host '>> E2E Sistem Testleri Basliyor' -ForegroundColor Yellow
                try { Invoke-PSCMTestSuite } catch { Write-Host "Hata: $($_.Exception.Message)" -ForegroundColor Red }
                Pause-PSCM
            }
            '5' {
                Show-PSCMBanner
                Write-Host '>> Pester Birim Testleri Baslatiliyor...' -ForegroundColor Yellow
                try {
                    $modulesPath = Get-PSCMPath -Name Modules
                    $rootPath = Split-Path -Parent $modulesPath
                    $testsPath = Join-Path $rootPath "Tests\PSCertManager.Tests.ps1"
                    if (Test-Path $testsPath) {
                        Invoke-Pester -Path $testsPath
                    } else {
                        Write-Host "Test dosyasi bulunamadi: $testsPath" -ForegroundColor Red
                    }
                } catch { Write-Host "Hata: $($_.Exception.Message)" -ForegroundColor Red }
                Pause-PSCM
            }
            '6' {
                Show-PSCMBanner
                Write-Host '>> Zamanlayici Zorla Calistiriliyor (Tum sertifikalar yenilenmeyi deneyecek)' -ForegroundColor Yellow
                Write-Host "Bu islem, uretim (Production) sunucularinda Let's Encrypt kotalarini (Rate Limit) hizli doldurabilir!" -ForegroundColor Red
                $confirm = Read-Host 'Devam etmek istiyor musunuz? [E/H]'
                if ($confirm -match '^[EeYy]') {
                    try { Invoke-PSCMRenewalCycle -Force } catch { Write-Host "Hata: $($_.Exception.Message)" -ForegroundColor Red }
                }
                Pause-PSCM
            }
            '7' {
                Show-PSCMBanner
                Write-Host '>> Bekleyen (Pending) ve Hatali (Failed) kuyruk temizleniyor...' -ForegroundColor Yellow
                try {
                    Clear-PSCMActionQueue -All
                    Write-Host 'Kuyruk temizlendi.' -ForegroundColor Green
                } catch { Write-Host "Hata: $($_.Exception.Message)" -ForegroundColor Red }
                Pause-PSCM
            }
            '8' {
                try {
                    if ($acme.PSObject.Properties.Name -contains 'Provider') { $acme.Provider = $oppositeProvider }
                    else { $acme | Add-Member -NotePropertyName 'Provider' -NotePropertyValue $oppositeProvider }
                    Set-PSSettings -Section 'Acme' -Value $acme
                    Write-Host "ACME Ortami $oppositeProvider olarak degistirildi." -ForegroundColor Green
                } catch { Write-Host "Hata: $($_.Exception.Message)" -ForegroundColor Red }
                Pause-PSCM
            }
            '9' {
                Show-PSCMBanner
                Write-Host '>> Eksik Bagimliliklar (OpenSSL) Kontrol Ediliyor...' -ForegroundColor Yellow
                $hasOpenSsl = Get-Command openssl -ErrorAction SilentlyContinue
                if ($hasOpenSsl) {
                    Write-Host "Sistemde OpenSSL zaten kurulu ve PATH'e ekli! ($($hasOpenSsl.Source))" -ForegroundColor Green
                } else {
                    Write-Host "OpenSSL bulunamadi. Winget uzerinden kurulum baslatiliyor. Lutfen bekleyin..." -ForegroundColor Yellow
                    try {
                        & winget install -e --id FireDaemon.OpenSSL --accept-package-agreements --accept-source-agreements --silent
                        
                        # PATH guncellemesi (mevcut oturumu yeniden baslatmaya gerek kalmamasi icin)
                        $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
                        
                        Write-Host "`n[!] Kurulum basariyla tamamlandi!" -ForegroundColor Green
                        Write-Host "[!] OpenSSL komutu sisteme tanitildi ve kullanima hazir." -ForegroundColor Green
                    } catch {
                        Write-Host "Kurulum sirasinda hata olustu: $($_.Exception.Message)" -ForegroundColor Red
                    }
                }
                Pause-PSCM
            }
            '10' {
                Show-PSCMBanner
                Write-Host '>> Certificates\Current klasoru taraniyor...' -ForegroundColor Cyan
                try {
                    Sync-PSCMCertificateCache
                } catch {
                    Write-Host "Senkronizasyon hatasi: $($_.Exception.Message)" -ForegroundColor Red
                }
                Pause-PSCM
            }
            ''  { $subRun = $false }
        }
    }
}
