function Get-PSInfrastructure {
<#
.SYNOPSIS
Sistem/altyapi bilesenlerini analiz eder.
#>
    [CmdletBinding()]
    param()
    Write-PSCMLog -Level INFO -Message 'Altyapi kontrolu baslatildi.' -Source 'Bootstrap'
    $results = New-Object System.Collections.Generic.List[object]

    $psOk = ($PSVersionTable.PSVersion.Major -ge 5)
    $psStat = if ($psOk) { 'OK' } else { 'HATA' }
    $results.Add([PSCustomObject]@{ Kategori='PowerShell'; Bilesen='PowerShell Surumu'; Durum=$psStat; Detay=$PSVersionTable.PSVersion.ToString() })

    $isAdmin = Test-PSCMAdmin
    $adminStat = if ($isAdmin) { 'OK' } else { 'UYARI' }
    $adminDetay = if ($isAdmin) { 'Yonetici olarak calisiyor.' } else { 'Bazi islemler yonetici yetkisi gerektirir.' }
    $results.Add([PSCustomObject]@{ Kategori='Yetki'; Bilesen='Yonetici Yetkisi'; Durum=$adminStat; Detay=$adminDetay })

    foreach ($m in $script:PSCMRequiredModules) {
        $installed = Get-Module -ListAvailable -Name $m.Name | Sort-Object Version -Descending | Select-Object -First 1
        if ($installed) {
            $verOk = ($installed.Version -ge [Version]$m.MinVersion)
            $stat = if ($verOk) { 'OK' } else { 'UYARI' }
            $detay = 'Yuklu: ' + $installed.Version + ' / Gerekli: ' + $m.MinVersion
            $results.Add([PSCustomObject]@{ Kategori='Modul'; Bilesen=$m.Name; Durum=$stat; Detay=$detay })
        } else {
            $detay = 'Bulunamadi. Gerekli: ' + $m.MinVersion + ' - ' + $m.Purpose
            $results.Add([PSCustomObject]@{ Kategori='Modul'; Bilesen=$m.Name; Durum='EKSIK'; Detay=$detay })
        }
    }
    foreach ($n in @('Config','Certificates','Current','Archive','Logs','Temp')) {
        $p = Get-PSCMPath -Name $n
        $stat = if (Test-Path $p) { 'OK' } else { 'HATA' }
        $results.Add([PSCustomObject]@{ Kategori='Klasor'; Bilesen=$n; Durum=$stat; Detay=$p })
    }
    $letsOk = $false
    try {
        $r = Invoke-WebRequest -Uri 'https://acme-v02.api.letsencrypt.org/directory' -UseBasicParsing -TimeoutSec 10
        $letsOk = ($r.StatusCode -eq 200)
    } catch { $letsOk = $false }
    $letsStat = if ($letsOk) { 'OK' } else { 'UYARI' }
    $results.Add([PSCustomObject]@{ Kategori='Ag'; Bilesen="Let's Encrypt Erisimi"; Durum=$letsStat; Detay='https://acme-v02.api.letsencrypt.org/directory' })

    $azOk = $false; $azDetay = 'Baglanti yok'
    try {
        if (Get-Command Get-AzContext -EA SilentlyContinue) {
            $ctx = Get-AzContext -EA SilentlyContinue
            if ($ctx) { $azOk = $true; $azDetay = 'Tenant: ' + $ctx.Tenant.Id + ' / Sub: ' + $ctx.Subscription.Name }
        }
    } catch {}
    $azStat = if ($azOk) { 'OK' } else { 'UYARI' }
    $results.Add([PSCustomObject]@{ Kategori='Azure'; Bilesen='Az Context'; Durum=$azStat; Detay=$azDetay })

    Write-PSCMLog -Level INFO -Message ('Altyapi kontrolu tamamlandi. Toplam bilesen: ' + $results.Count) -Source 'Bootstrap'
    return $results
}
