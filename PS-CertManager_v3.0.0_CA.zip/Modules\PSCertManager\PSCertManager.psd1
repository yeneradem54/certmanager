@{
    RootModule = 'PSCertManager.psm1'
    ModuleVersion = '3.0.0'
    GUID = 'ffffffff-0000-1111-2222-333333333333'
    Author = 'PS-CertManager Ekibi'
    CompanyName = 'PS-CertManager'
    Copyright = '(c) 2026 PS-CertManager. Tum haklari saklidir.'
    Description = 'PS-CertManager v3.0.0 - Multi-Domain Certificate Lifecycle Management Framework'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    NestedModules = @(
        '..\Common\PSCM.Common.psd1',
        '..\Logging\PSCM.Logging.psd1',
        '..\Security\PSCM.Security.psd1',
        '..\Settings\PSCM.Settings.psd1',
        '..\Bootstrap\PSCM.Bootstrap.psd1',
        '..\AzureDNS\PSCM.AzureDNS.psd1',
        '..\ACME\PSCM.ACME.psd1',
        '..\Certificate\PSCM.Certificate.psd1',
        '..\Notification\PSCM.Notification.psd1',
        '..\Dashboard\PSCM.Dashboard.psd1',
        '..\Scheduler\PSCM.Scheduler.psd1',
        '..\ActionQueue\PSCM.ActionQueue.psd1',
        '..\WebServer\PSCM.WebServer.psd1',
        '..\Testing\PSCM.Testing.psd1',
        '..\Deployment\PSCM.Deployment.psd1',
        '..\LocalCA\PSCM.LocalCA.psd1'
    )
    FunctionsToExport = @(
        'Get-PSCMRootPath','Get-PSCMPath','Read-PSCMJson','Write-PSCMJson',
        'Test-PSCMAdmin','Get-PSCMVersion','Lock-PSCMResource','Unlock-PSCMResource',
        'ConvertTo-PSCMSafeString','New-PSCMException',
        'Copy-PSCMPoshAcmeOutput','Format-PSCMCertTable',
        'Get-PSCMState','Set-PSCMState','Invoke-PSCMReliableAction','Initialize-PSCMSQLite',
        'Write-PSCMLog','Get-PSLog','Invoke-PSCMLogRotation',
        'Initialize-PSCMSecretStore','Set-PSCMSecret','Get-PSCMSecret','Remove-PSCMSecret','Unlock-PSCMSecretStore','Set-PSCMSecretStorePolicy',
        'Get-PSSettings','Set-PSSettings','Initialize-PSCMSettings',
        'Initialize-PSCertManager','Get-PSInfrastructure','Repair-PSInfrastructure','Start-PSCMConfigWizard',
        'Connect-PSCMAzure','Test-PSAzure','Get-PSCMDnsZone','Find-PSCMDnsZone','Add-PSCMDnsZone','Get-PSCMDnsZones','Remove-PSCMDnsZone',
        'Initialize-PSCMAcmeProvider','New-PSCMAcmeCertificate','Update-PSCMAcmeCertificate',
        'Get-PSCertificate','New-PSCertificate','Update-PSCertificate','Remove-PSCertificate','Export-PSCertificate','Test-PSCertificate','Repair-PSCMCertificatePfx',
        'Send-PSCMMailNotification','Send-PSCMTeamsNotification',
        'Get-PSDashboard','New-PSDashboard',
        'Register-PSCMRenewalTask','Unregister-PSCMRenewalTask','Get-PSCMRenewalTask','Invoke-PSCMRenewalCycle',
        'Add-PSCMAction','Get-PSCMActionQueue','Invoke-PSCMActionQueue','Clear-PSCMActionQueue','Import-PSCMActionFile',
        'Start-PSCMWebServer','Invoke-PSCMTestSuite',
        'Install-CertificateToStore','Set-IISCertificateBinding','Invoke-RemoteIISDeployment','Get-PSCMDeploymentConfig','Get-PSCMIISBinding',
        'Invoke-PSCMLocalCACertificateRequest'
    )
    CmdletsToExport = @()
    AliasesToExport = @()
    VariablesToExport = @()
    PrivateData = @{
        PSData = @{
            Tags = @('PKI','ACME','Certificate','LetsEncrypt','Azure','DNS','CLM','Scheduler','Queue','MultiDomain')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ReleaseNotes = 'v2.3.1 HOTFIX - Format-PSCMCertTable PassThru array garantisi + ConvertFrom-PSCMRangeString rezerve degisken cakismasi cozuldu.'
        }
    }
}
