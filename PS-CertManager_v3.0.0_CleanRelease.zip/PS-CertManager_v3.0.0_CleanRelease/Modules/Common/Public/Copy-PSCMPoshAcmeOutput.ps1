﻿function Copy-PSCMPoshAcmeOutput {
<#
.SYNOPSIS
Posh-ACME ciktisini hedef klasore kopyalar (New/Update icin ortak helper).
.DESCRIPTION
CertFolder property yoksa CertFile'dan Split-Path ile turetir.
Get-PACertificate fallback yapar. Kopyalanan dosya sayisini,
kaynak klasoru ve X509'dan cikarilmis meta bilgiyi dondurur.
#>
    [CmdletBinding()]
    param(
        [Parameter()]$AcmeResult,
        [Parameter(Mandatory)][string]$Domain,
        [Parameter(Mandatory)][string]$Destination
    )
    $availableProps = @()
    if ($AcmeResult) { $availableProps = @($AcmeResult.PSObject.Properties.Name) }

    $certFolder = $null
    if ($availableProps -contains 'CertFolder' -and $AcmeResult.CertFolder) {
        $certFolder = [string]$AcmeResult.CertFolder
    } elseif ($availableProps -contains 'CertFile' -and $AcmeResult.CertFile) {
        $certFolder = Split-Path -Parent ([string]$AcmeResult.CertFile)
    }
    if (-not $certFolder) {
        try {
            Import-Module Posh-ACME -ErrorAction Stop
            $paCert = Get-PACertificate -MainDomain $Domain -ErrorAction SilentlyContinue
            if ($paCert) {
                $paProps = @($paCert.PSObject.Properties.Name)
                if ($paProps -contains 'CertFolder' -and $paCert.CertFolder) {
                    $certFolder = [string]$paCert.CertFolder
                } elseif ($paProps -contains 'CertFile' -and $paCert.CertFile) {
                    $certFolder = Split-Path -Parent ([string]$paCert.CertFile)
                }
                if (-not $AcmeResult) { $AcmeResult = $paCert; $availableProps = $paProps }
            }
        } catch { }
    }
    if (-not $certFolder -or -not (Test-Path -LiteralPath $certFolder)) {
        throw (New-PSCMException -Message ('Posh-ACME sertifika klasoru bulunamadi. Property listesi: ' + ($availableProps -join ', ')) -Category 'ACME' -ErrorCode 'PSCM-1021')
    }
    if (-not (Test-Path -LiteralPath $Destination)) {
        New-Item -ItemType Directory -Path $Destination -Force | Out-Null
    }
    $sourceFiles = Get-ChildItem -Path $certFolder -File -ErrorAction SilentlyContinue
    if (-not $sourceFiles -or $sourceFiles.Count -eq 0) {
        throw (New-PSCMException -Message ('Kaynak klasor bos: ' + $certFolder) -Category 'ACME' -ErrorCode 'PSCM-1022')
    }
    $copied = 0
    foreach ($srcFile in $sourceFiles) {
        $destPath = Join-Path $Destination $srcFile.Name
        try {
            Copy-Item -LiteralPath $srcFile.FullName -Destination $destPath -Force -ErrorAction Stop
            $copied++
        } catch { }
    }
    if ($copied -eq 0) {
        throw (New-PSCMException -Message 'Hicbir dosya kopyalanamadi.' -Category 'ACME' -ErrorCode 'PSCM-1023')
    }
    $thumb = ''; $nb = $null; $na = $null; $issuer = "Let's Encrypt"
    if ($availableProps -contains 'Thumbprint' -and $AcmeResult.Thumbprint) { $thumb = [string]$AcmeResult.Thumbprint }
    if ($availableProps -contains 'Issuer' -and $AcmeResult.Issuer) { $issuer = [string]$AcmeResult.Issuer }
    $certPath = Join-Path $Destination 'cert.cer'
    if (Test-Path -LiteralPath $certPath) {
        try {
            $x509 = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($certPath)
            if (-not $thumb) { $thumb = $x509.Thumbprint }
            $nb = $x509.NotBefore.ToString('o')
            $na = $x509.NotAfter.ToString('o')
            $issuerStr = $x509.Issuer
            if ($issuerStr -match 'CN=([^,]+)') { $issuer = $matches[1].Trim() }
        } catch { }
    }
    return [PSCustomObject]@{
        SourceFolder = $certFolder
        Destination  = $Destination
        CopiedCount  = $copied
        TotalCount   = $sourceFiles.Count
        Thumbprint   = $thumb
        NotBefore    = $nb
        NotAfter     = $na
        Issuer       = $issuer
    }
}
