function Get-PSCMRootPath {
<#
.SYNOPSIS
PS-CertManager kok klasorunu dondurur.
#>
    [CmdletBinding()]
    param()
    if ($env:PSCM_ROOT -and (Test-Path -LiteralPath $env:PSCM_ROOT)) {
        return (Resolve-Path -LiteralPath $env:PSCM_ROOT).Path
    }
    
    # In Windows PowerShell 5.1, when this function is called, 
    # $PSScriptRoot inside the function is not guaranteed to be stable if dot-sourced.
    # However, since this framework has a strict folder structure:
    # Root -> Modules -> Common -> Public -> Get-PSCMRootPath.ps1
    # We can just look for Manager-Start.ps1 anywhere in the call stack paths.
    
    $searchPaths = @($PSScriptRoot, $PSScriptRoot + '\..\..\..', (Get-Location).Path)
    $mod = Get-Module PSCertManager -ErrorAction SilentlyContinue
    if ($mod -and $mod.ModuleBase) {
        $searchPaths += $mod.ModuleBase + '\..\..'
    }

    foreach ($p in $searchPaths) {
        if (-not $p) { continue }
        $current = $p
        for ($i = 0; $i -lt 6; $i++) {
            if (-not $current) { break }
            if (Test-Path -LiteralPath (Join-Path $current 'Manager-Start.ps1') -ErrorAction SilentlyContinue) {
                return (Resolve-Path -LiteralPath $current).Path
            }
            $current = Split-Path -Parent $current
        }
    }

    throw (New-Object PSCMException('PS-CertManager kok klasoru bulunamadi.','Yapilandirma','PSCM-3001'))
}
