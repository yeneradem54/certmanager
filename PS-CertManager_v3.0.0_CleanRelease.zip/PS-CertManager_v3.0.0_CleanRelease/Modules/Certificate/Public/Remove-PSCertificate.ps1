function Remove-PSCertificate {
<#
.SYNOPSIS
Sertifikayi index'ten cikarir. Dosyalar Archive'a tasinir.
#>
    [CmdletBinding(SupportsShouldProcess,ConfirmImpact='High')]
    param([Parameter(Mandatory)][string]$Domain)
    if ($PSCmdlet.ShouldProcess($Domain,'Sertifika kaldir')) {
        $data = @(Get-PSCMState -Table 'certificates')
        if ($data.Count -gt 0) {
            $filtered = @($data | Where-Object { $_.Domain -ne $Domain })
            Set-PSCMState -Table 'certificates' -Data $filtered
        }
        $safe = ($Domain -replace '\*','wildcard') -replace '[^a-zA-Z0-9\.\-_]','_'
        $currentDir = Join-Path (Get-PSCMPath -Name Current) $safe
        if (Test-Path -LiteralPath $currentDir) {
            $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
            $archive = Join-Path (Join-Path (Get-PSCMPath -Name Archive) $safe) ('removed_' + $stamp)
            Move-Item -LiteralPath $currentDir -Destination $archive -Force
            Write-PSCMLog -Level INFO -Message ('Aktif klasor arsivlendi: ' + $archive) -Source 'Certificate'
        }
        Write-PSCMLog -Level INFO -Message ('Sertifika index kaldirildi: ' + $Domain) -Source 'Certificate'
    }
}
