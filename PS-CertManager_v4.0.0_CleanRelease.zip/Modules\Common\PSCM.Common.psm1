#Requires -Version 5.1
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'

$PrivateFiles = @('PSCMException.ps1','PSCMPaths.ps1')
foreach ($f in $PrivateFiles) {
    . (Join-Path $PSScriptRoot ('Private\' + $f))
}

Get-ChildItem -Path (Join-Path $PSScriptRoot 'Public') -Filter '*.ps1' -ErrorAction SilentlyContinue | ForEach-Object {
    . $_.FullName
}

Export-ModuleMember -Function @(
    'Get-PSCMRootPath','Get-PSCMPath','Read-PSCMJson','Write-PSCMJson',
    'Test-PSCMAdmin','Get-PSCMVersion','Lock-PSCMResource','Unlock-PSCMResource',
    'ConvertTo-PSCMSafeString','New-PSCMException',
    'Copy-PSCMPoshAcmeOutput','Format-PSCMCertTable',
    'Get-PSCMState','Set-PSCMState','Invoke-PSCMReliableAction','Initialize-PSCMSQLite'
)
