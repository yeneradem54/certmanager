function Invoke-MenuInfrastructure {
    Show-PSCMBanner
    Write-Host '  --- ALTYAPI & KLASOR KONTROLU ---' -ForegroundColor Yellow
    Write-Host ''
    $report = Get-PSInfrastructure
    $report | Format-Table Kategori,Bilesen,Durum,Detay -AutoSize | Out-String -Stream | ForEach-Object { Write-Host $_ }
    $azRow = $report | Where-Object { $_.Kategori -eq 'Azure' } | Select-Object -First 1
    if ($azRow -and $azRow.Durum -ne 'OK') {
        Write-Host ''
        Write-Host '  ! Azure baglantisi kurulu degil. Menu 8 ile ayarlayin.' -ForegroundColor Yellow
    }
    Write-Host ''
    $yn = Read-Host 'Eksik modul/klasor yuklensin mi? [E/H]'
    if ($yn -match '^[EeYy]') {
        Repair-PSInfrastructure | Format-Table Kategori,Bilesen,Durum -AutoSize | Out-String -Stream | ForEach-Object { Write-Host $_ }
    }
    Pause-PSCM
}
