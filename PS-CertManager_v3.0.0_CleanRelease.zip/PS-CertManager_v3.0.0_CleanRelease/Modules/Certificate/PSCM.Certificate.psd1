﻿@{
    RootModule = 'PSCM.Certificate.psm1'
    ModuleVersion = '2.2.1'
    GUID = '88888888-8888-8888-8888-888888888888'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager Sertifika Yasam Dongusu Modulu'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Get-PSCertificate','New-PSCertificate','Update-PSCertificate','Remove-PSCertificate','Export-PSCertificate','Test-PSCertificate','Repair-PSCMCertificatePfx')
}
