﻿function Export-PSCertificate {
<#
.SYNOPSIS
Sertifika dosyalarini istenen formatta hedef klasore kopyalar.
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Domain,
        [Parameter(Mandatory)][string]$Destination,
        [ValidateSet('pfx','pem','crt','key','all')][string]$Format = 'all'
    )
    $c = Get-PSCertificate -Domain $Domain | Select-Object -First 1
    if (-not $c) { throw (New-PSCMException -Message ('Sertifika bulunamadi: ' + $Domain) -Category 'Dogrulama' -ErrorCode 'PSCM-4011') }
    if (-not (Test-Path $Destination)) { New-Item -ItemType Directory -Path $Destination -Force | Out-Null }
    $map = @{
        pfx = @('fullchain.pfx')
        pem = @('fullchain.cer','cert.key')
        crt = @('cert.cer','chain.cer','fullchain.cer')
        key = @('cert.key')
        all = @('cert.cer','chain.cer','fullchain.cer','cert.key','fullchain.pfx')
    }
    foreach ($f in $map[$Format]) {
        $src = Join-Path $c.Path $f
        if (Test-Path -LiteralPath $src) {
            Copy-Item -LiteralPath $src -Destination (Join-Path $Destination $f) -Force
        }
    }
    Write-PSCMLog -Level INFO -Message ('Sertifika export: {0} -> {1}' -f $Domain,$Destination) -Source 'Certificate'
}
