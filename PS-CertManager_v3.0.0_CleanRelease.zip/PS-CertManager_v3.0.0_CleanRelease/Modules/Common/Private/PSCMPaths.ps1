$script:PSCMPathMap = @{
    Config       = 'Config'
    State        = 'Config\State'
    Certificates = 'Certificates'
    Current      = 'Certificates\Current'
    Archive      = 'Certificates\Archive'
    Logs         = 'Logs'
    Dashboard    = 'Dashboard'
    Temp         = 'Temp'
    Modules      = 'Modules'
}
