function Write-DeployLog {
    param($Level, $Message)
    if (Get-Command Write-PSCMLog -ErrorAction SilentlyContinue) {
        Write-PSCMLog -Level $Level -Message $Message -Source 'Deployment'
    } else {
        if ($Level -eq 'ERROR') { Write-Error $Message }
        else { Write-Host "[$Level] $Message" }
    }
}
