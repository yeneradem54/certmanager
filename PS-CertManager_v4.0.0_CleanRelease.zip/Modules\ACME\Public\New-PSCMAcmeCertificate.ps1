function New-PSCMAcmeCertificate {
<#
.SYNOPSIS
ACME uzerinden yeni sertifika olusturur.
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string[]]$Domain,
        [Parameter(Mandatory=$false)][System.Security.SecureString]$PfxPass,
        [string]$CsrPath,
        [string]$AcmeProvider
    )
    Write-PSCMLog -Level INFO -Message ('ACME sertifika istegi baslatildi: ' + $Domain[0]) -Source 'ACME'
    Connect-PSCMAzure | Out-Null
    $az = Get-PSSettings -Section 'Azure'
    $acme = Get-PSSettings -Section 'Acme'
    $provider = Initialize-PSCMAcmeProvider -ProviderOverride $AcmeProvider
    $provider.Register($acme.AccountEmail) | Out-Null
    
    $params = @{ Domain=$Domain }
    if ($PfxPass) { $params['PfxPass'] = $PfxPass }
    if ($CsrPath) { $params['CSRPath'] = $CsrPath }
    
    $dnsPlugin = 'Azure'
    if ($acme.PSObject.Properties.Name -contains 'DnsPlugin' -and -not [string]::IsNullOrWhiteSpace($acme.DnsPlugin)) {
        $dnsPlugin = $acme.DnsPlugin
    }
    $params['DnsPlugin'] = $dnsPlugin

    $pArgs = @{}
    
    if ($dnsPlugin -eq 'Azure') {
        $pArgs['AZSubscriptionId'] = $az.SubscriptionId
        $pArgs['AZTenantId']       = $az.TenantId
        if ($az.AuthMode -eq 'ServicePrincipal') {
            $secret = Get-PSCMSecret -Name 'Azure.ClientSecret'
            $cred   = New-Object System.Management.Automation.PSCredential($az.ClientId, $secret)
            $pArgs['AZAppCred'] = $cred
        }
    }
    elseif ($dnsPlugin -eq 'Cloudflare') {
        $pArgs['CFToken'] = Get-PSCMSecret -Name 'Cloudflare.Token' -AsPlainText
    }
    elseif ($dnsPlugin -eq 'Route53') {
        $pArgs['R53AccessKey'] = Get-PSCMSecret -Name 'Route53.AccessKey' -AsPlainText
        $pArgs['R53SecretKey'] = Get-PSCMSecret -Name 'Route53.SecretKey' -AsPlainText
    }
    elseif ($dnsPlugin -eq 'GoDaddy') {
        $pArgs['GDKey']    = Get-PSCMSecret -Name 'GoDaddy.Key' -AsPlainText
        $pArgs['GDSecret'] = Get-PSCMSecret -Name 'GoDaddy.Secret' -AsPlainText
    }
    
    $params['PluginArgs'] = $pArgs
    
    $cert = $provider.NewCertificate($params)
    Write-PSCMLog -Level INFO -Message ('ACME sertifika basariyla alindi: ' + $Domain[0]) -Source 'ACME'
    return $cert
}
