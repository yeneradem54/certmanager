<#
.SYNOPSIS
PS-CertManager uygulamasını kişisel verilerden (veritabanı, loglar, sertifikalar, ayarlar) arındırarak 
başkalarıyla paylaşılabilecek temiz bir ZIP sürümü haline getirir.
#>

$ErrorActionPreference = 'Stop'

Write-Host "=========================================" -ForegroundColor Cyan
Write-Host " PS-CertManager Temiz Sürüm Paketleyici  " -ForegroundColor Cyan
Write-Host "=========================================" -ForegroundColor Cyan
Write-Host ""

# Not: $PSScriptRoot PowerShell otomatik değişkenidir, üzerine yazılmamalıdır.
# Doğrudan çalıştırma (F5 / .\Build-Release.ps1) ve ISE uyumluluğu:
$ScriptRoot = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$DesktopPath = [Environment]::GetFolderPath('Desktop')

# Versiyonu manifest dosyasından dinamik olarak oku
$manifestPath = Join-Path $ScriptRoot 'Modules\PSCertManager\PSCertManager.psd1'
if (-not (Test-Path $manifestPath)) {
    Write-Host "[HATA] Modül manifest dosyası bulunamadı: $manifestPath" -ForegroundColor Red
    Write-Host "       Script'in proje kök dizininde olduğundan emin olun." -ForegroundColor Red
    return
}
$manifestData = Import-PowerShellDataFile -Path $manifestPath
$version = $manifestData.ModuleVersion

Write-Host "   Sürüm   : v$version" -ForegroundColor Gray
Write-Host "   Kaynak   : $ScriptRoot" -ForegroundColor Gray
Write-Host ""

$ReleaseZipPath = Join-Path $DesktopPath "PS-CertManager_v${version}_CleanRelease.zip"

# Staging (Hazırlık) dizinini oluştur
$StagingDir = Join-Path $env:TEMP "PSCM_Staging"
if (Test-Path $StagingDir) {
    Remove-Item -Path $StagingDir -Recurse -Force
}
New-Item -ItemType Directory -Path $StagingDir -Force | Out-Null

Write-Host "-> 1. Kaynak dosyalar hazirlik alanina kopyalaniyor..." -ForegroundColor Yellow
Copy-Item -Path "$ScriptRoot\*" -Destination $StagingDir -Recurse -Force

Write-Host "-> 2. Kisisel veriler ve loglar temizleniyor..." -ForegroundColor Yellow

# Temizlenecek klasörlerin içini boşalt
$foldersToClean = @(
    "Logs",
    "Temp",
    "Certificates\Current",
    "Certificates\Archive",
    "Config\State"
)

foreach ($folder in $foldersToClean) {
    $targetFolder = Join-Path $StagingDir $folder
    if (Test-Path $targetFolder) {
        Remove-Item -Path "$targetFolder\*" -Recurse -Force -ErrorAction SilentlyContinue
    }
}

# Gerekli boş klasör hiyerarşisini (Özellikle Action Queue için) yeniden kur
$requiredFolders = @(
    "Logs",
    "Temp",
    "Certificates\Current",
    "Certificates\Archive",
    "Config\State\actions\pending",
    "Config\State\actions\processed",
    "Config\State\actions\failed"
)

foreach ($folder in $requiredFolders) {
    $targetFolder = Join-Path $StagingDir $folder
    if (-not (Test-Path $targetFolder)) {
        New-Item -ItemType Directory -Path $targetFolder -Force | Out-Null
    }
}

# Settings.json dosyasını şablona çevir (kişisel bilgiler çıkarılır)
$settingsPath = Join-Path $StagingDir "Config\settings.json"
if (Test-Path $settingsPath) {
    Remove-Item -Path $settingsPath -Force
}

# .bak dosyalarını temizle (örn: Deployments.json.bak)
Get-ChildItem -Path (Join-Path $StagingDir "Config") -Filter "*.bak" -ErrorAction SilentlyContinue | Remove-Item -Force

$exampleSettings = @"
{
    "Version": "$version",
    "General": { "IsConfigured": false },
    "Azure": {
        "TenantId": "",
        "SubscriptionId": "",
        "ResourceGroup": "",
        "DnsZone": "",
        "AuthMode": "Interactive",
        "ClientId": ""
    },
    "Acme": {
        "Provider": "LetsEncrypt",
        "DnsPlugin": "",
        "AccountEmail": "",
        "KeyLength": "2048",
        "ChallengeType": "dns-01",
        "Client": "Posh-ACME"
    },
    "Certificate": {
        "DefaultExportFormat": "pfx",
        "RenewalThresholdDay": 30,
        "AutoRenew": true
    },
    "Notification": {
        "Enabled": false,
        "Smtp": {
            "Server": "",
            "Port": 587,
            "UseTls": true,
            "From": "",
            "To": [],
            "Username": ""
        },
        "Teams": { "Enabled": false, "WebhookRef": "Teams.WebhookUrl" }
    },
    "Logging": {
        "MinimumLevel": "INFO",
        "MaxSizeMB": 10,
        "RetentionDays": 90
    },
    "Paths": {
        "OutputFolder": "Certificates\\Current",
        "ArchiveFolder": "Certificates\\Archive"
    },
    "Deployment": {},
    "Defaults": {
        "Provider": "ACME",
        "TemplateName": "WebServer",
        "StoreName": "WebHosting"
    }
}
"@
Set-Content -Path (Join-Path $StagingDir "Config\Settings.example.json") -Value $exampleSettings -Encoding UTF8

# Gizli/geliştirici dosya ve dizinleri temizle
$dirsToRemove = @(
    ".git",
    ".history",
    ".gemini",
    ".vscode"
)
foreach ($dir in $dirsToRemove) {
    $targetDir = Join-Path $StagingDir $dir
    if (Test-Path $targetDir) { Remove-Item -Path $targetDir -Recurse -Force }
}

# Release paketine dahil edilmemesi gereken geliştirici dosyalarını temizle
$filesToRemove = @(
    "AI-REBUILD-PROMPT.md",
    "PROJECT-INDEX.md",
    "Build-Release - Kopya.ps1"
)
foreach ($file in $filesToRemove) {
    $targetFile = Join-Path $StagingDir $file
    if (Test-Path $targetFile) { Remove-Item -Path $targetFile -Force }
}

# Pester test kalıntılarını temizle
$testResultFile = Join-Path $StagingDir "Tests\TestResults.xml"
if (Test-Path $testResultFile) { Remove-Item -Path $testResultFile -Force }

# Eğer staging içinde ZIP dosyası kopyalanmışsa (yanlışlıkla), sil
Get-ChildItem -Path $StagingDir -Filter "*.zip" | Remove-Item -Force

Write-Host "-> 3. ZIP paketi olusturuluyor ($ReleaseZipPath)..." -ForegroundColor Yellow
if (Test-Path $ReleaseZipPath) {
    Remove-Item -Path $ReleaseZipPath -Force
}

# PowerShell Compress-Archive kullanarak Sıkıştır
Compress-Archive -Path "$StagingDir\*" -DestinationPath $ReleaseZipPath -Force

Write-Host "-> 4. Gecici hazirlik dizini siliniyor..." -ForegroundColor Yellow
Remove-Item -Path $StagingDir -Recurse -Force

# ZIP doğrulaması
if (Test-Path $ReleaseZipPath) {
    $zipSize = (Get-Item $ReleaseZipPath).Length
    $zipSizeMB = [math]::Round($zipSize / 1MB, 2)
    Write-Host ""
    Write-Host "[ OK ] Basarili! Temiz surum ZIP dosyasi masaustunuzde hazir:" -ForegroundColor Green
    Write-Host "       $ReleaseZipPath" -ForegroundColor White
    Write-Host "       Boyut: $zipSizeMB MB" -ForegroundColor Gray
} else {
    Write-Host ""
    Write-Host "[ HATA ] ZIP dosyasi olusturulamadi!" -ForegroundColor Red
}
Write-Host ""
