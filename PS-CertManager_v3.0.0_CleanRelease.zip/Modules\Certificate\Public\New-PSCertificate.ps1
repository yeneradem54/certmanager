function New-PSCertificate {
<#
.SYNOPSIS
Yeni ACME sertifikasi olusturur ve metadata kaydeder (v2.1 helper tabanli).
#>
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][string]$Domain,
        [switch]$Wildcard,
        [Parameter(Mandatory=$false)][System.Security.SecureString]$PfxPass,
        [string]$FriendlyName,
        [string[]]$SANList,
        [ValidateSet('ACME','LocalCA')][string]$Provider = 'ACME',
        [string]$TemplateName = 'WebServer'
    )
    $lock = $null
    $lockName = 'cert-' + ($Domain -replace '[^a-zA-Z0-9]','_')
    try {
        $lock = Lock-PSCMResource -Name $lockName
        $realDomain = if ($Wildcard) { '*.' + ($Domain -replace '^\*\.','') } else { $Domain }
        Write-PSCMLog -Level INFO -Message ('Yeni sertifika istegi: ' + $realDomain) -Source 'Certificate'
        if (-not $PSCmdlet.ShouldProcess($realDomain,'ACME sertifika olustur')) { return }
        
        $realPfxPass = $PfxPass
        if (-not $realPfxPass) {
            $realPfxPass = Get-PSCMSecret -Name 'Certificate.DefaultPfxPassword'
            if (-not $realPfxPass) {
                throw (New-PSCMException -Message 'PFX parolasi belirtilmedi ve varsayilan bir PFX parolasi da bulunamadi.' -Category 'Dogrulama' -ErrorCode 'PSCM-4015')
            }
        }
        
        $acmeDomains = @($realDomain)
        if ($SANList) {
            foreach ($san in $SANList) {
                $cleanSan = $san.Trim()
                if ($cleanSan -and $cleanSan -ne $realDomain) { $acmeDomains += $cleanSan }
            }
        }
        
        $safeName = ($realDomain -replace '\*','wildcard') -replace '[^a-zA-Z0-9\.\-_]','_'
        $target = Join-Path (Get-PSCMPath -Name Current) $safeName
        
        $meta = $null
        $friendly = if ($FriendlyName) { $FriendlyName } else { $realDomain }
        
        if ($Provider -eq 'ACME') {
            Write-PSCMLog -Level INFO -Message ("ACME sunucusu (Let's Encrypt) baglantisi test ediliyor...") -Source 'Certificate'
            $netCheck = Test-NetConnection -ComputerName "acme-v02.api.letsencrypt.org" -Port 443 -WarningAction SilentlyContinue
            if (-not $netCheck.TcpTestSucceeded) {
                throw (New-PSCMException -Message "Internet baglantiniz koptu veya Let's Encrypt sunucularina erisim saglanamiyor." -Category 'Network' -ErrorCode 'PSCM-5000')
            }

            $result = New-PSCMAcmeCertificate -Domain $acmeDomains -PfxPass $realPfxPass
            if (-not $result) {
                throw (New-PSCMException -Message 'Posh-ACME bos sonuc dondu.' -Category 'ACME' -ErrorCode 'PSCM-1020')
            }
            
            $copyRes = Copy-PSCMPoshAcmeOutput -AcmeResult $result -Domain $realDomain -Destination $target
            Write-PSCMLog -Level INFO -Message ('Kopyalanan dosya: ' + $copyRes.CopiedCount + ' / ' + $copyRes.TotalCount) -Source 'Certificate'
            
            $meta = [PSCustomObject]@{
                Domain=$realDomain; Wildcard=[bool]$Wildcard
                Issuer=$copyRes.Issuer; Thumbprint=$copyRes.Thumbprint
                NotBefore=$copyRes.NotBefore; NotAfter=$copyRes.NotAfter
                FriendlyName=$friendly; Path=$target
                SourceFolder=$copyRes.SourceFolder; CreatedAt=(Get-Date).ToString('o')
                Provider=$Provider
                SANList=($acmeDomains -join ',')
            }
        } else {
            # LocalCA provider
            $result = Invoke-PSCMLocalCACertificateRequest -Domain $realDomain -PfxPass $realPfxPass -TemplateName $TemplateName -FriendlyName $friendly -SANList $SANList
            
            if (-not (Test-Path $target)) { New-Item -ItemType Directory -Path $target -Force | Out-Null }
            $destPfx = Join-Path $target "$realDomain.pfx"
            Copy-Item -Path $result.PfxTempPath -Destination $destPfx -Force
            Remove-Item -Path $result.PfxTempPath -Force -ErrorAction SilentlyContinue
            
            Write-PSCMLog -Level INFO -Message ('Sertifika kopyalandi: ' + $destPfx) -Source 'Certificate'
            
            $meta = [PSCustomObject]@{
                Domain=$realDomain; Wildcard=[bool]$Wildcard
                Issuer=$result.Issuer; Thumbprint=$result.Thumbprint
                NotBefore=$result.NotBefore; NotAfter=$result.NotAfter
                FriendlyName=$friendly; Path=$target
                SourceFolder=$target; CreatedAt=(Get-Date).ToString('o')
                Provider=$Provider
                SANList=($acmeDomains -join ',')
            }
        }
        $meta | Write-PSCMJson -Path (Join-Path $target 'metadata.json')
        $data = Get-PSCMState -Table 'certificates'
        $list = @($data | Where-Object { $_.Domain -ne $realDomain })
        $list += $meta
        Set-PSCMState -Table 'certificates' -Data $list
        Write-PSCMLog -Level INFO -Message ('Sertifika kayit edildi: ' + $realDomain) -Source 'Certificate'
        
        try {
            $deploys = @(Get-PSCMDeploymentConfig -Domain $realDomain)
            if ($deploys.Count -gt 0) {
                Write-PSCMLog -Level INFO -Message ("$realDomain icin $($deploys.Count) adet deploy gorevi kuyruga ekleniyor.") -Source 'Certificate'
                $pfxFiles = @(Get-ChildItem -Path $target -Filter '*.pfx' -File)
                if ($pfxFiles.Count -gt 0) {
                    $pfxPath = $pfxFiles[0].FullName
                    foreach ($d in $deploys) {
                        $pArgs = @{
                            PfxFilePath = $pfxPath
                            SiteName = $d.SiteName
                        }
                        $dProps = $d.psobject.Properties.Name
                        if ($dProps -contains 'HostHeader' -and $d.HostHeader) { $pArgs['HostHeader'] = $d.HostHeader }
                        if ($dProps -contains 'PfxPass' -and $d.PfxPass) { $pArgs['PfxPass'] = $d.PfxPass }
                        if ($dProps -contains 'ComputerName' -and $d.ComputerName) { $pArgs['ComputerName'] = $d.ComputerName }
                        if ($dProps -contains 'DeployUsername' -and $d.DeployUsername) { $pArgs['DeployUsername'] = $d.DeployUsername }
                        
                        Add-PSCMAction -Action 'deploy' -Domain $realDomain -Params $pArgs | Out-Null
                        Write-PSCMLog -Level INFO -Message ("Kuyruga deploy eklendi: $($d.SiteName)") -Source 'Certificate'
                    }
                } else {
                    Write-PSCMLog -Level WARNING -Message ("Deploy iptal edildi: PFX dosyasi bulunamadi ($target).") -Source 'Certificate'
                }
            }
        } catch {
            Write-PSCMLog -Level ERROR -Message ("Deploy kuyruga eklenirken hata: " + $_.Exception.Message) -Source 'Certificate'
        }
        
        return $meta
    } catch {
        Write-PSCMLog -Level ERROR -Message ('Sertifika olusturulamadi: ' + $_.Exception.Message) -Source 'Certificate'
        throw
    } finally {
        if ($lock) { Unlock-PSCMResource -Name $lockName }
    }
}
