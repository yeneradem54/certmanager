﻿function Initialize-PSCMAcmeProvider {
<#
.SYNOPSIS
ACME saglayici somut nesnesini olusturur (fabrika).
#>
    [CmdletBinding()]
    param()
    $s = Get-PSSettings -Section 'Acme'
    switch ($s.Provider) {
        'LetsEncrypt'        { return (New-Object PSCMPoshAcmeProvider('LetsEncrypt','LE_PROD')) }
        'LetsEncryptStaging' { return (New-Object PSCMPoshAcmeProvider('LetsEncryptStaging','LE_STAGE')) }
        default { throw (New-PSCMException -Message ("Desteklenmeyen ACME saglayici: " + $s.Provider) -Category 'ACME' -ErrorCode 'PSCM-1010') }
    }
}
