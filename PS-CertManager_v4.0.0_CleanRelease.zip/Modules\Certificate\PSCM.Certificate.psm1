#Requires -Version 5.1
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'
$script:PSCMCertIndex = 'certificates.json'
Get-ChildItem -Path (Join-Path $PSScriptRoot 'Public') -Filter '*.ps1' -EA SilentlyContinue | ForEach-Object { . $_.FullName }
Export-ModuleMember -Function @('Get-PSCertificate','New-PSCertificate','Update-PSCertificate','Remove-PSCertificate','Export-PSCertificate','Test-PSCertificate','Repair-PSCMCertificatePfx','Sync-PSCMCertificateCache')
