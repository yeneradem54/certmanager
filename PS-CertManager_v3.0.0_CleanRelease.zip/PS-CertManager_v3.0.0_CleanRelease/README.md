# PS-CertManager v3.0.0

PS-CertManager, çoklu domain yapıları için tasarlanmış kurumsal seviyede bir **Sertifika Yaşam Döngüsü Yönetim (Certificate Lifecycle Management - CLM)** sistemidir. v3.0 sürümüyle birlikte PowerShell konsol bağımlılığından sıyrılarak modern bir web arayüzüne ve güçlü bir arka plan işlem mimarisine kavuşmuştur.

---

## 🌟 Neler Yeni (v3.0.0 Özellikleri)

1. **SPA Web Dashboard (Canlı Yönetim):**
   - Sertifikalarınızı listeleyebileceğiniz, durumlarını (kalan süre, zincir sağlığı vs.) anlık takip edebileceğiniz interaktif web arayüzü.
   - PFX parolası sıfırlama, arşive taşıma, sertifika testi ve yeni Wildcard sertifika üretimlerini tamamen web üzerinden yapabilme imkanı.
2. **Action Queue (İşlem Kuyruğu) Mimarisi:**
   - Web arayüzünden verdiğiniz komutlar (yenileme, silme vb.) anında PowerShell oturumunu kilitlemek yerine güvenli bir işlem kuyruğuna (Pending) yazılır. Arka planda sessizce işlenerek sonuç (Processed/Failed) olarak döndürülür.
3. **Enterprise Altyapı (SQLite & EventLog):**
   - Sertifika State verileri, yüksek performanslı **SQLite Transaction** mimarisiyle saklanır. Hatalar eşzamanlı olarak yerel `Logs` klasörüne ve Windows **Event Log** (Application) üzerine yazılır.
4. **Otomatik IIS Dağıtımı (Automated Deployments):**
   - Yenilenen veya yeni alınan sertifikalar, hedeflediğiniz (Local veya Uzak) Windows IIS sunucularına otomatik olarak gönderilir, PFX parolaları Vault'tan çözülür ve IIS binding işlemleri otonom bir şekilde tamamlanır.
5. **Network Resilience (Bağlantı Kalkanı):**
   - ACME sunucularına (Let's Encrypt) bağlanmadan önce bağlantı testleri yapılarak olası kilitlenmelerin (Cascade Failure) önüne geçilir.
6. **Rest API & Mikroservis Altyapısı:**
   - Sistem durumunu, logları ve görev zamanlayıcısını (Task Scheduler) sunan mikro REST API uç noktaları.

---

## 🚀 Hızlı Başlangıç (Kurulum)

Sistemi kullanmaya başlamak için hiçbir kurulum yapmanıza gerek yoktur (Portable mimari).

1. Proje klasöründeki `Manager-Start.ps1` dosyasına sağ tıklayıp **"PowerShell ile Çalıştır"** diyebilirsiniz.
   *(Sistem Yönetici yetkilerine ihtiyaç duyar, eğer standart kullanıcıyla açarsanız yetki isteyerek kendini yeniden başlatır.)*
2. **İlk Kurulum (First-Run):** Uygulama yeni bir bilgisayarda ilk kez açıldığında eksik modülleri (`Posh-ACME`, `Az.Dns`, `ThreadJob`, `SecretStore`) otomatik olarak kurar ve sizi **Kurulum Sihirbazı**na yönlendirir.
3. Sihirbaz ekranında sizden PFX dosyalarınız için varsayılan bir şifre belirlemenizi ve Azure (DNS-01 doğrulaması için) bağlantısı yapmanızı ister. 
4. Kurulum bittiğinde, **Ana Menüye** ulaşacaksınız.

---

## 💻 Kullanım (Ana Menü)

Sistemi başlattığınızda sizi sade ve kurumsal bir terminal menüsü karşılar:

1. **Canli Web Dashboard & API Baslat:**
   - Arka planda `http://localhost:8080` adresinde çalışan API ve web sunucusunu ayağa kaldırır. Bu aşamadan sonra tüm işlemlerinizi (Yenileme, Ekleme, Silme) web tarayıcınızdan yapabilirsiniz. Sunucu çalışırken terminal log akışını izleyebilirsiniz.
2. **Sertifika Operasyonlari:**
   - Eğer işlemleri konsol üzerinden yapmak isterseniz, klasik sertifika oluşturma ve listeleme menülerini açar.
3. **Otomasyon (Görev Zamanlayıcı):**
   - Windows Task Scheduler'a otomatik bir arka plan görevi (AutoRenew) kaydeder. Sistem haftada/günde bir arka planda uyanarak süresi 30 günün altına düşen sertifikaları otomatik yeniler.
4. **Sistem Ayarları & Güvenlik:**
   - Azure Tenant ayarlarınızı güncelleyebilir veya yerel cihazdaki Kasa (Vault) parolanızı değiştirebilirsiniz.
5. **Bakım & Loglar:**
   - Uygulamanın ürettiği hata kayıtlarını (Logs) okuyabilir, bağımlılıkları kontrol edebilir veya sistem genelinde **Otomatik E2E Test** suitini çalıştırabilirsiniz.

---

## 🔒 Güvenlik Notu
Uygulama hiçbir şekilde PFX şifrelerini veya Azure şifrelerinizi JSON/Metin dosyalarında saklamaz. Şifreler işletim sisteminize ait şifreli ve korumalı **Microsoft.PowerShell.SecretStore** (Kasa) altyapısında tutulur. Proje klasörünü kopyalayıp başka bir bilgisayara taşıdığınızda şifreleriniz kopyalanmaz.

*(c) 2026 PS-CertManager Ekibi*
