﻿@{
    RootModule = 'PSCM.AzureDNS.psm1'
    ModuleVersion = '2.3.0'
    GUID = '66666666-6666-6666-6666-666666666666'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager Azure DNS Modulu (multi-zone)'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Connect-PSCMAzure','Test-PSAzure','Get-PSCMDnsZone','Find-PSCMDnsZone','Add-PSCMDnsZone','Get-PSCMDnsZones','Remove-PSCMDnsZone')
}
