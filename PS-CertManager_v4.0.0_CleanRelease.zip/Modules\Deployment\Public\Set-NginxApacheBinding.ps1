function Set-NginxApacheBinding {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Domain,
        [Parameter(Mandatory=$true)][string]$PfxFilePath,
        [Parameter(Mandatory=$true)][securestring]$PfxPassword,
        [Parameter(Mandatory=$true)][string]$ServerType,  # 'Nginx' veya 'Apache'
        [Parameter(Mandatory=$true)][string]$CertOutPath, # Ornek: C:\nginx\conf\ssl\domain.crt
        [Parameter(Mandatory=$true)][string]$KeyOutPath,  # Ornek: C:\nginx\conf\ssl\domain.key
        [Parameter(Mandatory=$true)][string]$ServiceName  # Ornek: 'nginx'
    )

    Write-DeployLog -Level INFO -Message "$ServerType ($ServiceName) icin dagitim baslatiliyor: $Domain"

    try {
        if (-not (Test-Path $PfxFilePath)) {
            throw "PFX dosyasi bulunamadi: $PfxFilePath"
        }

        Write-DeployLog -Level INFO -Message "Sertifika ve Private Key disari aktariliyor (.pem)..."
        
        # SSLTools modulu kullanilarak PFX'ten .crt ve .key olusturma islemi
        # Oncelikle gecici bir klasore PFX icerigindeki her seyi cikar
        $tempDir = Join-Path $env:TEMP ([guid]::NewGuid().ToString())
        New-Item -ItemType Directory -Path $tempDir | Out-Null
        
        $tempCert = Join-Path $tempDir 'cert.crt'
        $tempKey  = Join-Path $tempDir 'private.key'

        # .NET ile PFX oku ve ayristir (Ya da openssl/certutil var sayiyorsak kullanabiliriz)
        # Windows ortaminda PFX icinden private key'i duz metin olarak (openssl olmadan) cikarmak karmasiktir.
        # En pratik yol: Export-PSCMSslPrivateKey fonksiyonumuzu kullanmak!
        Export-PSCMSslPrivateKey -PfxPath $PfxFilePath -PfxPassword $PfxPassword -OutPath $tempKey -NoPassword | Out-Null
        
        # Sertifikayi da .crt formatinda cikar
        $certObj = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($PfxFilePath, $PfxPassword, [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable)
        $certBytes = $certObj.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Cert)
        $b64 = [Convert]::ToBase64String($certBytes, [System.Base64FormattingOptions]::InsertLineBreaks)
        $crtPem = "-----BEGIN CERTIFICATE-----`n$b64`n-----END CERTIFICATE-----"
        [System.IO.File]::WriteAllText($tempCert, $crtPem, [System.Text.Encoding]::ASCII)
        
        # Dosyalari hedef dizinlere kopyala
        $certDir = Split-Path $CertOutPath
        $keyDir  = Split-Path $KeyOutPath
        if (-not (Test-Path $certDir)) { New-Item -ItemType Directory -Path $certDir -Force | Out-Null }
        if (-not (Test-Path $keyDir)) { New-Item -ItemType Directory -Path $keyDir -Force | Out-Null }

        Copy-Item -Path $tempCert -Destination $CertOutPath -Force
        Copy-Item -Path $tempKey -Destination $KeyOutPath -Force
        Write-DeployLog -Level INFO -Message "Dosyalar hedefe kopyalandi: $CertOutPath, $KeyOutPath"

        # Servisi yeniden baslat (Windows Servisi varsayiliyor)
        Write-DeployLog -Level INFO -Message "Servis yeniden baslatiliyor: $ServiceName"
        Restart-Service -Name $ServiceName -Force
        
        Write-DeployLog -Level INFO -Message "$ServerType dagitimi basariyla tamamlandi!"
    } catch {
        Write-DeployLog -Level ERROR -Message ("$ServerType dagitim hatasi: " + $_.Exception.Message)
        throw
    } finally {
        if ($tempDir -and (Test-Path $tempDir)) {
            Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}
