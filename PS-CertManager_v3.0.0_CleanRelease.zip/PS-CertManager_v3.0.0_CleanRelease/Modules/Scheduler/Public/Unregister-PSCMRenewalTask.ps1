﻿function Unregister-PSCMRenewalTask {
<#
.SYNOPSIS
PS-CertManager Task Scheduler gorevlerini kaldirir.
#>
    [CmdletBinding(SupportsShouldProcess)]
    param([switch]$IncludeActionQueue)
    if (-not (Test-PSCMAdmin)) {
        throw (New-PSCMException -Message 'Task Scheduler kaldirmak icin yonetici yetkisi gerekir.' -Category 'Guvenlik' -ErrorCode 'PSCM-5031')
    }
    if ($PSCmdlet.ShouldProcess($script:PSCMTaskName,'Task Scheduler gorevi kaldir')) {
        Unregister-ScheduledTask -TaskName $script:PSCMTaskName -TaskPath $script:PSCMTaskFolder -Confirm:$false -EA SilentlyContinue
        Write-PSCMLog -Level INFO -Message ('Task kaldirildi: ' + $script:PSCMTaskName) -Source 'Scheduler'
        if ($IncludeActionQueue) {
            Unregister-ScheduledTask -TaskName $script:PSCMQueueTaskName -TaskPath $script:PSCMTaskFolder -Confirm:$false -EA SilentlyContinue
            Write-PSCMLog -Level INFO -Message ('Task kaldirildi: ' + $script:PSCMQueueTaskName) -Source 'Scheduler'
        }
    }
}
