@{
    RootModule = 'PSCM.Testing.psm1'
    ModuleVersion = '1.0.0'
    GUID = '11111111-2222-3333-4444-555555555555'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager Testing Module'
    FunctionsToExport = @('Invoke-PSCMTestSuite')
}
