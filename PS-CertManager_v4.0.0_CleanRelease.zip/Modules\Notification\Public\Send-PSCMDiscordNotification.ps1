function Send-PSCMDiscordNotification {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Title,
        [Parameter(Mandatory)][string]$Message,
        [ValidateSet('Bilgi','Uyari','Hata','Basari')][string]$Level = 'Bilgi'
    )
    $s = Get-PSSettings -Section 'Notification'
    if (-not $s.Enabled -or [string]::IsNullOrWhiteSpace($s.DiscordWebhook)) { throw "Discord bildirimi pasif veya Webhook URL girilmemiş." }
    $webhook = $s.DiscordWebhook
    
    $color = switch ($Level) { 'Bilgi'{3447003} 'Uyari'{15909393} 'Hata'{13710136} 'Basari'{1103090} default{3447003} }
    
    $payload = @{
        embeds = @(
            @{
                title = $Title
                description = $Message
                color = $color
            }
        )
    }
    
    try {
        $json = $payload | ConvertTo-Json -Depth 5
        Invoke-RestMethod -Uri $webhook -Method Post -Body $json -ContentType 'application/json; charset=utf-8' -EA Stop | Out-Null
        Write-PSCMLog -Level INFO -Message ('Discord bildirimi basarili: ' + $Title) -Source 'Notification'
    } catch {
        Write-PSCMLog -Level ERROR -Message ('Discord bildirim hatasi: ' + $_.Exception.Message) -Source 'Notification'
        throw
    }
}
