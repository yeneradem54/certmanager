function Invoke-MenuDefaults {
    $run = $true
    while ($run) {
        Show-PSCMBanner
        Write-Host '  --- GLOBAL VARSAYILANLAR (DEFAULTS) ---' -ForegroundColor Yellow
        Write-Host ''
        
        $settingsPath = Join-Path (Get-PSCMPath -Name Config) 'settings.json'
        $obj = Read-PSCMJson -Path $settingsPath
        
        if ('Defaults' -notin $obj.PSObject.Properties.Name) {
            $obj | Add-Member -NotePropertyName 'Defaults' -NotePropertyValue ([ordered]@{ Provider='ACME'; TemplateName='WebServer'; StoreName='WebHosting' })
            $obj | Write-PSCMJson -Path $settingsPath
        }
        
        $def = $obj.Defaults
        
        Write-Host "  Mevcut Varsayilan Ayarlar:" -ForegroundColor Cyan
        Write-Host ("  [1] Sertifika Saglayicisi (Provider)   : " + $def.Provider) -ForegroundColor White
        Write-Host ("  [2] Local CA Sablon Adi (TemplateName): " + $def.TemplateName) -ForegroundColor White
        Write-Host ("  [3] IIS Sertifika Magazasi (StoreName): " + $def.StoreName) -ForegroundColor White
        Write-Host ''
        Write-Host '  Enter) Ana Menuye Don' -ForegroundColor DarkGray
        Write-Host ''
        
        $choice = Read-Host 'Degistirmek istediginiz ayarin numarasini secin'
        
        $changed = $false
        switch ($choice) {
            '1' {
                Write-Host ''
                $newProv = Read-Host "Yeni Saglayici (ACME veya LocalCA) [Varsayilan: $($def.Provider)]"
                if ($newProv -and ($newProv -eq 'ACME' -or $newProv -eq 'LocalCA')) {
                    $def.Provider = $newProv
                    $changed = $true
                    Write-Host 'Guncellendi.' -ForegroundColor Green
                } elseif ($newProv) {
                    Write-Host 'Gecersiz saglayici! Sadece ACME veya LocalCA yazabilirsiniz.' -ForegroundColor Red
                }
            }
            '2' {
                Write-Host ''
                $newTmp = Read-Host "Yeni Local CA Sablon Adi [Varsayilan: $($def.TemplateName)]"
                if ($newTmp) {
                    $def.TemplateName = $newTmp.Trim()
                    $changed = $true
                    Write-Host 'Guncellendi.' -ForegroundColor Green
                }
            }
            '3' {
                Write-Host ''
                $newStore = Read-Host "Yeni IIS Magaza Adi (Orn: My, WebHosting) [Varsayilan: $($def.StoreName)]"
                if ($newStore) {
                    $def.StoreName = $newStore.Trim()
                    $changed = $true
                    Write-Host 'Guncellendi.' -ForegroundColor Green
                }
            }
            '' {
                $run = $false
            }
        }
        
        if ($changed) {
            $obj | Write-PSCMJson -Path $settingsPath
            Pause-PSCM
        }
    }
}
