#Requires -Version 5.1
$ErrorActionPreference = 'Stop'

$pub = Join-Path $PSScriptRoot 'IISDeployment.psm1'
$rem = Join-Path $PSScriptRoot 'Invoke-RemoteDeployment.psm1'
$cfg = Join-Path $PSScriptRoot 'Get-PSCMDeploymentConfig.psm1'
$bind = Join-Path $PSScriptRoot 'Get-PSCMIISBinding.psm1'

Import-Module $pub -Force -ErrorAction Stop
Import-Module $rem -Force -ErrorAction Stop
Import-Module $cfg -Force -ErrorAction Stop
Import-Module $bind -Force -ErrorAction Stop

Export-ModuleMember -Function Install-CertificateToStore, Set-IISCertificateBinding, Invoke-RemoteIISDeployment, Get-PSCMDeploymentConfig, Get-PSCMIISBinding
