function Invoke-PSCMLocalCACertificateRequest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Domain,
        [Parameter(Mandatory=$false)][System.Security.SecureString]$PfxPass,
        [string]$TemplateName = 'WebServer',
        [string]$FriendlyName,
        [string[]]$SANList,
        [string]$CsrPath
    )
    
    # Temp dosya yolları finally'de temizlenebilmesi için dışarıda tanımlanıyor
    $cerTempPath = $null
    $pfxTempPath = $null

    try {
        if ($CsrPath) {
            Write-PSCMLog -Level INFO -Message "Local CA (ADCS) uzerinden CSR ile sertifika talep ediliyor: $CsrPath (Template: $TemplateName)" -Source 'LocalCA'
            if (-not (Test-Path $CsrPath)) { throw "CSR dosyasi bulunamadi: $CsrPath" }
            
            $cerTempPath = Join-Path $env:TEMP "$([guid]::NewGuid()).cer"
            $argsList = "-submit -attrib `"CertificateTemplate:$TemplateName`" `"$CsrPath`" `"$cerTempPath`""
            Write-PSCMLog -Level INFO -Message "certreq args: $argsList" -Source 'LocalCA'
            
            $p = Start-Process -FilePath "certreq.exe" -ArgumentList $argsList -Wait -NoNewWindow -PassThru
            if ($p.ExitCode -ne 0 -or -not (Test-Path $cerTempPath)) {
                throw "certreq basarisiz oldu veya sertifika dosyasi olusmadi. Cikis kodu: $($p.ExitCode)"
            }
            
            $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($cerTempPath)
            Write-PSCMLog -Level INFO -Message "Sertifika alindi, Thumbprint: $($cert.Thumbprint)" -Source 'LocalCA'
            
            return [PSCustomObject]@{
                Thumbprint  = $cert.Thumbprint
                NotBefore   = $cert.NotBefore.ToString('o')
                NotAfter    = $cert.NotAfter.ToString('o')
                Issuer      = $cert.Issuer
                CerTempPath = $cerTempPath
            }
        } else {
            Write-PSCMLog -Level INFO -Message "Local CA (ADCS) uzerinden otomatik sertifika talep ediliyor: $Domain (Template: $TemplateName)" -Source 'LocalCA'
            
            $dnsEntries = @()
            $ipEntries = @()
            
            # Ana domain ayrıştırılıyor
            if ($Domain -as [ipaddress]) { $ipEntries += $Domain } else { $dnsEntries += $Domain }
            
            if ($SANList) {
                foreach ($san in $SANList) {
                    $cleanSan = $san.Trim()
                    if ($cleanSan) {
                        if ($cleanSan -as [ipaddress]) {
                            if ($cleanSan -notin $ipEntries) { $ipEntries += $cleanSan }
                        } else {
                            if ($cleanSan -notin $dnsEntries) { $dnsEntries += $cleanSan }
                        }
                    }
                }
            }

            # Eğer SAN listesinde IP adresi varsa, Get-Certificate IP desteklemediği için certreq.exe kullanıyoruz
            if ($ipEntries.Count -gt 0) {
                Write-PSCMLog -Level INFO -Message "SAN listesinde IP adresi tespit edildi. certreq.exe ve INF sablonu kullaniliyor." -Source 'LocalCA'
                
                $infPath = Join-Path $env:TEMP "$([guid]::NewGuid()).inf"
                $csrTempPath = Join-Path $env:TEMP "$([guid]::NewGuid()).csr"
                $cerTempPath = Join-Path $env:TEMP "$([guid]::NewGuid()).cer"
                $pfxTempPath = Join-Path $env:TEMP "$([guid]::NewGuid()).pfx"
                
                # SAN satırları oluşturuluyor
                $sanLines = @()
                $sanLines += '2.5.29.17 = "{text}"'
                
                # DNS entries
                for ($i = 0; $i -lt $dnsEntries.Count; $i++) {
                    $val = "DNS=" + $dnsEntries[$i]
                    if ($i -lt ($dnsEntries.Count -1) -or $ipEntries.Count -gt 0) {
                        $val += "&"
                    }
                    $sanLines += "_continue_ = `"$val`""
                }
                
                # IP entries
                for ($j = 0; $j -lt $ipEntries.Count; $j++) {
                    $val = "IPAddress=" + $ipEntries[$j]
                    if ($j -lt ($ipEntries.Count -1)) {
                        $val += "&"
                    }
                    $sanLines += "_continue_ = `"$val`""
                }
                
                $sanBlock = $sanLines -join "`r`n"

                $infContent = @"
[Version]
Signature="`$Windows NT`$"

[NewRequest]
Subject = "CN=$Domain"
KeyLength = 2048
HashAlgorithm = SHA256
Exportable = TRUE
MachineKeySet = TRUE
PrivateKeyArchive = FALSE
RequestType = PKCS10
ProviderName = "Microsoft RSA SChannel Cryptographic Provider"
ProviderType = 12
KeyUsage = 0xa0

[Extensions]
$sanBlock
"@
                try {
                    # certreq.exe UTF8 BOM dosyalarda hata verir. Bu yuzden ASCII olarak yaziyoruz.
                    Set-Content -Path $infPath -Value $infContent -Encoding Ascii -Force
                    
                    # 1. CSR oluştur
                    $argsNew = "-new `"$infPath`" `"$csrTempPath`""
                    $pNew = Start-Process -FilePath "certreq.exe" -ArgumentList $argsNew -Wait -NoNewWindow -PassThru
                    if ($pNew.ExitCode -ne 0 -or -not (Test-Path $csrTempPath)) {
                        throw "certreq -new basarisiz oldu. Cikis kodu: $($pNew.ExitCode)"
                    }

                    # 2. CA'e Gönder (CA secim penceresini engellemek icin active directory CA bilgisini otomatik alip -config ile veriyoruz)
                    $caConfig = $null
                    try {
                        # Active Directory uzerindeki kayitli CA sunucularini listele ve ilkini al
                        $rootDse = New-Object System.DirectoryServices.DirectoryEntry("LDAP://RootDSE")
                        $configContext = $rootDse.Properties["configurationNamingContext"].Value
                        $caSearcher = New-Object System.DirectoryServices.DirectorySearcher(
                            [System.DirectoryServices.DirectoryEntry]"LDAP://CN=Enrollment Services,CN=Public Key Services,CN=Services,$configContext"
                        )
                        $caSearcher.Filter = "(objectClass=pKIEnrollmentService)"
                        $caResult = $caSearcher.FindOne()
                        if ($caResult) {
                            $caEntry = $caResult.GetDirectoryEntry()
                            $dnsName = $caEntry.Properties["dNSHostName"].Value
                            $caName = $caEntry.Properties["cn"].Value
                            $caConfig = "$dnsName\$caName"
                        }
                    } catch {
                        Write-PSCMLog -Level WARNING -Message "Active Directory CA sunucusu otomatik tespit edilemedi: $($_.Exception.Message)" -Source 'LocalCA'
                    }

                    $argsSubmit = @()
                    if ($caConfig) {
                        Write-PSCMLog -Level INFO -Message "Tespit edilen CA sunucusuna gonderiliyor: $caConfig" -Source 'LocalCA'
                        $argsSubmit = "-q -config `"$caConfig`" -submit -attrib `"CertificateTemplate:$TemplateName`" `"$csrTempPath`" `"$cerTempPath`""
                    } else {
                        # CA bulunamazsa sessiz modda varsayilani dene
                        $argsSubmit = "-q -submit -attrib `"CertificateTemplate:$TemplateName`" `"$csrTempPath`" `"$cerTempPath`""
                    }

                    $pSub = Start-Process -FilePath "certreq.exe" -ArgumentList $argsSubmit -Wait -NoNewWindow -PassThru
                    if ($pSub.ExitCode -ne 0 -or -not (Test-Path $cerTempPath)) {
                        throw "certreq -submit basarisiz oldu. Cikis kodu: $($pSub.ExitCode)"
                    }

                    # 3. Sertifikayı PFX olarak dışarı aktarmak için yerel depoya kabul et (Accept - LocalMachine için -machine eklendi)
                    $argsAccept = "-machine -accept `"$cerTempPath`""
                    Start-Process -FilePath "certreq.exe" -ArgumentList $argsAccept -Wait -NoNewWindow | Out-Null
                    
                    # Yerel (LocalMachine) deposundan sertifikayı bul (Yazma gecikmelerine karsi 20 saniye boyunca her saniye basi yeniden deneme)
                    $cert = $null
                    for ($retry = 1; $retry -le 20; $retry++) {
                        $cert = Get-ChildItem -Path "cert:\LocalMachine\My" | Where-Object { 
                            $_.Subject -match "CN=$Domain" -and $_.NotBefore -ge (Get-Date).AddMinutes(-10) 
                        } | Sort-Object NotBefore -Descending | Select-Object -First 1
                        
                        if ($cert) {
                            Write-PSCMLog -Level INFO -Message "Sertifika yerel depoda bulundu ($retry. saniyede)." -Source 'LocalCA'
                            break
                        }
                        Start-Sleep -Seconds 1
                    }
                    
                    if (-not $cert) {
                        throw "Sertifika yerel (LocalMachine) deposuna kabul edildi ancak 20 saniye icinde depoda bulunamadı."
                    }

                    Write-PSCMLog -Level INFO -Message "Sertifika alindi ve depoya kabul edildi. Thumbprint: $($cert.Thumbprint)" -Source 'LocalCA'
                    if ($FriendlyName) { $cert.FriendlyName = $FriendlyName } else { $cert.FriendlyName = $Domain }

                    # PFX ve CER aktarımı
                    Export-PfxCertificate -Cert $cert -FilePath $pfxTempPath -Password $PfxPass | Out-Null
                    
                    # CER dosyasını da temp klasörüne çıkartalım
                    $cerTempPathForReturn = Join-Path $env:TEMP "$([guid]::NewGuid()).cer"
                    $certBytes = $cert.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Cert)
                    [System.IO.File]::WriteAllBytes($cerTempPathForReturn, $certBytes)
                    
                    # Yerel depodan temizle
                    Remove-Item -Path "cert:\LocalMachine\My\$($cert.Thumbprint)" -Force -ErrorAction SilentlyContinue

                    return [PSCustomObject]@{
                        Thumbprint  = $cert.Thumbprint
                        NotBefore   = $cert.NotBefore.ToString('o')
                        NotAfter    = $cert.NotAfter.ToString('o')
                        Issuer      = $cert.Issuer
                        PfxTempPath = $pfxTempPath
                        CerTempPath = $cerTempPathForReturn
                    }
                } finally {
                    # Geçici certreq dosyalarını temizle
                    if ($infPath -and (Test-Path $infPath)) { Remove-Item $infPath -Force -EA SilentlyContinue }
                    if ($csrTempPath -and (Test-Path $csrTempPath)) { Remove-Item $csrTempPath -Force -EA SilentlyContinue }
                    if ($cerTempPath -and (Test-Path $cerTempPath)) { Remove-Item $cerTempPath -Force -EA SilentlyContinue }
                }
            } else {
                # Sadece DNS isimleri varsa klasik Get-Certificate ile devam et
                $reqArgs = @{
                    SubjectName         = "CN=$Domain"
                    DnsName             = $dnsEntries
                    CertStoreLocation   = 'cert:\LocalMachine\My'
                    Template            = $TemplateName
                }
                
                $certInfo = Get-Certificate @reqArgs
                $cert = $certInfo.Certificate
                
                if (-not $cert) {
                    throw "Get-Certificate basarili dondu fakat sertifika nesnesi bulunamadi."
                }
                
                Write-PSCMLog -Level INFO -Message "Sertifika alindi, Thumbprint: $($cert.Thumbprint)" -Source 'LocalCA'
                
                if ($FriendlyName) { $cert.FriendlyName = $FriendlyName } else { $cert.FriendlyName = $Domain }
                
                $pfxTempPath = Join-Path $env:TEMP "$([guid]::NewGuid()).pfx"
                $cerTempPathForReturn = Join-Path $env:TEMP "$([guid]::NewGuid()).cer"
                
                Write-PSCMLog -Level INFO -Message "Sertifika PFX ve CER olarak disari aktariliyor..." -Source 'LocalCA'
                Export-PfxCertificate -Cert $cert -FilePath $pfxTempPath -Password $PfxPass | Out-Null
                
                $certBytes = $cert.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Cert)
                [System.IO.File]::WriteAllBytes($cerTempPathForReturn, $certBytes)
                
                Remove-Item -Path "cert:\LocalMachine\My\$($cert.Thumbprint)" -Force -ErrorAction SilentlyContinue
                
                return [PSCustomObject]@{
                    Thumbprint  = $cert.Thumbprint
                    NotBefore   = $cert.NotBefore.ToString('o')
                    NotAfter    = $cert.NotAfter.ToString('o')
                    Issuer      = $cert.Issuer
                    PfxTempPath = $pfxTempPath
                    CerTempPath = $cerTempPathForReturn
                }
            }
        }
    } catch {
        Write-PSCMLog -Level ERROR -Message ("Local CA sertifika talebi basarisiz: " + $_.Exception.Message) -Source 'LocalCA'
        # Hata durumunda temp dosyaları temizle
        if ($cerTempPath) { Remove-Item -Path $cerTempPath -Force -ErrorAction SilentlyContinue }
        if ($pfxTempPath) { Remove-Item -Path $pfxTempPath -Force -ErrorAction SilentlyContinue }
        throw
    }
}

