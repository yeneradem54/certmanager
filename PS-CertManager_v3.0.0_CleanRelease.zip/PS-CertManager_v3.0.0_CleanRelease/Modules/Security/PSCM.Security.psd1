﻿@{
    RootModule = 'PSCM.Security.psm1'
    ModuleVersion = '2.2.2'
    GUID = '33333333-3333-3333-3333-333333333333'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager Guvenlik ve Secret Yonetim Modulu'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Initialize-PSCMSecretStore','Set-PSCMSecret','Get-PSCMSecret','Remove-PSCMSecret','Unlock-PSCMSecretStore','Set-PSCMSecretStorePolicy')
}
