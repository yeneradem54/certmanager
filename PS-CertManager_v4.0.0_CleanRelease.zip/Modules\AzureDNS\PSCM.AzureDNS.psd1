@{
    RootModule = 'PSCM.AzureDNS.psm1'
    ModuleVersion = '4.0.0'
    GUID = '6ac953b1-fa23-4f0d-9ac4-c4267db534d8'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager Azure DNS Modulu (multi-zone)'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Connect-PSCMAzure','Test-PSAzure','Get-PSCMDnsZone','Find-PSCMDnsZone','Add-PSCMDnsZone','Get-PSCMDnsZones','Remove-PSCMDnsZone')
}
