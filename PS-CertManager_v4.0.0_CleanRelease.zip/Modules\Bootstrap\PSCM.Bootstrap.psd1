@{
    RootModule = 'PSCM.Bootstrap.psm1'
    ModuleVersion = '4.0.0'
    GUID = 'ed2d7f64-ddc4-4ab2-b9c7-e03a9336c768'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager Altyapi Kontrol ve Kurulum Modulu'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Initialize-PSCertManager','Get-PSInfrastructure','Repair-PSInfrastructure','Start-PSCMConfigWizard')
}
