function Get-PSCMIISBinding {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$false)]
        [string]$ComputerName = "localhost",
        
        [Parameter(Mandatory=$false)]
        [pscredential]$Credential
    )

    try {
        $scriptBlock = {
            [Reflection.Assembly]::LoadWithPartialName("Microsoft.Web.Administration") | Out-Null
            $sm = New-Object Microsoft.Web.Administration.ServerManager
            $results = @()
            
            foreach ($site in $sm.Sites) {
                foreach ($binding in $site.Bindings) {
                    $results += [PSCustomObject]@{
                        SiteName   = $site.Name
                        SiteId     = $site.Id
                        Protocol   = $binding.Protocol
                        Port       = if ($binding.EndPoint) { $binding.EndPoint.Port } else { $binding.BindingInformation.Split(':')[1] }
                        HostHeader = $binding.Host
                        State      = $site.State
                    }
                }
            }
            return $results
        }
        
        if ($ComputerName -eq "localhost" -or $ComputerName -eq $env:COMPUTERNAME -or $ComputerName -eq "127.0.0.1") {
            Write-Verbose "Yerel IIS taranıyor..."
            $bindings = Invoke-Command -ScriptBlock $scriptBlock -ErrorAction Stop
            return $bindings
        } else {
            Write-Verbose "Uzak IIS ($ComputerName) taranıyor..."
            $sessionParams = @{ ComputerName = $ComputerName; ErrorAction = 'Stop' }
            if ($Credential) { $sessionParams.Add("Credential", $Credential) }
            
            $bindings = Invoke-Command @sessionParams -ScriptBlock $scriptBlock
            return $bindings
        }
    } catch {
        throw "IIS baglamalari alinirken hata: $_"
    }
}
