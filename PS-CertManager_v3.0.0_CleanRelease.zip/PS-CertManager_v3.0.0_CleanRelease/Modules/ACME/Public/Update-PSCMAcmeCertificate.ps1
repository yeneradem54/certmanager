﻿function Update-PSCMAcmeCertificate {
<#
.SYNOPSIS
Mevcut ACME sertifikasini yeniler.
#>
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Domain)
    Write-PSCMLog -Level INFO -Message ('ACME yenileme baslatildi: ' + $Domain) -Source 'ACME'
    $provider = Initialize-PSCMAcmeProvider
    return $provider.RenewCertificate(@{ Domain = $Domain })
}
