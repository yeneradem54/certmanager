function Invoke-MenuWizard {
    Show-PSCMBanner
    Write-Host '  --- KURULUM VE YAPILANDIRMA SIHIRBAZI ---' -ForegroundColor Yellow
    Write-Host ''
    try { Start-PSCMConfigWizard } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
    Pause-PSCM
}
