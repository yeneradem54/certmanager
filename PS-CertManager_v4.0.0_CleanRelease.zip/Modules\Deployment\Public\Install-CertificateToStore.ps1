function Install-CertificateToStore {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]$PfxFilePath,
        
        [Parameter(Mandatory=$true)]
        [securestring]$PfxPassword,
        
        [Parameter(Mandatory=$false)]
        [string]$StoreName = "WebHosting",
        
        [Parameter(Mandatory=$false)]
        [string]$StoreLocation = "LocalMachine"
    )
    
    try {
        if (-not (Test-Path $PfxFilePath)) {
            throw "PFX dosyasi bulunamadi: $PfxFilePath"
        }
        
        $store = New-Object System.Security.Cryptography.X509Certificates.X509Store($StoreName, $StoreLocation)
        $store.Open('ReadWrite')
        
        $flags = [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable -bor 
                 [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::MachineKeySet -bor 
                 [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::PersistKeySet
                 
        $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
        $cert.Import($PfxFilePath, $PfxPassword, $flags)
        
        $store.Add($cert)
        $store.Close()
        
        $certStore = if ($StoreLocation -eq 'LocalMachine') { 'machine' } else { 'user' }
        & certutil.exe -$certStore -repairstore $StoreName $($cert.Thumbprint) | Out-Null
        
        Write-DeployLog -Level INFO -Message "Sertifika basariyla Store'a eklendi. Thumbprint: $($cert.Thumbprint)"
        return $cert
    }
    catch {
        Write-DeployLog -Level ERROR -Message ("Sertifika Store'a yuklenirken hata olustu: " + $_.Exception.Message)
        throw
    }
}
