﻿function Get-PSDashboard {
<#
.SYNOPSIS
En son olusturulan dashboard HTML dosyasinin tam yolunu dondurur.
#>
    [CmdletBinding()]
    param()
    $dir = Get-PSCMPath -Name Dashboard
    $latest = Get-ChildItem -Path $dir -Filter 'dashboard*.html' -EA SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $latest) { return $null }
    return $latest.FullName
}
