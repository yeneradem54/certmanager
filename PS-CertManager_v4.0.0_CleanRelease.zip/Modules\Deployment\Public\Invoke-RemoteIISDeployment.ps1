function Invoke-RemoteIISDeployment {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]$ComputerName,
        
        [Parameter(Mandatory=$true)]
        [string]$PfxFilePath,
        
        [Parameter(Mandatory=$true)]
        [securestring]$PfxPassword,
        
        [Parameter(Mandatory=$true)]
        [string]$SiteName,
        
        [Parameter(Mandatory=$false)]
        [string]$HostHeader = "",
        
        [Parameter(Mandatory=$false)]
        [switch]$RequireSNI,

        [Parameter(Mandatory=$false)]
        [string]$StoreName = "WebHosting",

        [Parameter(Mandatory=$false)]
        [string]$StoreLocation = "LocalMachine",
        
        [Parameter(Mandatory=$false)]
        [pscredential]$Credential
    )

    try {
        Write-Verbose "Uzak sunucuya ($ComputerName) sertifika aktarimi basliyor..."
        
        # PFX dosyasinin uzak sunucuya aktarimi
        $remoteTempPath = "C:\Windows\Temp\$([guid]::NewGuid()).pfx"
        
        $sessionParams = @{
            ComputerName = $ComputerName
        }
        if ($Credential) {
            $sessionParams.Add("Credential", $Credential)
        }

        $session = New-PSSession @sessionParams
        
        Write-Verbose "Sertifika dosyasi sunucuya kopyalaniyor..."
        Copy-Item -Path $PfxFilePath -Destination $remoteTempPath -ToSession $session
        
        # Modul script blogunu uzak sunucuya gondermek uzere hazirla
        $deployModuleDir = if (Test-Path (Join-Path $PSScriptRoot "Install-CertificateToStore.ps1")) {
            Split-Path $PSScriptRoot -Parent
        } else {
            $PSScriptRoot
        }

        $scriptParts = [System.Collections.Generic.List[string]]::new()

        # 1. Write-DeployLog
        $logFile = Join-Path $deployModuleDir "Private\Write-DeployLog.ps1"
        if (Test-Path $logFile) {
            $scriptParts.Add((Get-Content -Path $logFile -Raw))
        } else {
            $scriptParts.Add(@'
function Write-DeployLog {
    param($Level, $Message)
    if (Get-Command Write-PSCMLog -ErrorAction SilentlyContinue) {
        Write-PSCMLog -Level $Level -Message $Message -Source 'Deployment'
    } else {
        if ($Level -eq 'ERROR') { Write-Error $Message }
        else { Write-Host "[$Level] $Message" }
    }
}
'@)
        }

        # 2. Install-CertificateToStore
        $installFile = Join-Path $deployModuleDir "Public\Install-CertificateToStore.ps1"
        if (Test-Path $installFile) {
            $scriptParts.Add((Get-Content -Path $installFile -Raw))
        } elseif (Get-Command Install-CertificateToStore -ErrorAction SilentlyContinue) {
            $scriptParts.Add("function Install-CertificateToStore { ${function:Install-CertificateToStore} }")
        }

        # 3. Set-IISCertificateBinding
        $bindFile = Join-Path $deployModuleDir "Public\Set-IISCertificateBinding.ps1"
        if (Test-Path $bindFile) {
            $scriptParts.Add((Get-Content -Path $bindFile -Raw))
        } elseif (Get-Command Set-IISCertificateBinding -ErrorAction SilentlyContinue) {
            $scriptParts.Add("function Set-IISCertificateBinding { ${function:Set-IISCertificateBinding} }")
        }

        $moduleScript = $scriptParts -join "`r`n`r`n"
        $moduleScript = $moduleScript -replace '(?mi)^Export-ModuleMember.*', ''
        
        $scriptBlock = {
            param ($pfxPath, $pfxPass, $siteName, $hostHdr, $reqSNI, $targetStore, $targetLoc, $modScript)
            
            # Uzak sunucuda modulu memory'de tanimla
            . ([scriptblock]::Create($modScript))
            
            # Fonksiyonlari cagir
            $cert = Install-CertificateToStore -PfxFilePath $pfxPath -PfxPassword $pfxPass -StoreName $targetStore -StoreLocation $targetLoc
            
            # SNI parametresini Boolean olarak guvenli sekilde geciyoruz (-Switch:$bool)
            Set-IISCertificateBinding -SiteName $siteName -Thumbprint $cert.Thumbprint -HostHeader $hostHdr -RequireSNI:$reqSNI
            
            # Gecici dosyayi sil
            Remove-Item -Path $pfxPath -Force -ErrorAction SilentlyContinue
            
            return $cert.Thumbprint
        }
        
        Write-Verbose "Uzak sunucuda islemler baslatiliyor..."
        $effectiveSNI = $RequireSNI.IsPresent
        if (-not $effectiveSNI -and -not [string]::IsNullOrWhiteSpace($HostHeader)) {
            $effectiveSNI = $true
        }

        $thumbprint = Invoke-Command -Session $session -ScriptBlock $scriptBlock -ArgumentList $remoteTempPath, $PfxPassword, $SiteName, $HostHeader, $effectiveSNI, $StoreName, $StoreLocation, $moduleScript
        
        Remove-PSSession -Session $session
        
        Write-Verbose "Uzak sunucu dagitimi basariyla tamamlandi. Thumbprint: $thumbprint"
        return $true
    }
    catch {
        Write-Error "Uzak sunucuya deployment sirasinda hata: $_"
        if ($session) { Remove-PSSession -Session $session }
        throw
    }
}
