function Export-PSCMSslKeystore {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$PfxPath,
        [Parameter(Mandatory=$true)][System.Security.SecureString]$PfxPass,
        [Parameter(Mandatory=$true)][string]$DestinationJks
    )
    
    $PfxPath = $PfxPath.Trim("`"").Trim("'").Trim()
    $DestinationJks = $DestinationJks.Trim("`"").Trim("'").Trim()
    
    if (-not (Test-Path -LiteralPath $PfxPath)) { throw "PFX dosyasi bulunamadi: $PfxPath" }
    
    # Validate the PFX password by trying to load it
    try {
        $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($PfxPath, $PfxPass)
        $cert.Dispose()
    } catch {
        throw "PFX sifresi dogrulanamadi veya dosya bozuk. Hata: $($_.Exception.Message)"
    }
    
    Write-PSCMLog -Level INFO -Message "Keystore (PKCS12) olusturuluyor: $DestinationJks" -Source 'SSLTools'
    
    try {
        # Check if destination directory exists
        $destDir = Split-Path -Parent $DestinationJks
        if ($destDir -and -not (Test-Path -LiteralPath $destDir)) {
            New-Item -ItemType Directory -Path $destDir -Force | Out-Null
        }
        
        # Copy-Item as PKCS12 Keystore
        Copy-Item -LiteralPath $PfxPath -Destination $DestinationJks -Force
        Write-PSCMLog -Level INFO -Message "PKCS12 formatli Keystore ($DestinationJks) basariyla olusturuldu." -Source 'SSLTools'
        return $DestinationJks
    } catch {
        throw "Keystore olusturulurken hata: $($_.Exception.Message)"
    }
}
