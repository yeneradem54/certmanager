﻿function Get-PSCMRenewalTask {
<#
.SYNOPSIS
Kayitli PS-CertManager gorevlerini listeler.
#>
    [CmdletBinding()]
    param()
    $tasks = @()
    foreach ($n in @($script:PSCMTaskName, $script:PSCMQueueTaskName)) {
        $t = Get-ScheduledTask -TaskName $n -TaskPath $script:PSCMTaskFolder -EA SilentlyContinue
        if ($t) {
            $info = Get-ScheduledTaskInfo -TaskName $n -TaskPath $script:PSCMTaskFolder -EA SilentlyContinue
            $tasks += [PSCustomObject]@{
                Name        = $n
                State       = [string]$t.State
                LastRunTime = if ($info) { $info.LastRunTime } else { $null }
                LastResult  = if ($info) { $info.LastTaskResult } else { $null }
                NextRunTime = if ($info) { $info.NextRunTime } else { $null }
                Description = [string]$t.Description
            }
        }
    }
    return $tasks
}
