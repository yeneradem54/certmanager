function Invoke-MenuNotifications {
    $run = $true
    while ($run) {
        Show-PSCMBanner
        Write-Host '  --- BILDIRIM (NOTIFICATION) KANALLARI ---' -ForegroundColor Yellow
        Write-Host ''
        
        $path = Join-Path (Get-PSCMPath -Name Config) 'settings.json'
        $obj = Read-PSCMJson -Path $path
        if (-not $obj.PSObject.Properties.Name -contains 'Notification' -or -not $obj.Notification) {
            $obj | Add-Member -NotePropertyName 'Notification' -NotePropertyValue ([PSCustomObject]@{
                Enabled = $false
                SlackWebhook = ''
                DiscordWebhook = ''
                Smtp = [PSCustomObject]@{ Server=''; Port=587; UseTls=$true; From=''; To=@(); Username='' }
                Teams = [PSCustomObject]@{ Enabled=$false; WebhookRef='Teams.WebhookUrl' }
            }) -Force
        }
        $n = $obj.Notification
        if ($n.PSObject.Properties.Name -notcontains 'SlackWebhook') { $n | Add-Member -NotePropertyName 'SlackWebhook' -NotePropertyValue '' -Force }
        if ($n.PSObject.Properties.Name -notcontains 'DiscordWebhook') { $n | Add-Member -NotePropertyName 'DiscordWebhook' -NotePropertyValue '' -Force }
        if ($n.PSObject.Properties.Name -notcontains 'Teams' -or -not $n.Teams) { $n | Add-Member -NotePropertyName 'Teams' -NotePropertyValue ([PSCustomObject]@{ Enabled=$false; WebhookRef='Teams.WebhookUrl' }) -Force }
        if ($n.PSObject.Properties.Name -notcontains 'Smtp' -or -not $n.Smtp) { $n | Add-Member -NotePropertyName 'Smtp' -NotePropertyValue ([PSCustomObject]@{ Server=''; Port=587; UseTls=$true; From=''; To=@(); Username='' }) -Force }
        
        Write-Host '  Mevcut Durum:' -ForegroundColor Cyan
        $teamsUrl = Get-PSCMSecret -Name 'Teams.WebhookUrl' -AsPlainText
        $teamsText = if ($teamsUrl -or ($n.Teams.PSObject.Properties.Name -contains 'Enabled' -and $n.Teams.Enabled)) { 'Ayarlanmis' } else { 'Yok' }
        $smtpText = if ($n.Smtp.PSObject.Properties.Name -contains 'Server' -and $n.Smtp.Server) { $n.Smtp.Server } else { 'Yok' }
        $slackText = if ($n.SlackWebhook) { 'Ayarlanmis' } else { 'Yok' }
        $discordText = if ($n.DiscordWebhook) { 'Ayarlanmis' } else { 'Yok' }
        Write-Host ("  - Teams Webhook  : " + $teamsText)
        Write-Host ("  - Slack Webhook  : " + $slackText)
        Write-Host ("  - Discord Webhook: " + $discordText)
        Write-Host ("  - SMTP Sunucu    : " + $smtpText)
        Write-Host ''
        Write-Host '  [1] Teams Webhook Ayarla' -ForegroundColor White
        Write-Host '  [2] Slack Webhook Ayarla' -ForegroundColor White
        Write-Host '  [3] Discord Webhook Ayarla' -ForegroundColor White
        Write-Host '  [4] SMTP (E-Posta) Sunucusu Ayarla' -ForegroundColor White
        Write-Host '  [5] Bildirim Kanallarini Test Et' -ForegroundColor White
        Write-Host ''
        Write-Host '  Enter) Ana Menuye Don' -ForegroundColor DarkGray
        Write-Host ''
        
        $sel = Read-Host 'Secim'
        switch ($sel) {
            ''  { $run = $false }
            '0' { $run = $false }
            '1' {
                Write-Host ''
                Write-Host 'Teams Webhook URL adresinizi girin (temizlemek icin bos birakin):'
                $url = Read-Host 'Webhook URL'
                try {
                    if ($url) {
                        Set-PSCMSecret -Name 'Teams.WebhookUrl' -Value (ConvertTo-SecureString $url -AsPlainText -Force)
                        $n.Teams.Enabled = $true
                        $n.Enabled = $true
                        Write-Host 'Teams Webhook guncellendi.' -ForegroundColor Green
                    } else {
                        Remove-PSCMSecret -Name 'Teams.WebhookUrl' -EA SilentlyContinue
                        $n.Teams.Enabled = $false
                        Write-Host 'Teams Webhook temizlendi.' -ForegroundColor Green
                    }
                    $obj | Write-PSCMJson -Path $path
                } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
                Pause-PSCM
            }
            '2' {
                Write-Host ''
                Write-Host 'Slack Webhook URL adresinizi girin (temizlemek icin bos birakin):'
                $url = Read-Host 'Webhook URL'
                $obj.Notification.SlackWebhook = $url
                if ($url) { $obj.Notification.Enabled = $true; Write-Host 'Slack Webhook guncellendi.' -ForegroundColor Green }
                else { Write-Host 'Slack Webhook temizlendi.' -ForegroundColor Green }
                $obj | Write-PSCMJson -Path $path
                Pause-PSCM
            }
            '3' {
                Write-Host ''
                Write-Host 'Discord Webhook URL adresinizi girin (temizlemek icin bos birakin):'
                $url = Read-Host 'Webhook URL'
                $obj.Notification.DiscordWebhook = $url
                if ($url) { $obj.Notification.Enabled = $true; Write-Host 'Discord Webhook guncellendi.' -ForegroundColor Green }
                else { Write-Host 'Discord Webhook temizlendi.' -ForegroundColor Green }
                $obj | Write-PSCMJson -Path $path
                Pause-PSCM
            }
            '4' {
                Write-Host ''
                Write-Host 'SMTP Sunucu adresini girin (Orn: smtp.office365.com) (temizlemek icin bos birakin):'
                $srv = Read-Host 'SMTP Sunucu'
                if (-not $srv) {
                    $n.Smtp.Server = ''
                    $n.Smtp.Username = ''
                    Write-Host 'SMTP ayarlari temizlendi.' -ForegroundColor Green
                } else {
                    $n.Smtp.Server = $srv
                    $port = Read-Host 'SMTP Port (Orn: 587)'
                    $n.Smtp.Port = [int]$port
                    $ssl = Read-Host 'SSL/TLS kullanilsin mi? [E/H]'
                    $n.Smtp.UseTls = ($ssl -match '^[EeYy]')
                    $from = Read-Host 'Gonderen (From) E-Posta Adresi (Orn: cert@sirket.com)'
                    $n.Smtp.From = $from
                    $to = Read-Host 'Alici (To) E-Posta Adresi (Orn: admin@sirket.com)'
                    $n.Smtp.To = @($to -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
                    $user = Read-Host 'SMTP Kullanici Adi (Gerekli degilse bos birakin)'
                    $n.Smtp.Username = $user
                    if ($user) {
                        Write-Host 'SMTP Parolasini girin (Guvenli kasaya kaydedilecek):'
                        $pass = Read-Host -AsSecureString
                        Set-PSCMSecret -Name 'Smtp.Password' -Value $pass
                    }
                    $n.Enabled = $true
                    Write-Host 'SMTP ayarlari basariyla guncellendi.' -ForegroundColor Green
                }
                $obj | Write-PSCMJson -Path $path
                Pause-PSCM
            }
            '5' {
                Write-Host "`nTest mesaji gonderiliyor..." -ForegroundColor Cyan
                try {
                    $testMsg = "PS-CertManager: Bu bir test mesajidir. Bildirim ayarlariniz dogru calisiyor!"
                    $sent = 0
                    if ($n.Teams.Enabled -or (Get-PSCMSecret -Name 'Teams.WebhookUrl')) {
                        Send-PSCMTeamsNotification -Title 'Test Basarili' -Message $testMsg -Level 'Basari'
                        Write-Host "Teams test mesaji gonderimi tetiklendi." -ForegroundColor Green
                        $sent++
                    }
                    if ($obj.Notification.SlackWebhook) {
                        Send-PSCMSlackNotification -Title 'Test Basarili' -Message $testMsg -Level 'Basari'
                        Write-Host "Slack test mesaji gonderimi tetiklendi." -ForegroundColor Green
                        $sent++
                    }
                    if ($obj.Notification.DiscordWebhook) {
                        Send-PSCMDiscordNotification -Title 'Test Basarili' -Message $testMsg -Level 'Basari'
                        Write-Host "Discord test mesaji gonderimi tetiklendi." -ForegroundColor Green
                        $sent++
                    }
                    if ($n.Smtp.Server) {
                        Send-PSCMMailNotification -Subject "PS-CertManager Test" -Body $testMsg
                        Write-Host "E-Posta (SMTP) test mesaji gonderimi tetiklendi." -ForegroundColor Green
                        $sent++
                    }
                    if ($sent -eq 0) {
                        Write-Host "Ayarlanmis herhangi bir bildirim kanali bulunamadi!" -ForegroundColor Yellow
                    }
                } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
                Pause-PSCM
            }
            '0' { $run = $false }
        }
    }
}
