function Get-PSCMAcmeProviders {
<#
.SYNOPSIS
    Sistemde desteklenen ACME Sağlayıcılarının (Otoritelerinin) listesini döndürür.
#>
    [CmdletBinding()]
    param()
    return @(
        [PSCustomObject]@{ Name = 'LetsEncrypt'; DisplayName = "Let's Encrypt (Ucretsiz)"; DirectoryUrl = 'LE_PROD'; RequireEAB = $false }
        [PSCustomObject]@{ Name = 'LetsEncryptStaging'; DisplayName = "Let's Encrypt Staging (Test/Deneme)"; DirectoryUrl = 'LE_STAGE'; RequireEAB = $false }
        [PSCustomObject]@{ Name = 'ZeroSSL'; DisplayName = "ZeroSSL (Ucretsiz/Ucretli)"; DirectoryUrl = 'ZeroSSL'; RequireEAB = $false }
        [PSCustomObject]@{ Name = 'GoDaddy'; DisplayName = "GoDaddy CA (Ucretli - EAB)"; DirectoryUrl = 'https://acme.godaddy.com/v1/directory'; RequireEAB = $true }
    )
}
