/* ============================================================
   PS-CertManager v4 — Dashboard Application Logic
   ============================================================ */

// ── State ──
let certData = [];
let currentFilter = 'all';
let autoRefreshInterval = null;
let autoRefreshEnabled = true;
const AUTO_REFRESH_MS = 30000;

const pageTitles = {
  'page-dashboard': 'Dashboard',
  'page-certs': 'Sertifika Yönetimi',
  'page-queue': 'İşlem Kuyruğu',
  'page-ssltools': 'SSL & Sertifika Araçları',
  'page-system': 'Sistem & Loglar',
  'page-settings': 'Ayarlar'
};

// ── Init ──
document.addEventListener('DOMContentLoaded', () => {
  refreshAll();
  startAutoRefresh();
});

// ── Navigation ──
function switchPage(pageId, navEl) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById(pageId).classList.add('active');
  if (navEl) navEl.classList.add('active');
  document.getElementById('pageTitle').textContent = pageTitles[pageId] || '';

  if (pageId === 'page-queue') loadQueue();
  if (pageId === 'page-system') { loadSystemSummary(); loadInfra(); loadSched(); loadLogs(); }
  if (pageId === 'page-settings') { loadNotifications(); loadSettings(); }
}

// ── Auto Refresh ──
function toggleAutoRefresh() {
  const btn = document.getElementById('autoRefreshToggle');
  autoRefreshEnabled = !autoRefreshEnabled;
  btn.classList.toggle('on', autoRefreshEnabled);
  if (autoRefreshEnabled) startAutoRefresh(); else stopAutoRefresh();
}

function startAutoRefresh() {
  stopAutoRefresh();
  autoRefreshInterval = setInterval(() => refreshAll(true), AUTO_REFRESH_MS);
}

function stopAutoRefresh() {
  if (autoRefreshInterval) { clearInterval(autoRefreshInterval); autoRefreshInterval = null; }
}

// ── Toast ──
let toastTimer = null;
function showToast(msg, isError = false) {
  const t = document.getElementById('toast');
  if (!t) return;
  if (toastTimer) clearTimeout(toastTimer);

  const icon = isError ? '❌ ' : '✅ ';
  let extraHint = '';
  if (isError) {
    extraHint = '<br><span style="font-size:11px;opacity:0.85;font-weight:normal;">💡 Detaylı hata geçmişini Sistem & Loglar sekmesinde inceleyebilirsiniz.</span>';
  }
  
  t.innerHTML = `<div>${icon}${esc(msg)}${extraHint}</div><button class="toast-close" onclick="hideToast()">✕</button>`;
  t.classList.toggle('error', isError);
  t.classList.add('show');

  const timeoutMs = isError ? 12000 : 5000;
  toastTimer = setTimeout(() => hideToast(), timeoutMs);
}

function hideToast() {
  const t = document.getElementById('toast');
  if (t) t.classList.remove('show');
  if (toastTimer) { clearTimeout(toastTimer); toastTimer = null; }
}

// ── Animated Counter ──
function animateCounter(el, target) {
  const duration = 600;
  const start = parseInt(el.textContent) || 0;
  if (start === target) return;
  const startTime = performance.now();
  function step(now) {
    const progress = Math.min((now - startTime) / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.round(start + (target - start) * eased);
    if (progress < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

// ── Certificate Status Helper ──
function calcStatus(notAfterStr) {
  if (!notAfterStr) return { cls: 'expired', badge: 'badge-expired', text: 'Bilinmiyor', days: -1 };
  const days = Math.ceil((new Date(notAfterStr) - new Date()) / 86400000);
  if (days <= 0) return { cls: 'expired', badge: 'badge-expired', text: 'Süresi Doldu', days };
  if (days <= 10) return { cls: 'crit', badge: 'badge-crit', text: 'Kritik (' + days + ' gün)', days };
  if (days <= 30) return { cls: 'warn', badge: 'badge-warn', text: 'Uyarı (' + days + ' gün)', days };
  return { cls: 'ok', badge: 'badge-ok', text: 'Sağlıklı', days };
}

// ── LOAD: Certificates ──
async function loadCerts(silent = false) {
  const btn = document.getElementById('refreshBtn');
  if (!silent) btn.classList.add('loading');
  try {
    const res = await fetch('/api/v1/certificates');
    if (!res.ok) throw new Error('API Hatası: ' + res.status);
    certData = await res.json();
    if (!Array.isArray(certData)) certData = [];
    certData.sort((a, b) => new Date(a.NotAfter) - new Date(b.NotAfter));
    renderDashboard();
    renderCertTable();
    document.getElementById('lastSync').textContent = 'Son: ' + new Date().toLocaleTimeString('tr-TR');
  } catch (err) {
    if (!silent) showToast(err.message, true);
  } finally {
    btn.classList.remove('loading');
  }
}

// ── RENDER: Dashboard Stats + Progress ──
function renderDashboard() {
  let ok = 0, warn = 0, crit = 0;
  certData.forEach(c => {
    const st = calcStatus(c.NotAfter);
    if (st.cls === 'ok') ok++;
    else if (st.cls === 'warn') warn++;
    else crit++;
  });

  animateCounter(document.getElementById('valTotal'), certData.length);
  animateCounter(document.getElementById('valOk'), ok);
  animateCounter(document.getElementById('valWarn'), warn);
  animateCounter(document.getElementById('valCrit'), crit);

  // Nav badges
  const critBadge = document.getElementById('navBadgeCrit');
  if (crit > 0) { critBadge.textContent = crit; critBadge.style.display = ''; }
  else { critBadge.style.display = 'none'; }

  // Progress bars
  const container = document.getElementById('progressList');
  if (certData.length === 0) {
    container.innerHTML = '<div class="empty-state"><p>Kayıtlı sertifika bulunamadı.</p></div>';
    return;
  }
  const maxDays = 90;
  container.innerHTML = certData.map(c => {
    const st = calcStatus(c.NotAfter);
    const pct = Math.max(0, Math.min(100, (st.days / maxDays) * 100));
    const daysText = st.days > 0 ? st.days + ' gün' : 'Doldu';
    const daysColor = st.cls === 'ok' ? 'var(--ok)' : st.cls === 'warn' ? 'var(--warn)' : 'var(--crit)';
    return `<div class="cert-progress-item">
      <span class="cert-progress-domain" title="${c.Domain}">${c.Domain}</span>
      <div class="cert-progress-bar-bg">
        <div class="cert-progress-bar-fill ${st.cls}" style="width:${pct}%"></div>
      </div>
      <span class="cert-progress-days" style="color:${daysColor}">${daysText}</span>
    </div>`;
  }).join('');
}

// ── RENDER: Certificates Table ──
function renderCertTable() {
  const tbody = document.getElementById('tableBody');
  const search = (document.getElementById('searchInput').value || '').toLowerCase();
  let filtered = certData;

  if (search) {
    filtered = filtered.filter(c =>
      (c.Domain || '').toLowerCase().includes(search) ||
      (c.Issuer || '').toLowerCase().includes(search) ||
      (c.Thumbprint || '').toLowerCase().includes(search)
    );
  }

  if (currentFilter !== 'all') {
    filtered = filtered.filter(c => {
      const st = calcStatus(c.NotAfter);
      if (currentFilter === 'crit') return st.cls === 'crit' || st.cls === 'expired';
      return st.cls === currentFilter;
    });
  }

  if (filtered.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" class="empty-state"><p>Eşleşen sertifika bulunamadı.</p></td></tr>';
    return;
  }

  tbody.innerHTML = filtered.map(c => {
    const st = calcStatus(c.NotAfter);
    const expDate = c.NotAfter ? new Date(c.NotAfter).toLocaleDateString('tr-TR') : '—';
    const daysText = st.days > 0 ? st.days + ' gün' : (st.days === 0 ? 'Bugün' : '—');
    return `<tr>
      <td class="domain-cell">${esc(c.Domain)}</td>
      <td>${c.Wildcard ? '✓ Evet' : '—'}</td>
      <td>${esc(c.Issuer || '—')}</td>
      <td>${expDate}</td>
      <td>${daysText}</td>
      <td><span class="badge ${st.badge}">${st.text}</span></td>
      <td>
        <div class="actions-cell">
          <button class="action-btn" onclick="sendAction('renew','${esc(c.Domain)}')">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
            Yenile
          </button>
          <div class="dropdown">
            <button class="action-btn dropdown-trigger" onclick="toggleDropdown(this)">⋯</button>
            <div class="dropdown-menu">
              <button class="dropdown-item" onclick="sendAction('test','${esc(c.Domain)}')">Test Et</button>
              <button class="dropdown-item" onclick="promptRepair('${esc(c.Domain)}')">PFX Onar</button>
              <button class="dropdown-item danger" onclick="sendAction('remove','${esc(c.Domain)}')">Arşive Taşı</button>
            </div>
          </div>
        </div>
      </td>
    </tr>`;
  }).join('');
}

function esc(s) { return s ? s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])) : ''; }

function formatBytes(bytes) {
  if (!bytes || bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

// ── Filter & Search ──
function setFilter(f, btn) {
  currentFilter = f;
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderCertTable();
}

function filterCerts() { renderCertTable(); }

// ── Dropdown ──
function toggleDropdown(trigger) {
  const dd = trigger.closest('.dropdown');
  const wasOpen = dd.classList.contains('open');
  document.querySelectorAll('.dropdown.open').forEach(d => d.classList.remove('open'));
  if (!wasOpen) dd.classList.add('open');
}
document.addEventListener('click', e => {
  if (!e.target.closest('.dropdown')) {
    document.querySelectorAll('.dropdown.open').forEach(d => d.classList.remove('open'));
  }
});

// ── Actions ──
async function sendAction(action, domain) {
  if (!confirm(domain + ' için "' + action + '" işlemi kuyruğa eklensin mi?')) return;
  try {
    const res = await fetch('/api/v1/action', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ Action: action, Domain: domain })
    });
    const data = await res.json();
    showToast(data.message, !res.ok);
  } catch { showToast('Ağ hatası: işlem gönderilemedi.', true); }
}

function promptRepair(domain) {
  const p = prompt(domain + ' için yeni PFX parolası girin:');
  if (!p) return;
  fetch('/api/v1/action', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ Action: 'repair', Domain: domain, Params: { PfxPass: p } })
  }).then(r => r.json()).then(() => showToast('Onarım emri kuyruğa eklendi!'))
    .catch(() => showToast('Hata oluştu.', true));
}

// ── Queue ──
async function loadQueue() {
  try {
    const res = await fetch('/api/v1/actionqueue');
    const data = await res.json();
    const tb = document.getElementById('tbQueue');
    const all = [...(data.pending||[]), ...(data.processed||[]), ...(data.failed||[])];
    all.sort((a, b) => new Date(b.CreatedAt) - new Date(a.CreatedAt));

    const qBadge = document.getElementById('navBadgeQueue');
    const pendingCount = (data.pending || []).length;
    if (pendingCount > 0) { qBadge.textContent = pendingCount; qBadge.style.display = ''; qBadge.style.background = 'var(--warn-bg)'; qBadge.style.color = 'var(--warn)'; qBadge.style.borderColor = 'var(--warn-border)'; }
    else { qBadge.style.display = 'none'; }

    if (all.length === 0) { tb.innerHTML = '<tr><td colspan="5" class="empty-state"><p>Kuyruk boş.</p></td></tr>'; return; }
    tb.innerHTML = all.map(q => {
      const badgeCls = q.Status === 'pending' ? 'badge-pending' : (q.Status === 'processed' ? 'badge-processed' : 'badge-failed');
      const date = q.CreatedAt ? new Date(q.CreatedAt).toLocaleString('tr-TR') : '—';
      return `<tr>
        <td class="domain-cell">${esc(q.Action)}</td>
        <td>${esc(q.Domain)}</td>
        <td>${date}</td>
        <td><span class="badge ${badgeCls}">${esc(q.Status)}</span></td>
        <td style="font-size:12px;color:var(--text-muted);">${esc(q.Error || '—')}</td>
      </tr>`;
    }).join('');
  } catch {}
}

async function processQueue() {
  if (!confirm('Kuyruktaki işlemleri hemen başlatmak istiyor musunuz?')) return;
  try {
    const res = await fetch('/api/v1/actionqueue/process', { method: 'POST' });
    const data = await res.json();
    showToast(data.message);
    loadQueue();
  } catch { showToast('Hata oluştu.', true); }
}

async function clearQueue() {
  if (!confirm('30 günden eski tamamlanmış işlemleri temizlemek istiyor musunuz?')) return;
  try {
    const res = await fetch('/api/v1/actionqueue/clear', { method: 'POST' });
    const data = await res.json();
    showToast(data.message);
    loadQueue();
  } catch {}
}

// ── Infrastructure ──
async function loadInfra() {
  try {
    const res = await fetch('/api/v1/infrastructure');
    const data = await res.json();
    if (!data || data.length === 0) { document.getElementById('divInfra').innerHTML = '<div class="empty-state"><p>Altyapı bilgisi bulunamadı.</p></div>'; return; }
    document.getElementById('divInfra').innerHTML = data.map(d => {
      const stCls = (d.Durum === 'OK' || d.Durum === 'Installed') ? 'ok' : 'fail';
      return `<div class="infra-item">
        <div><div class="infra-name">${esc(d.Bilesen)}</div><div class="infra-detail">${esc(d.Kategori || '')} ${d.Detay ? '— ' + esc(d.Detay) : ''}</div></div>
        <div class="infra-status ${stCls}">${esc(d.Durum)}</div>
      </div>`;
    }).join('');
  } catch {}
}

// ── Scheduler ──
async function loadSched() {
  try {
    const res = await fetch('/api/v1/scheduler');
    const data = await res.json();
    if (!data || data.length === 0) { document.getElementById('divSched').innerHTML = '<div class="empty-state"><p>Kayıtlı görev yok.</p></div>'; return; }
    document.getElementById('divSched').innerHTML = data.map(d => {
      return `<div class="infra-item">
        <div><div class="infra-name">${esc(d.Name || d.TaskName || '—')}</div><div class="infra-detail">Son: ${esc(d.LastRunTime || '—')} · Sonraki: ${esc(d.NextRunTime || '—')}</div></div>
        <div class="infra-status ok">${esc(d.State || d.Status || '—')}</div>
      </div>`;
    }).join('');
  } catch {}
}

// ── System Summary ──
async function loadSystemSummary() {
  try {
    const res = await fetch('/api/v1/system/summary');
    if (!res.ok) return;
    const data = await res.json();
    
    document.getElementById('sysAdminState').textContent = data.isAdmin ? 'Admin (Aktif)' : 'Kullanıcı (Sınırlı)';
    document.getElementById('sysAdminState').style.color = data.isAdmin ? 'var(--ok)' : 'var(--warn)';
    
    document.getElementById('sysVaultState').textContent = data.vaultStatus || 'Hazır';
    document.getElementById('sysPsVersion').textContent = 'v' + (data.psVersion || '5.1') + ' / UTF-8';
    document.getElementById('sysPortInfo').textContent = 'Port ' + (data.port || 8080) + ' (Canlı)';
  } catch {}
}

// ── Infrastructure Repair ──
async function repairInfra() {
  const btn = document.getElementById('btnRepairInfra');
  if (btn) { btn.textContent = 'Onarılıyor...'; btn.disabled = true; }
  showToast('Altyapı bileşenleri ve eksik modüller kontrol edilip onarılıyor...');
  try {
    const res = await fetch('/api/v1/infrastructure/repair', { method: 'POST' });
    const data = await res.json();
    showToast(data.message, !res.ok);
    loadInfra();
  } catch {
    showToast('Altyapı onarımı sırasında hata oluştu.', true);
  } finally {
    if (btn) { btn.textContent = '🛠️ Eksikleri Onar'; btn.disabled = false; }
  }
}

// ── Advanced Logs Filtering & Download ──
let rawLogsData = [];
let currentLogFilter = 'ALL';

async function loadLogs() {
  try {
    const res = await fetch('/api/v1/logs');
    const data = await res.json();
    rawLogsData = Array.isArray(data) ? data : [];
    renderLogs();
  } catch {}
}

function setLogFilter(level, btn) {
  currentLogFilter = level;
  document.querySelectorAll('.log-filter-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  renderLogs();
}

function filterLogs() {
  renderLogs();
}

function renderLogs() {
  const div = document.getElementById('divLogs');
  if (!div) return;
  
  const query = (document.getElementById('logSearchInput')?.value || '').toLowerCase().trim();
  
  let filtered = rawLogsData.filter(line => {
    if (currentLogFilter !== 'ALL' && !line.includes('[' + currentLogFilter + ']')) return false;
    if (query && !line.toLowerCase().includes(query)) return false;
    return true;
  });

  if (filtered.length === 0) {
    div.textContent = 'Filtrelere uygun log kaydı bulunamadı.';
    return;
  }

  div.innerHTML = filtered.map(line => {
    const escaped = esc(line);
    if (line.includes('[ERROR]')) return `<span style="color:#ef4444;font-weight:bold;">${escaped}</span>`;
    if (line.includes('[WARNING]')) return `<span style="color:#f59e0b;">${escaped}</span>`;
    if (line.includes('[INFO]')) return `<span style="color:#10b981;">${escaped}</span>`;
    return escaped;
  }).join('<br>');
}

function downloadLogs() {
  if (!rawLogsData || rawLogsData.length === 0) {
    showToast('İndirilecek log kaydı bulunamadı.', true);
    return;
  }
  const text = rawLogsData.join('\r\n');
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `pscm_logs_${new Date().toISOString().slice(0,10)}.log`;
  a.click();
  showToast('Log dosyası indiriliyor...');
}

// ── Local File Picker (HTML5 File API) ──
function selectLocalFile(targetInputId, fileInputEl) {
  if (fileInputEl.files && fileInputEl.files.length > 0) {
    const file = fileInputEl.files[0];
    let val = file.path || file.name;
    
    if (val === file.name && !val.includes('\\') && !val.includes('/')) {
      showToast('İpucu: Sunucudaki dosyayı doğrudan seçmek için yandaki [🖥️ Sunucudan Seç] butonunu kullanabilirsiniz.');
    } else {
      showToast('Dosya seçildi: ' + file.name);
    }
    document.getElementById(targetInputId).value = val;
  }
}

// ── Interactive Server File Explorer Modal Logic ──
let activeBrowserTargetId = null;
let activeBrowserMode = 'file';
let currentServerDirPath = 'C:\\';
let currentParentDirPath = '';

function openServerFileBrowser(targetInputId, mode) {
  activeBrowserTargetId = targetInputId;
  activeBrowserMode = mode;
  document.getElementById('serverFileBrowserModal').classList.add('show');
  
  const btnFolder = document.getElementById('btnSelectCurrentFolder');
  if (btnFolder) btnFolder.style.display = (mode === 'folder') ? 'inline-block' : 'none';
  
  const currentVal = document.getElementById(targetInputId)?.value;
  let startPath = 'C:\\';
  if (currentVal && currentVal.length > 3) {
    const idx = currentVal.lastIndexOf('\\');
    if (idx > 0) startPath = currentVal.substring(0, idx);
  }
  loadServerDir(startPath);
}

function closeServerFileBrowser() {
  document.getElementById('serverFileBrowserModal').classList.remove('show');
}

async function loadServerDir(dirPath) {
  const container = document.getElementById('serverFileListContainer');
  container.innerHTML = '<div class="empty-state"><p>Dizin yükleniyor...</p></div>';
  
  try {
    const res = await fetch('/api/v1/system/dir?path=' + encodeURIComponent(dirPath));
    const data = await res.json();
    
    currentServerDirPath = data.currentPath || dirPath;
    currentParentDirPath = data.parentPath || '';
    document.getElementById('serverCurrentPath').value = currentServerDirPath;
    
    // Drive Buttons - use data-drive attribute to avoid backslash escaping issues
    const drivesDiv = document.getElementById('serverDriveButtons');
    if (drivesDiv && Array.isArray(data.drives)) {
      drivesDiv.innerHTML = '';
      data.drives.forEach(drv => {
        const btn = document.createElement('button');
        btn.className = 'btn btn-ghost btn-sm';
        btn.style.cssText = 'padding:2px 8px; font-size:11px;';
        btn.textContent = drv;
        btn.setAttribute('data-drive', drv);
        btn.addEventListener('click', function() { loadServerDir(this.getAttribute('data-drive')); });
        drivesDiv.appendChild(btn);
      });
    }

    if (!Array.isArray(data.items) || data.items.length === 0) {
      container.innerHTML = '<div class="empty-state"><p>Bu klasör boş veya erişim izni yok.</p></div>';
      return;
    }

    // Build file list using DOM API to avoid backslash escaping bugs in inline onclick
    container.innerHTML = '';
    data.items.forEach(item => {
      const icon = item.isDir ? '📁' : getFileIcon(item.extension);
      const sizeStr = item.isDir ? '<DIR>' : formatBytes(item.size);
      
      const row = document.createElement('div');
      row.className = 'server-file-item' + (item.isDir ? ' is-dir' : '');
      row.setAttribute('data-fullpath', item.fullPath);
      row.setAttribute('data-isdir', item.isDir ? 'true' : 'false');
      row.innerHTML = `<span class="server-file-icon">${icon}</span><span class="server-file-name">${esc(item.name)}</span><span class="server-file-size">${sizeStr}</span>`;
      row.addEventListener('click', function() {
        const fp = this.getAttribute('data-fullpath');
        const isDir = this.getAttribute('data-isdir') === 'true';
        handleServerItemClick(fp, isDir);
      });
      container.appendChild(row);
    });

  } catch (e) {
    container.innerHTML = '<div class="empty-state"><p>Hata: ' + esc(e.message) + '</p></div>';
  }
}

function navServerParentDir() {
  if (currentParentDirPath) {
    loadServerDir(currentParentDirPath);
  }
}

function handleServerItemClick(fullPath, isDir) {
  if (isDir) {
    loadServerDir(fullPath);
  } else {
    if (activeBrowserTargetId) {
      document.getElementById(activeBrowserTargetId).value = fullPath;
      showToast('Sunucu dosyası seçildi: ' + fullPath);
    }
    closeServerFileBrowser();
  }
}

function confirmFolderSelection() {
  if (activeBrowserTargetId && currentServerDirPath) {
    document.getElementById(activeBrowserTargetId).value = currentServerDirPath;
    showToast('Sunucu klasörü seçildi: ' + currentServerDirPath);
  }
  closeServerFileBrowser();
}

function getFileIcon(ext) {
  if (ext === '.csr') return '📄';
  if (ext === '.cer' || ext === '.crt' || ext === '.pem') return '📜';
  if (ext === '.key') return '🔑';
  if (ext === '.pfx' || ext === '.p12') return '📦';
  if (ext === '.jks' || ext === '.keystore') return '☕';
  return '📃';
}

// ── Native Windows File Picker Dialog ──
async function browseFile(inputId, filterType) {
  let payload = { Mode: 'file' };
  
  if (filterType === 'csr') {
    payload.Filter = "CSR Istek Dosyalari (*.csr)|*.csr|Tum Dosyalar (*.*)|*.*";
  } else if (filterType === 'cert') {
    payload.Filter = "Sertifika Dosyalari (*.cer;*.crt;*.pem)|*.cer;*.crt;*.pem|Tum Dosyalar (*.*)|*.*";
  } else if (filterType === 'key') {
    payload.Filter = "Private Key Dosyalari (*.key)|*.key|Tum Dosyalar (*.*)|*.*";
  } else if (filterType === 'pfx') {
    payload.Filter = "PFX / PKCS12 Paketi (*.pfx;*.p12)|*.pfx;*.p12|Tum Dosyalar (*.*)|*.*";
  } else if (filterType === 'all') {
    payload.Filter = "Sertifika Dosyalari (*.cer;*.crt;*.pem;*.csr;*.key;*.pfx)|*.cer;*.crt;*.pem;*.csr;*.key;*.pfx|Tum Dosyalar (*.*)|*.*";
  } else if (filterType === 'save_pfx') {
    payload.Mode = 'save';
    payload.Filter = "PFX Paketi (*.pfx)|*.pfx";
    payload.DefaultFileName = "certificate.pfx";
  } else if (filterType === 'save_jks') {
    payload.Mode = 'save';
    payload.Filter = "Java Keystore (*.jks;*.keystore)|*.jks;*.keystore";
    payload.DefaultFileName = "keystore.jks";
  } else if (filterType === 'save_folder' || filterType === 'folder') {
    payload.Mode = 'save';
    payload.Filter = "Klasor Secimi | *.folder";
    payload.DefaultFileName = "Klasor_Sec";
  }

  showToast('Windows dosya seçici penceresi açılıyor...');

  try {
    const res = await fetch('/api/v1/system/filedialog', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.success && data.selectedPath) {
      let val = data.selectedPath;
      if (filterType === 'save_folder' || filterType === 'folder') {
        const idx = val.lastIndexOf('\\');
        if (idx > 0) {
          val = val.substring(0, idx);
        }
      }
      document.getElementById(inputId).value = val;
      showToast('Seçildi: ' + val);
    } else {
      showToast('Seçim iptal edildi.');
    }
  } catch (e) {
    showToast('Dosya seçici açılamadı: ' + e.message, true);
  }
}

// ── SSL Tab Switcher ──
function switchSslTab(tabId, btn) {
  document.querySelectorAll('.ssl-tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.ssl-tab-content').forEach(c => c.style.display = 'none');
  
  if (btn) btn.classList.add('active');
  const target = document.getElementById(tabId);
  if (target) target.style.display = 'block';
}

// ── Dedicated SSL Tools Page Logic ──
async function runSslAction(action) {
  let payload = { Action: action };
  
  if (action === 'read_csr') {
    payload.CsrPath = document.getElementById('toolCsrPath').value.trim();
    if (!payload.CsrPath) { showToast('CSR dosya yolu girilmelidir.', true); return; }
  }
  else if (action === 'read_cert') {
    payload.CertPath = document.getElementById('toolCertPath').value.trim();
    if (!payload.CertPath) { showToast('Sertifika dosya yolu girilmelidir.', true); return; }
  }
  else if (action === 'make_pfx') {
    payload.CertPath = document.getElementById('toolPfxCert').value.trim();
    payload.KeyPath = document.getElementById('toolPfxKey').value.trim();
    payload.DestinationPfx = document.getElementById('toolPfxDest').value.trim();
    payload.PfxPass = document.getElementById('toolPfxPass').value;
    if (!payload.CertPath || !payload.KeyPath || !payload.DestinationPfx) {
      showToast('Sertifika, Key ve Hedef PFX yolları girilmelidir.', true); return;
    }
  }
  else if (action === 'export_pfx') {
    payload.PfxPath = document.getElementById('toolExpPfxPath').value.trim();
    payload.PfxPass = document.getElementById('toolExpPfxPass').value;
    payload.OutFolder = document.getElementById('toolExpFolder').value.trim();
    if (!payload.PfxPath || !payload.OutFolder) {
      showToast('PFX yolu ve hedef klasör girilmelidir.', true); return;
    }
  }
  else if (action === 'export_jks') {
    payload.PfxPath = document.getElementById('toolJksPfxPath').value.trim();
    payload.PfxPass = document.getElementById('toolJksPfxPass').value;
    payload.DestinationJks = document.getElementById('toolJksDest').value.trim();
    if (!payload.PfxPath || !payload.DestinationJks) {
      showToast('PFX yolu ve hedef Keystore (.jks) yolu girilmelidir.', true); return;
    }
  }
  else if (action === 'new_csr') {
    payload.Domain = document.getElementById('toolNewCsrDom').value.trim();
    payload.Organization = document.getElementById('toolNewCsrOrg').value.trim();
    payload.OutFolder = document.getElementById('toolNewCsrFolder').value.trim();
    if (!payload.Domain) {
      showToast('Domain adı (CN) girilmelidir.', true); return;
    }
  }

  const box = document.getElementById('sslConsoleBox');
  if (box) {
    box.style.display = 'block';
    box.textContent = 'İşlem çalıştırılıyor... Lütfen bekleyin.';
  }
  showToast('SSL aracı çalıştırılıyor...');

  try {
    const res = await fetch('/api/v1/ssl/tools', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (res.ok && data.success) {
      showToast(data.message || 'İşlem başarıyla tamamlandı!');
      if (box) {
        if (typeof data.data === 'string') {
          // Long text output like certutil dump
          box.style.whiteSpace = 'pre-wrap';
          box.textContent = data.data;
        } else if (typeof data.data === 'object' && data.data !== null) {
          box.style.whiteSpace = 'normal';
          let html = '';
          for (let k in data.data) {
            const val = data.data[k] != null ? String(data.data[k]) : '';
            html += `<div style="margin-bottom:6px;"><span style="color:#60a5fa;font-weight:bold;">${esc(k)}:</span> <span style="color:#e2e8f0;font-family:monospace;">${esc(val)}</span></div>`;
          }
          box.innerHTML = html;
        } else {
          box.textContent = data.message || 'Başarılı.';
        }
      }
    } else {
      showToast(data.message || 'İşlem sırasında hata oluştu.', true);
      if (box) box.textContent = '❌ Hata: ' + (data.message || 'Bilinmeyen hata');
    }
  } catch (e) {
    showToast('Bağlantı hatası: ' + e.message, true);
    if (box) box.textContent = '🔌 Ağ Hatası: ' + e.message;
  }
}

// ── SSL Diagnostic Modal ──
function openSslModal() {
  document.getElementById('sslToolsModal').classList.add('show');
}
function closeSslModal() {
  document.getElementById('sslToolsModal').classList.remove('show');
  document.getElementById('sslResultBox').style.display = 'none';
}
function toggleSslFields() {
  const act = document.getElementById('sslActionSelect').value;
  document.getElementById('fieldCsr').style.display = act === 'csr' ? '' : 'none';
  document.getElementById('fieldCertInfo').style.display = act === 'certinfo' ? '' : 'none';
}

async function submitSslTool() {
  const act = document.getElementById('sslActionSelect').value;
  let actionKey = act === 'csr' ? 'read_csr' : 'read_cert';
  let payload = { Action: actionKey };
  if (act === 'csr') {
    payload.CsrPath = document.getElementById('sslCsrDomain').value.trim();
  } else if (act === 'certinfo') {
    payload.CertPath = document.getElementById('sslCertPath').value.trim();
  }

  const box = document.getElementById('sslResultBox');
  box.style.display = 'block';
  box.textContent = 'İşlem çalıştırılıyor...';

  try {
    const res = await fetch('/api/v1/ssl/tools', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.success) {
      box.textContent = typeof data.data === 'object' ? JSON.stringify(data.data, null, 2) : (data.data || data.message);
    } else {
      box.textContent = 'Hata: ' + data.message;
    }
  } catch (e) {
    box.textContent = 'Bağlantı hatası: ' + e.message;
  }
}

// ── Settings ──
async function loadSettings() {
  try {
    const res = await fetch('/api/v1/settings');
    if (!res.ok) throw new Error('Ayarlar yüklenemedi');
    const settings = await res.json();
    renderSettings(settings);
  } catch (e) {
    document.getElementById('settingsContainer').innerHTML = '<div class="empty-state" style="grid-column:1/-1;"><p>' + esc(e.message) + '</p></div>';
  }
}

function renderSettings(obj) {
  const container = document.getElementById('settingsContainer');
  const sectionIcons = {
    'General': '⚙️', 'Azure': '☁️', 'Acme': '🔐', 'Certificate': '📜',
    'Notification': '🔔', 'Logging': '📋', 'Paths': '📁', 'Defaults': '🏷️'
  };

  let html = '';
  for (const [section, val] of Object.entries(obj)) {
    if (section === 'Version') continue;
    if (typeof val !== 'object' || val === null) continue;
    const icon = sectionIcons[section] || '📦';
    html += `<div class="settings-section"><h3>${icon} ${esc(section)}</h3>`;
    html += renderSettingRows(val, section);
    html += '</div>';
  }
  container.innerHTML = html || '<div class="empty-state" style="grid-column:1/-1;"><p>Ayar bulunamadı.</p></div>';
}

function renderSettingRows(obj, prefix) {
  let html = '';
  const parts = prefix.split('.');
  const section = parts[0];
  
  for (const [key, val] of Object.entries(obj)) {
    if (typeof val === 'object' && val !== null && !Array.isArray(val)) {
      html += `<div style="margin-top:12px;margin-bottom:4px;font-size:11px;color:var(--text-muted);font-weight:700;text-transform:uppercase;letter-spacing:1px;">${esc(key)}</div>`;
      html += renderSettingRows(val, prefix + '.' + key);
    } else {
      let displayVal = val;
      const type = typeof val;
      if (Array.isArray(val)) displayVal = val.join(', ') || '—';
      else if (typeof val === 'boolean') displayVal = val ? '✓ Aktif' : '✗ Pasif';
      else if (val === '' || val === null) displayVal = '—';
      const valColor = val === true ? 'color:var(--ok)' : val === false ? 'color:var(--crit)' : '';
      
      const isEditable = (parts.length === 1);
      const editButton = isEditable ? `<button type="button" class="btn btn-secondary btn-sm" style="padding: 2px 6px; font-size: 11px; margin-left: 8px;" onclick="editSettingValue('${esc(section)}', '${esc(key)}', ${type === 'boolean' ? val : `'${esc(String(val))}'`}, '${type}')">📝 Düzenle</button>` : '';

      html += `<div class="setting-row" style="display: flex; justify-content: space-between; align-items: center;">
        <span class="setting-label">${esc(key)}</span>
        <div style="display: flex; align-items: center;">
          <span class="setting-value" style="${valColor}">${esc(String(displayVal))}</span>
          ${editButton}
        </div>
      </div>`;
    }
  }
  return html;
}

async function editSettingValue(section, key, currentValue, type) {
  let newValue;
  if (type === 'boolean') {
    newValue = !currentValue;
  } else {
    const promptVal = prompt(`${section}.${key} için yeni değeri girin:`, currentValue);
    if (promptVal === null) return;
    newValue = promptVal.trim();
    if (type === 'number') {
      newValue = parseInt(newValue, 10);
      if (isNaN(newValue)) {
        alert('Lütfen geçerli bir sayı girin.');
        return;
      }
    }
  }

  try {
    const res = await fetch('/api/v1/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ Section: section, Key: key, Value: newValue })
    });
    const data = await res.json();
    if (res.ok && data.success) {
      showToast(data.message);
      loadSettings();
    } else {
      showToast(data.message, true);
    }
  } catch (e) {
    showToast('Ayarı kaydederken bağlantı hatası oluştu.', true);
  }
}

// ── Notifications Center ──
async function loadNotifications() {
  try {
    const res = await fetch('/api/v1/notifications');
    if (!res.ok) return;
    const data = await res.json();

    // Teams
    if (data.teams) {
      document.getElementById('notifTeamsUrl').value = data.teams.url || '';
      updateBadge('badgeTeams', data.teams.enabled);
    }
    // Slack
    if (data.slack) {
      document.getElementById('notifSlackUrl').value = data.slack.url || '';
      updateBadge('badgeSlack', data.slack.enabled);
    }
    // Discord
    if (data.discord) {
      document.getElementById('notifDiscordUrl').value = data.discord.url || '';
      updateBadge('badgeDiscord', data.discord.enabled);
    }
    // SMTP
    if (data.smtp) {
      document.getElementById('notifSmtpServer').value = data.smtp.server || '';
      document.getElementById('notifSmtpPort').value = data.smtp.port || 587;
      document.getElementById('notifSmtpFrom').value = data.smtp.from || '';
      document.getElementById('notifSmtpTo').value = data.smtp.to || '';
      document.getElementById('notifSmtpUser').value = data.smtp.username || '';
      document.getElementById('notifSmtpTls').checked = data.smtp.useTls !== false;
      updateBadge('badgeSmtp', !!data.smtp.server);
    }
  } catch (e) {}
}

function updateBadge(id, active) {
  const el = document.getElementById(id);
  if (!el) return;
  if (active) {
    el.textContent = 'Aktif';
    el.className = 'badge badge-ok';
  } else {
    el.textContent = 'Devre Dışı';
    el.className = 'badge badge-muted';
  }
}

async function saveNotificationChannel(channel) {
  let payload = { Channel: channel };
  if (channel === 'teams') {
    payload.Url = document.getElementById('notifTeamsUrl').value.trim();
  } else if (channel === 'slack') {
    payload.Url = document.getElementById('notifSlackUrl').value.trim();
  } else if (channel === 'discord') {
    payload.Url = document.getElementById('notifDiscordUrl').value.trim();
  } else if (channel === 'smtp') {
    payload.Server = document.getElementById('notifSmtpServer').value.trim();
    payload.Port = document.getElementById('notifSmtpPort').value.trim();
    payload.From = document.getElementById('notifSmtpFrom').value.trim();
    payload.To = document.getElementById('notifSmtpTo').value.trim();
    payload.Username = document.getElementById('notifSmtpUser').value.trim();
    payload.Password = document.getElementById('notifSmtpPass').value;
    payload.UseTls = document.getElementById('notifSmtpTls').checked;
  }

  try {
    const res = await fetch('/api/v1/notifications', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    showToast(data.message, !res.ok);
    loadNotifications();
  } catch {
    showToast('Kaydetme hatası oluştu.', true);
  }
}

async function testNotificationChannel(channel) {
  showToast(channel.toUpperCase() + ' test bildirimi gönderiliyor...');
  try {
    const res = await fetch('/api/v1/notifications/test', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ Channel: channel })
    });
    const data = await res.json();
    showToast(data.message, !res.ok);
  } catch {
    showToast('Test mesajı gönderilirken hata oluştu.', true);
  }
}

// ── New Certificate Modal ──
function openNewCertModal() { 
  document.getElementById('newCertModal').classList.add('show'); 
  toggleCertMethodFields();
}

function closeNewCertModal() { 
  document.getElementById('newCertModal').classList.remove('show'); 
  document.getElementById('newCertForm').reset(); 
}

function toggleCertMethodFields() {
  const method = document.querySelector('input[name="certMethod"]:checked').value;
  if (method === 'form') {
    document.getElementById('certFormFields').style.display = 'block';
    document.getElementById('certCsrFields').style.display = 'none';
    document.getElementById('inpDomain').required = true;
    document.getElementById('inpCsrPath').required = false;
  } else {
    document.getElementById('certFormFields').style.display = 'none';
    document.getElementById('certCsrFields').style.display = 'block';
    document.getElementById('inpDomain').required = false;
    document.getElementById('inpCsrPath').required = true;
  }
}

async function submitNewCert(e) {
  e.preventDefault();
  
  const method = document.querySelector('input[name="certMethod"]:checked').value;
  const provider = document.querySelector('input[name="certProvider"]:checked').value;
  const pfx = document.getElementById('inpPfx').value;
  
  let domain = "";
  const params = { Provider: provider };
  if (pfx) params.PfxPass = pfx;
  
  if (method === 'form') {
    domain = document.getElementById('inpDomain').value.trim();
    const wildcard = document.getElementById('inpWildcard').checked;
    const san = document.getElementById('inpSan').value.trim();
    
    if (wildcard) params.Wildcard = true;
    if (san) params.SANList = san;
  } else {
    // CSR Mode
    const csrPath = document.getElementById('inpCsrPath').value.trim();
    const backupDomain = document.getElementById('inpCsrDomain').value.trim();
    
    params.CsrPath = csrPath;
    
    // Extract a default domain name from the CSR file name if not provided
    if (backupDomain) {
      domain = backupDomain;
    } else {
      // e.g. "C:\path\request.csr" -> "request.csr" -> "request"
      const parts = csrPath.split('\\');
      const fileName = parts[parts.length - 1];
      domain = fileName.replace(/\.[^/.]+$/, "");
      if (!domain) domain = "CSR_Based_Cert";
    }
  }

  const btn = document.getElementById('btnSubmitCert');
  btn.textContent = 'Gönderiliyor...'; btn.disabled = true;
  try {
    const res = await fetch('/api/v1/action', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ Action: 'new', Domain: domain, Params: params })
    });
    const data = await res.json();
    if (res.ok) { 
      showToast('Sertifika oluşturma emri kuyruğa eklendi!'); 
      closeNewCertModal(); 
      refreshAll();
    }
    else showToast(data.message, true);
  } catch { 
    showToast('Bağlantı hatası.', true); 
  }
  finally { 
    btn.textContent = 'Kuyruğa Ekle'; btn.disabled = false; 
  }
}

// ── Refresh All ──
async function refreshAll(silent = false) {
  await loadCerts(silent);
}
