function Invoke-PSCMActionQueue {
<#
.SYNOPSIS
Pending klasorundeki tum aksiyonlari isler.
.DESCRIPTION
Her JSON dosyasini okur, ilgili PS-CertManager cmdlet'ini calistirir,
sonuca gore processed/ veya failed/ klasorune tasir.
Task Scheduler'dan her 5 dakikada bir cagirilmak uzere tasarlandi.
#>
    [CmdletBinding()]
    param()
    Write-PSCMLog -Level INFO -Message 'Action queue islenmeye baslandi.' -Source 'ActionQueue'
    $root = Get-PSCMActionRoot
    $pendingDir   = Join-Path $root 'pending'
    $processedDir = Join-Path $root 'processed'
    $failedDir    = Join-Path $root 'failed'

    $files = @(Get-ChildItem -Path $pendingDir -Filter '*.json' -EA SilentlyContinue)
    if ($files.Count -eq 0) {
        Write-PSCMLog -Level DEBUG -Message 'Pending kuyruk bos.' -Source 'ActionQueue'
        return
    }

    $lockName = 'action-queue'
    $lock = $null
    try {
        $lock = Lock-PSCMResource -Name $lockName -TimeoutSec 10

        $results = @()
        foreach ($file in $files) {
            $obj = $null
            try {
                $obj = Read-PSCMJson -Path $file.FullName
            } catch {
                Write-PSCMLog -Level ERROR -Message ('Action JSON okunamadi: ' + $file.Name) -Source 'ActionQueue'
                Move-Item -LiteralPath $file.FullName -Destination (Join-Path $failedDir $file.Name) -Force
                continue
            }
            if (-not $obj) { continue }
            $props = @($obj.PSObject.Properties.Name)
            if (-not ($props -contains 'Action') -or -not ($props -contains 'Domain')) {
                Write-PSCMLog -Level WARNING -Message ('Action dosyasi eksik alan: ' + $file.Name) -Source 'ActionQueue'
                Move-Item -LiteralPath $file.FullName -Destination (Join-Path $failedDir $file.Name) -Force
                continue
            }

            $action = [string]$obj.Action
            $domain = [string]$obj.Domain
            $params = @{}
            if ($props -contains 'Params' -and $obj.Params) {
                foreach ($p in $obj.Params.PSObject.Properties) {
                    $params[$p.Name] = $p.Value
                }
            }

            $success = $false
            $errMsg = ''
            try {
                Write-PSCMLog -Level INFO -Message ('Aksiyon calistiriliyor: ' + $action + ' ' + $domain) -Source 'ActionQueue'
                switch ($action) {
                    'new' {
                        $pArgs = @{ Domain = $domain }
                        if ($params.ContainsKey('Wildcard') -and [bool]$params['Wildcard']) { $pArgs['Wildcard'] = $true }
                        if ($params.ContainsKey('SANList') -and $params['SANList']) {
                            if ($params['SANList'] -is [string]) {
                                $pArgs['SANList'] = $params['SANList'] -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' }
                            } else {
                                $pArgs['SANList'] = [string[]]$params['SANList']
                            }
                        }
                        if ($params.ContainsKey('FriendlyName') -and $params['FriendlyName']) { $pArgs['FriendlyName'] = $params['FriendlyName'] }
                        if ($params.ContainsKey('PfxPassSecretName') -and $params['PfxPassSecretName']) {
                            $secVal = Get-PSCMSecret -Name $params['PfxPassSecretName']
                            if ($secVal) { $pArgs['PfxPass'] = $secVal }
                        } elseif ($params.ContainsKey('PfxPass') -and $params['PfxPass']) {
                            $pArgs['PfxPass'] = ConvertTo-SecureString $params['PfxPass'] -AsPlainText -Force
                        }
                        New-PSCertificate @pArgs -Confirm:$false | Out-Null
                    }
                    'renew'  { Update-PSCertificate -Domain $domain -Confirm:$false | Out-Null }
                    'test'   { Test-PSCertificate -Domain $domain | Out-Null }
                    'export' {
                        $dest = if ($params.ContainsKey('Destination')) { [string]$params['Destination'] } else { throw 'Destination gerekli.' }
                        $fmt  = if ($params.ContainsKey('Format')) { [string]$params['Format'] } else { 'all' }
                        Export-PSCertificate -Domain $domain -Destination $dest -Format $fmt | Out-Null
                    }
                    'deploy' {
                        $pArgs = @{}
                        if ($params.ContainsKey('PfxFilePath') -and $params['PfxFilePath']) { $pArgs['PfxFilePath'] = $params['PfxFilePath'] }
                        else {
                            throw 'PfxFilePath gerekli.'
                        }
                        
                        if ($params.ContainsKey('PfxPassSecretName') -and $params['PfxPassSecretName']) {
                            $secVal = Get-PSCMSecret -Name $params['PfxPassSecretName']
                            if ($secVal) { $pArgs['PfxPassword'] = $secVal }
                        } elseif ($params.ContainsKey('PfxPass') -and $params['PfxPass']) { 
                            $pArgs['PfxPassword'] = ConvertTo-SecureString $params['PfxPass'] -AsPlainText -Force
                        } else {
                            $defaultPass = Get-PSCMSecret -Name 'Certificate.DefaultPfxPassword'
                            if ($defaultPass) { $pArgs['PfxPassword'] = $defaultPass }
                        }

                        if ($params.ContainsKey('SiteName') -and $params['SiteName']) { $pArgs['SiteName'] = $params['SiteName'] }
                        else { throw 'SiteName gerekli.' }
                        
                        if ($params.ContainsKey('HostHeader') -and $params['HostHeader']) { $pArgs['HostHeader'] = $params['HostHeader'] }
                        
                        if ($params.ContainsKey('ComputerName') -and $params['ComputerName']) {
                            $pArgs['ComputerName'] = $params['ComputerName']
                            
                            if ($params.ContainsKey('DeployUsername') -and $params['DeployUsername']) {
                                $secretName = if ($params.ContainsKey('DeployPasswordSecretName') -and $params['DeployPasswordSecretName']) { $params['DeployPasswordSecretName'] } else { "DeployCred_$($params['ComputerName'])" }
                                $credSecret = Get-PSCMSecret -Name $secretName
                                if ($credSecret) {
                                    $cred = New-Object System.Management.Automation.PSCredential($params['DeployUsername'], $credSecret)
                                    $pArgs['Credential'] = $cred
                                    Write-PSCMLog -Level INFO -Message ("Uzak sunucu ($($params['ComputerName'])) icin $secretName kullanilarak kimlik dogrulamasi yapiliyor.") -Source 'ActionQueue'
                                } else {
                                    Write-PSCMLog -Level WARNING -Message ("Uzak sunucu baglantisi icin '$secretName' adinda secret bulunamadi! Islem mevcut kullanici yetkisi ile denenecek.") -Source 'ActionQueue'
                                }
                            }
                            
                            Invoke-RemoteIISDeployment @pArgs | Out-Null
                        } else {
                            $cert = Install-CertificateToStore -PfxFilePath $pArgs['PfxFilePath'] -PfxPassword $pArgs['PfxPassword']
                            
                            $bArgs = @{
                                SiteName = $pArgs['SiteName']
                                Thumbprint = $cert.Thumbprint
                            }
                            if ($pArgs.ContainsKey('HostHeader') -and $pArgs['HostHeader']) { 
                                $bArgs['HostHeader'] = $pArgs['HostHeader']
                                $bArgs['RequireSNI'] = $true
                            }
                            Set-IISCertificateBinding @bArgs | Out-Null
                        }
                    }
                    'remove' { Remove-PSCertificate -Domain $domain -Confirm:$false | Out-Null }
                    'repair' {
                        $pArgs = @{ Domain = $domain }
                        if ($params.ContainsKey('PfxPassSecretName') -and $params['PfxPassSecretName']) {
                            $secVal = Get-PSCMSecret -Name $params['PfxPassSecretName']
                            if ($secVal) { $pArgs['PfxPass'] = $secVal }
                        } elseif ($params.ContainsKey('PfxPass') -and $params['PfxPass']) { 
                            $pArgs['PfxPass'] = ConvertTo-SecureString $params['PfxPass'] -AsPlainText -Force
                        }
                        Repair-PSCMCertificatePfx @pArgs -Confirm:$false | Out-Null
                    }
                    default  { throw ('Bilinmeyen aksiyon: ' + $action) }
                }
                $success = $true
            } catch {
                $errMsg = $_.Exception.Message
                Write-PSCMLog -Level ERROR -Message ('Aksiyon hatasi (' + $action + ' ' + $domain + '): ' + $errMsg) -Source 'ActionQueue'
            }

            $updated = $obj | Select-Object *
            $updated | Add-Member -NotePropertyName 'ProcessedAt' -NotePropertyValue (Get-Date).ToString('o') -Force
            $statusVal = if ($success) { 'processed' } else { 'failed' }
            $updated | Add-Member -NotePropertyName 'Status' -NotePropertyValue $statusVal -Force
            if (-not $success) {
                $updated | Add-Member -NotePropertyName 'Error' -NotePropertyValue $errMsg -Force
            }

            $targetDir = if ($success) { $processedDir } else { $failedDir }
            $newPath = Join-Path $targetDir $file.Name
            $updated | Write-PSCMJson -Path $newPath
            Remove-Item -LiteralPath $file.FullName -Force -EA SilentlyContinue

            $results += [PSCustomObject]@{ Action=$action; Domain=$domain; Success=$success; Error=$errMsg }
        }

        $rcount = @($results).Count
        Write-PSCMLog -Level INFO -Message "Action queue islendi: $rcount aksiyon" -Source 'ActionQueue'
        return $results
    } catch {
        Write-PSCMLog -Level ERROR -Message ('Action queue islem hatasi: ' + $_.Exception.Message) -Source 'ActionQueue'
        throw
    } finally {
        if ($lock) { Unlock-PSCMResource -Name $lockName }
    }
}
