﻿function Set-PSCMSecret {
<#
.SYNOPSIS
Secret'i vault'a kaydeder.
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][object]$Value
    )
    if ($Value -is [System.Security.SecureString]) { $secure = $Value }
    elseif ($Value -is [string]) { $secure = ConvertTo-SecureString -String $Value -AsPlainText -Force }
    else { throw (New-PSCMException -Message 'Value SecureString veya string olmalidir.' -Category 'Dogrulama' -ErrorCode 'PSCM-4001') }
    Set-Secret -Name $Name -SecureStringSecret $secure -Vault $script:PSCMVaultName
    Write-PSCMLog -Level INFO -Message ('Secret kaydedildi: ' + $Name) -Source 'Security'
}
