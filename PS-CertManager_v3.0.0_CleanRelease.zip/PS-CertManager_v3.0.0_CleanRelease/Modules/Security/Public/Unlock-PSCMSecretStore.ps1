﻿function Unlock-PSCMSecretStore {
<#
.SYNOPSIS
SecretStore vault kilidini oturum boyu acar.
.DESCRIPTION
Vault Authentication moduna gore davranir:
  - Authentication=None  -> Islem yapmaz, vault zaten aciktir.
  - Authentication=Password -> Kilitli ise Unlock-SecretStore ile parola sorar.
    Basari halinde oturum boyunca (PasswordTimeout kadar) tekrar sormaz.
.PARAMETER Silent
Vault yoksa veya kilitli degilse hicbir sey yapmaz, hata firlatmaz.
.EXAMPLE
Unlock-PSCMSecretStore -Silent
#>
    [CmdletBinding()]
    param([switch]$Silent)

    $vault = Get-SecretVault -Name $script:PSCMVaultName -EA SilentlyContinue
    if (-not $vault) {
        if (-not $Silent) {
            Write-PSCMLog -Level DEBUG -Message 'Vault kayitli degil, Unlock atlandi.' -Source 'Security'
        }
        return $false
    }

    try {
        Import-Module Microsoft.PowerShell.SecretStore -EA Stop
        $cfg = Get-SecretStoreConfiguration -EA SilentlyContinue
        if ($cfg -and $cfg.Authentication -eq 'None') {
            Write-PSCMLog -Level DEBUG -Message 'SecretStore Authentication=None, kilit yok.' -Source 'Security'
            return $true
        }
    } catch {
        if (-not $Silent) {
            Write-PSCMLog -Level WARNING -Message ('SecretStore config okunamadi: ' + $_.Exception.Message) -Source 'Security'
        }
    }

    $needsUnlock = $false
    try {
        Get-SecretInfo -Vault $script:PSCMVaultName -EA Stop | Out-Null
    } catch {
        if ($_.Exception.Message -match 'password' -or $_.Exception.Message -match 'lock') {
            $needsUnlock = $true
        }
    }

    if (-not $needsUnlock) {
        Write-PSCMLog -Level DEBUG -Message 'SecretStore zaten acik.' -Source 'Security'
        return $true
    }

    Write-Host ''
    Write-Host '  SecretStore vault kilitli. Oturum boyunca acmak icin parola girin.' -ForegroundColor Yellow
    try {
        Unlock-SecretStore -EA Stop
        Write-PSCMLog -Level INFO -Message 'SecretStore vault kilidi acildi (oturum icin).' -Source 'Security'
        Write-Host '  [OK] Vault acildi. Oturum boyunca tekrar sorulmayacak.' -ForegroundColor Green
        return $true
    } catch {
        Write-PSCMLog -Level ERROR -Message ('SecretStore kilit acma hatasi: ' + $_.Exception.Message) -Source 'Security'
        Write-Host ('  [HATA] ' + $_.Exception.Message) -ForegroundColor Red
        return $false
    }
}
