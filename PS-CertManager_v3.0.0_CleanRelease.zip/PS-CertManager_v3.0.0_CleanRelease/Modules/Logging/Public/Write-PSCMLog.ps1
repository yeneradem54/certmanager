function Write-PSCMLog {
<#
.SYNOPSIS
Merkezi log kaydi.
#>
    [CmdletBinding()]
    param(
        [ValidateSet('DEBUG','INFO','WARNING','ERROR')][string]$Level = 'INFO',
        [Parameter(Mandatory)][string]$Message,
        [string]$Source = 'PSCM',
        [switch]$NoConsole
    )
    try {
        $priority = $script:PSCMLogConfig.LevelPriority[$Level]
        $minPri   = $script:PSCMLogConfig.LevelPriority[$script:PSCMLogConfig.MinimumLevel]
        if ($priority -lt $minPri) { return }
        $ts      = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff')
        $safeMsg = $Message | ConvertTo-PSCMSafeString
        $line    = ('{0} [{1,-7}] [{2}] {3}' -f $ts,$Level,$Source,$safeMsg)
        $logDir  = Get-PSCMPath -Name Logs
        $logFile = Join-Path $logDir ('pscm-{0}.log' -f (Get-Date -Format 'yyyyMMdd'))
        if (Test-Path -LiteralPath $logFile) {
            $sz = (Get-Item -LiteralPath $logFile).Length / 1MB
            if ($sz -ge $script:PSCMLogConfig.MaxSizeMB) {
                Invoke-PSCMLogRotation -LogFile $logFile
            }
        }
        
        # Windows Event Log Entegrasyonu (v3)
        if ($Level -in @('ERROR', 'WARNING')) {
            try {
                if (-not [System.Diagnostics.EventLog]::SourceExists('PS-CertManager')) {
                    New-EventLog -LogName Application -Source 'PS-CertManager' -ErrorAction Stop
                }
                $entryType = if ($Level -eq 'ERROR') { 'Error' } else { 'Warning' }
                Write-EventLog -LogName Application -Source 'PS-CertManager' -EventId 1000 -EntryType $entryType -Message $Message -ErrorAction Stop
            } catch {
                $evtErr = "EventLog yazilamadi: " + $_.Exception.Message
                $evtLine = ('{0} [{1,-7}] [{2}] {3}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'), 'WARNING', 'PSCM-Log', $evtErr)
                Add-Content -LiteralPath $logFile -Value $evtLine -Encoding UTF8 -ErrorAction SilentlyContinue
            }
        }
        Add-Content -LiteralPath $logFile -Value $line -Encoding UTF8
        if ($script:PSCMLogConfig.ConsoleOutput -and -not $NoConsole) {
            switch ($Level) {
                'DEBUG'   { Write-Verbose $line }
                'INFO'    { Write-Host $line -ForegroundColor Gray }
                'WARNING' { Write-Host $line -ForegroundColor Yellow }
                'ERROR'   { Write-Host $line -ForegroundColor Red }
            }
        }
    } catch {
        Write-Host ('LOG YAZIM HATASI: ' + $_.Exception.Message) -ForegroundColor Red
    }
}
