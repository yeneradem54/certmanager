function Test-PSAzure {
<#
.SYNOPSIS
Azure baglantisini ve tum kayitli DNS zone erisimlerini test eder.
.DESCRIPTION
Baglantiyi kurar, ardindan Get-PSCMDnsZones ile listeledigi her zone icin
Get-AzDnsZone dener. Her zone icin OK/HATA raporlar.
#>
    [CmdletBinding()]
    param()
    $connectOk = $false
    $connectDetail = ''
    $zoneResults = @()
    try {
        $ctx = Get-AzContext -EA SilentlyContinue
        if (-not $ctx) { $ctx = Connect-PSCMAzure }
        $connectOk = $true
        $connectDetail = 'Tenant: ' + $ctx.Tenant.Id + ' / Sub: ' + $ctx.Subscription.Name
    } catch {
        return [PSCustomObject]@{ Durum = $false; Aciklama = 'Azure baglanti hatasi: ' + $_.Exception.Message; Zonelar = @() }
    }
    try {
        Import-Module Az.Dns -EA Stop
        $zones = @(Get-PSCMDnsZones)
        if ($zones.Count -eq 0) {
            return [PSCustomObject]@{ Durum = $connectOk; Aciklama = $connectDetail + ' | Kayitli zone yok.'; Zonelar = @() }
        }
        foreach ($z in $zones) {
            $ok = $false; $msg = ''
            try {
                $az = Get-AzDnsZone -ResourceGroupName $z.ResourceGroup -Name $z.Name -EA Stop
                $ok = $null -ne $az
                $msg = if ($ok) { 'OK - RS: ' + $az.NumberOfRecordSets } else { 'Bulunamadi' }
            } catch {
                $msg = 'HATA: ' + $_.Exception.Message
            }
            $stat = if ($ok) { 'OK' } else { 'HATA' }
            $zoneResults += [PSCustomObject]@{
                Zone          = $z.Name
                ResourceGroup = $z.ResourceGroup
                Durum         = $stat
                Detay         = $msg
            }
        }
    } catch {
        return [PSCustomObject]@{ Durum = $connectOk; Aciklama = $connectDetail + ' | Zone test hatasi: ' + $_.Exception.Message; Zonelar = $zoneResults }
    }
    $failCount = @($zoneResults | Where-Object { $_.Durum -ne 'OK' }).Count
    $allOk = ($failCount -eq 0)
    return [PSCustomObject]@{
        Durum    = ($connectOk -and $allOk)
        Aciklama = $connectDetail
        Zonelar  = $zoneResults
    }
}
