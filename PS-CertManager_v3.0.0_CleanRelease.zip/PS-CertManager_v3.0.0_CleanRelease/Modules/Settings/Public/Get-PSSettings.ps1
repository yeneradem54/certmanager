﻿function Get-PSSettings {
<#
.SYNOPSIS
settings.json okur.
#>
    [CmdletBinding()]
    param([string]$Section)
    $path = Join-Path (Get-PSCMPath -Name Config) 'settings.json'
    if (-not (Test-Path -LiteralPath $path)) { Initialize-PSCMSettings }
    $obj = Read-PSCMJson -Path $path
    if ($Section) {
        if ($obj.PSObject.Properties.Name -contains $Section) { return $obj.$Section }
        throw (New-PSCMException -Message ("Ayar bolumu bulunamadi: " + $Section) -Category 'Yapilandirma' -ErrorCode 'PSCM-3002')
    }
    return $obj
}
