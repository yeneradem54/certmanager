# PS-CertManager ACME saglayici soyutlamasi
# v2.2.1 - PfxPass SecureString -> plain string donusum duzeltildi.

class PSCMAcmeContract {
    [string]$Name
    [string]$DirectoryUrl
    PSCMAcmeContract([string]$name,[string]$url) { $this.Name = $name; $this.DirectoryUrl = $url }
    [object] Register([string]$email) { throw 'Register icin somut sinif gerekli.' }
    [object] NewCertificate([hashtable]$params) { throw 'NewCertificate icin somut sinif gerekli.' }
    [object] RenewCertificate([hashtable]$params) { throw 'RenewCertificate icin somut sinif gerekli.' }
}

class PSCMPoshAcmeProvider : PSCMAcmeContract {
    PSCMPoshAcmeProvider([string]$name,[string]$url) : base($name,$url) {}

    [object] Register([string]$email) {
        Import-Module Posh-ACME -EA Stop
        Set-PAServer $this.DirectoryUrl -EA Stop
        $acct = Get-PAAccount -EA SilentlyContinue
        if (-not $acct) { $acct = New-PAAccount -Contact $email -AcceptTOS -EA Stop }
        return $acct
    }

    # v2.2.1 FIX: SecureString -> plain text sadece Posh-ACME cagrisi icin.
    # Posh-ACME'nin -PfxPass parametresi [string] tipinde.
    # SecureString verirsek PowerShell .ToString() cagirir ve tip adini dondurur.
    [object] NewCertificate([hashtable]$params) {
        Import-Module Posh-ACME -EA Stop
        $pArgs = @{
            AZSubscriptionId = $params.SubscriptionId
            AZTenantId       = $params.TenantId
        }
        if ($params.ContainsKey('AZAppCred')) { $pArgs['AZAppCred'] = $params.AZAppCred }

        $pfxPlain = $null
        $bstr     = [IntPtr]::Zero
        try {
            $pfxSs = $params.PfxPass
            if ($pfxSs -is [System.Security.SecureString]) {
                $bstr     = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($pfxSs)
                $pfxPlain = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
            } elseif ($pfxSs -is [string]) {
                $pfxPlain = $pfxSs
            } else {
                throw 'PfxPass parametresi SecureString veya string olmalidir.'
            }
            if ([string]::IsNullOrEmpty($pfxPlain)) { throw 'PfxPass bos olamaz.' }

            Write-Host "DNS-01 dogrulamasi baslatiliyor. DNS kayitlarinin Azure DNS uzerinde yayilmasi ve ACME sunucusu (Let's Encrypt) tarafindan dogrulanmasi birkac dakika surebilir. Lutfen bekleyin..." -ForegroundColor Yellow
            return New-PACertificate -Domain $params.Domain -DnsPlugin Azure -PluginArgs $pArgs -AcceptTOS -PfxPass $pfxPlain -Install:$false -Force
        } finally {
            if ($bstr -ne [IntPtr]::Zero) {
                [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
            }
            $pfxPlain = $null
            [System.GC]::Collect()
        }
    }

    [object] RenewCertificate([hashtable]$params) {
        Import-Module Posh-ACME -EA Stop
        Write-Host "DNS-01 yenileme dogrulamasi baslatiliyor. DNS kayitlarinin Azure DNS uzerinde yayilmasi ve ACME sunucusu (Let's Encrypt) tarafindan dogrulanmasi birkac dakika surebilir. Lutfen bekleyin..." -ForegroundColor Yellow
        try {
            return Submit-Renewal -MainDomain $params.Domain -Force
        } catch {
            Write-Host ("Submit-Renewal basarisiz oldu: " + $_.Exception.Message + ". Sifirdan alim (Fallback) deneniyor...") -ForegroundColor Yellow
            return $this.NewCertificate($params)
        }
    }
}
