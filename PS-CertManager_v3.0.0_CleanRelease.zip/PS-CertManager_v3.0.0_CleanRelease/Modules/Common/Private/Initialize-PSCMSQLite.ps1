function Initialize-PSCMSQLite {
<#
.SYNOPSIS
SQLite veritabanini olusturur ve eski JSON verilerini (varsa) migrate eder (v3).
#>
    [CmdletBinding()]
    param()
    Import-Module PSSQLite -ErrorAction Stop
    $dbPath = Join-Path (Get-PSCMPath -Name State) "pscm.db"
    
    $query = @"
    CREATE TABLE IF NOT EXISTS certificates (
        Domain TEXT PRIMARY KEY,
        Wildcard INTEGER,
        Issuer TEXT,
        Thumbprint TEXT,
        NotBefore TEXT,
        NotAfter TEXT,
        FriendlyName TEXT,
        Path TEXT,
        SourceFolder TEXT,
        CreatedAt TEXT,
        RenewedAt TEXT
    );
    CREATE TABLE IF NOT EXISTS deployments (
        Id INTEGER PRIMARY KEY AUTOINCREMENT,
        Domain TEXT NOT NULL,
        Target TEXT NOT NULL,
        ComputerName TEXT,
        SiteName TEXT NOT NULL,
        HostHeader TEXT,
        StoreLocation TEXT,
        StoreName TEXT,
        DeployUsername TEXT
    );
"@
    Invoke-SqliteQuery -DataSource $dbPath -Query $query | Out-Null
    
    $jsonPath = Join-Path (Get-PSCMPath -Name State) "certificates.json"
    if (Test-Path $jsonPath) {
        Write-PSCMLog -Level INFO -Message "SQLite gocu (migration) baslatildi..." -Source 'DAL'
        $data = Read-PSCMJson -Path $jsonPath
        if ($data -and $null -ne $data.PSObject -and $null -ne $data.PSObject.Properties -and $data.PSObject.Properties.Name -contains 'certificates' -and $data.certificates) {
            foreach ($c in $data.certificates) {
                if ($null -eq $c) { continue }
                $cProps = if ($null -ne $c.PSObject -and $null -ne $c.PSObject.Properties) { @($c.PSObject.Properties.Name) } else { @() }
                $wc = if ($cProps -contains 'Wildcard' -and $c.Wildcard) { 1 } else { 0 }
                $insert = @"
                INSERT OR IGNORE INTO certificates (Domain, Wildcard, Issuer, Thumbprint, NotBefore, NotAfter, FriendlyName, Path, SourceFolder, CreatedAt, RenewedAt)
                VALUES (@Domain, @Wildcard, @Issuer, @Thumbprint, @NotBefore, @NotAfter, @FriendlyName, @Path, @SourceFolder, @CreatedAt, @RenewedAt);
"@
                $p = @{
                    Domain = if ($cProps -contains 'Domain') { $c.Domain } else { $null }
                    Wildcard = $wc
                    Issuer = if ($cProps -contains 'Issuer') { $c.Issuer } else { $null }
                    Thumbprint = if ($cProps -contains 'Thumbprint') { $c.Thumbprint } else { $null }
                    NotBefore = if ($cProps -contains 'NotBefore') { $c.NotBefore } else { $null }
                    NotAfter = if ($cProps -contains 'NotAfter') { $c.NotAfter } else { $null }
                    FriendlyName = if ($cProps -contains 'FriendlyName') { $c.FriendlyName } else { $null }
                    Path = if ($cProps -contains 'Path') { $c.Path } else { $null }
                    SourceFolder = if ($cProps -contains 'SourceFolder') { $c.SourceFolder } else { $null }
                    CreatedAt = if ($cProps -contains 'CreatedAt') { $c.CreatedAt } else { $null }
                    RenewedAt = if ($cProps -contains 'RenewedAt') { $c.RenewedAt } else { $null }
                }
                Invoke-SqliteQuery -DataSource $dbPath -Query $insert -SqlParameters $p | Out-Null
            }
        }
        Move-Item -LiteralPath $jsonPath -Destination ($jsonPath + ".bak") -Force
        Write-PSCMLog -Level INFO -Message "SQLite gocu basariyla tamamlandi. Eski json yedege alindi." -Source 'DAL'
    }
    
    $deployJsonPath = Join-Path (Get-PSCMPath -Name Config) "Deployments.json"
    if (Test-Path $deployJsonPath) {
        Write-PSCMLog -Level INFO -Message "Deployments.json SQLite gocu baslatildi..." -Source 'DAL'
        $deploys = Read-PSCMJson -Path $deployJsonPath
        if ($deploys) {
            foreach ($d in @($deploys)) {
                if ($null -eq $d) { continue }
                $insert = @"
                INSERT INTO deployments (Domain, Target, ComputerName, SiteName, HostHeader, StoreLocation, StoreName, DeployUsername)
                VALUES (@Domain, @Target, @ComputerName, @SiteName, @HostHeader, @StoreLocation, @StoreName, @DeployUsername);
"@
                $pProps = if ($null -ne $d.psobject -and $null -ne $d.psobject.Properties) { @($d.psobject.Properties.Name) } else { @() }
                $p = @{
                    Domain = if ($pProps -contains 'Domain') { $d.Domain } else { $null }
                    Target = if ($pProps -contains 'Target') { $d.Target } else { 'IIS' }
                    ComputerName = if ($pProps -contains 'ComputerName') { $d.ComputerName } else { $null }
                    SiteName = if ($pProps -contains 'SiteName') { $d.SiteName } else { $null }
                    HostHeader = if ($pProps -contains 'HostHeader') { $d.HostHeader } else { $null }
                    StoreLocation = if ($pProps -contains 'StoreLocation') { $d.StoreLocation } else { 'LocalMachine' }
                    StoreName = if ($pProps -contains 'StoreName') { $d.StoreName } else { 'WebHosting' }
                    DeployUsername = if ($pProps -contains 'DeployUsername') { $d.DeployUsername } else { $null }
                }
                Invoke-SqliteQuery -DataSource $dbPath -Query $insert -SqlParameters $p | Out-Null
            }
        }
        Move-Item -LiteralPath $deployJsonPath -Destination ($deployJsonPath + ".bak") -Force
        Write-PSCMLog -Level INFO -Message "Deployments SQLite gocu tamamlandi." -Source 'DAL'
    }
}
