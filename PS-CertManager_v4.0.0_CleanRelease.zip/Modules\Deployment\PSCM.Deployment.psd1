@{
    RootModule = 'PSCM.Deployment.psm1'
    ModuleVersion = '4.0.0'
    GUID = 'b4b2f2c2-150e-4cdb-94cc-599a1bd816a2'
    CompatiblePSEditions = @('Desktop', 'Core')
    Author = 'PS-CertManager Ekibi'
    CompanyName = 'PS-CertManager'
    Copyright = '(c) 2026 PS-CertManager. Tum haklari saklidir.'
    Description = 'PS-CertManager Deployment Modülü (IIS, Nginx, Apache ve Uzak Sunucu)'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Install-CertificateToStore', 'Set-IISCertificateBinding', 'Invoke-RemoteIISDeployment', 'Get-PSCMDeploymentConfig', 'Get-PSCMIISBinding', 'Set-NginxApacheBinding')
}
