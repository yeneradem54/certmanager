function Get-PSCMActionQueue {
<#
.SYNOPSIS
Action queue durumunu listeler.
.PARAMETER Status
pending, processed, failed, all
#>
    [CmdletBinding()]
    param(
        [ValidateSet('pending','processed','failed','all')]
        [string]$Status = 'all'
    )
    $root = Get-PSCMActionRoot
    $folders = @()
    if ($Status -eq 'all') {
        $folders = @('pending','processed','failed')
    } else {
        $folders = @($Status)
    }
    $result = New-Object System.Collections.Generic.List[object]
    foreach ($f in $folders) {
        $dir = Join-Path $root $f
        $files = Get-ChildItem -Path $dir -Filter '*.json' -EA SilentlyContinue
        foreach ($file in $files) {
            try {
                $obj = Read-PSCMJson -Path $file.FullName
                if ($obj) {
                    $props = @($obj.PSObject.Properties.Name)
                    $entry = [PSCustomObject]@{
                        Id        = if ($props -contains 'Id') { $obj.Id } else { $file.BaseName }
                        Action    = if ($props -contains 'Action') { $obj.Action } else { '?' }
                        Domain    = if ($props -contains 'Domain') { $obj.Domain } else { '?' }
                        Params    = if ($props -contains 'Params') { $obj.Params } else { $null }
                        CreatedAt = if ($props -contains 'CreatedAt') { $obj.CreatedAt } else { $file.CreationTime }
                        Status    = $f
                        Source    = if ($props -contains 'Source') { $obj.Source } else { 'unknown' }
                        User      = if ($props -contains 'User') { $obj.User } else { 'unknown' }
                        FilePath  = $file.FullName
                        Error     = if ($props -contains 'Error') { $obj.Error } else { '' }
                    }
                    $result.Add($entry)
                }
            } catch {
                Write-PSCMLog -Level WARNING -Message ('Action dosyasi okunamadi: ' + $file.Name) -Source 'ActionQueue'
            }
        }
    }
    return ($result | Sort-Object CreatedAt -Descending)
}
