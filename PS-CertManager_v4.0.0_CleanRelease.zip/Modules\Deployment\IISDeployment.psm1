#Requires -Version 5.1
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'

<#
.SYNOPSIS
PS-CertManager IIS ve Web Dagitim Modulu (Geriye Donuk Uyumluluk ve Uzak Dagitim Paketi).
#>

# Private helper fonksiyonlari yukle
$privateDir = Join-Path $PSScriptRoot 'Private'
if (Test-Path $privateDir) {
    Get-ChildItem -Path $privateDir -Filter '*.ps1' -ErrorAction SilentlyContinue | ForEach-Object {
        . $_.FullName
    }
}

# Public fonksiyonlari yukle
$publicDir = Join-Path $PSScriptRoot 'Public'
if (Test-Path $publicDir) {
    Get-ChildItem -Path $publicDir -Filter '*.ps1' -ErrorAction SilentlyContinue | ForEach-Object {
        . $_.FullName
    }
}

Export-ModuleMember -Function @(
    'Install-CertificateToStore',
    'Set-IISCertificateBinding',
    'Invoke-RemoteIISDeployment',
    'Get-PSCMDeploymentConfig',
    'Get-PSCMIISBinding',
    'Set-NginxApacheBinding'
)
