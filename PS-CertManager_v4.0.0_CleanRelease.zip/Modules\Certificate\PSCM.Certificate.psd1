@{
    RootModule = 'PSCM.Certificate.psm1'
    ModuleVersion = '4.0.0'
    GUID = '99d34691-8077-4f76-9e42-b366098d5ef7'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager Sertifika Yasam Dongusu Modulu'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Get-PSCertificate','New-PSCertificate','Update-PSCertificate','Remove-PSCertificate','Export-PSCertificate','Test-PSCertificate','Repair-PSCMCertificatePfx')
}
