#Requires -Version 5.1
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'

$script:PSCMRequiredModules = @(
    @{ Name='Posh-ACME';                             MinVersion='4.0.0';  Purpose='ACME sertifika istemcisi' },
    @{ Name='Az.Accounts';                           MinVersion='2.10.0'; Purpose='Azure kimlik dogrulama' },
    @{ Name='Az.Resources';                          MinVersion='6.0.0';  Purpose='Azure kaynak yonetimi' },
    @{ Name='Az.Dns';                                MinVersion='1.1.0';  Purpose='Azure DNS Zone yonetimi' },
    @{ Name='Microsoft.PowerShell.SecretManagement'; MinVersion='1.1.2';  Purpose='Guvenli kasa yonetimi' },
    @{ Name='Microsoft.PowerShell.SecretStore';      MinVersion='1.0.6';  Purpose='Yerel guvenli kasa' },
    @{ Name='PSSQLite';                              MinVersion='1.1.0';  Purpose='SQLite v3 State Yonetimi' }
)
Get-ChildItem -Path (Join-Path $PSScriptRoot 'Public') -Filter '*.ps1' -EA SilentlyContinue | ForEach-Object { . $_.FullName }
Export-ModuleMember -Function @('Initialize-PSCertManager','Get-PSInfrastructure','Repair-PSInfrastructure','Start-PSCMConfigWizard')
