﻿@{
    RootModule = 'PSCM.ACME.psm1'
    ModuleVersion = '2.1.0'
    GUID = '77777777-7777-7777-7777-777777777777'
    Author = 'PS-CertManager Ekibi'
    Description = 'PS-CertManager ACME (Posh-ACME) Modulu'
    PowerShellVersion = '5.1'
    CompatiblePSEditions = @('Desktop','Core')
    FunctionsToExport = @('Initialize-PSCMAcmeProvider','New-PSCMAcmeCertificate','Update-PSCMAcmeCertificate')
}
