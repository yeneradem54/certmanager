function Invoke-MenuLocalCAPermissions {
    Clear-Host
    Show-PSCMBanner
    Write-Host '  --- LOCAL CA (ADCS) IZIN VE YETKI YONETIMI ---' -ForegroundColor Yellow
    Write-Host ''
    
    $cred = $null
    $templates = @()
    
    try {
        Write-Host "Active Directory ortamindaki sertifika sablonlari taranirken lutfen bekleyin..." -ForegroundColor Cyan
        $rootDse = [ADSI]"LDAP://RootDSE"
        $configContext = $rootDse.Properties["configurationNamingContext"].Value
        if (-not $configContext) { throw "RootDSE erisimi basarisiz." }
        
        $templatePath = "LDAP://CN=Certificate Templates,CN=Public Key Services,CN=Services,$configContext"
        $templatesContainer = [ADSI]$templatePath
        
        # Sadece okumayi test etmek icin child kontrolu
        $childCount = $templatesContainer.Children.Count
    } catch {
        Write-Host ""
        Write-Host "Mevcut kullanici yetkilerinizle ADCS sablonlari okunamadi veya erisim reddedildi." -ForegroundColor Yellow
        Write-Host "Lutfen Root Domain (Kök Alan Adi) yetkili hesabinizin (Domain Admin vb.) bilgilerini girin." -ForegroundColor White
        Write-Host ""
        $cred = Get-Credential -Message "Active Directory Erisimi - Yetkili Hesap"
        if (-not $cred) { return }
        
        try {
            Write-Host "Yetkili hesap ile tekrar baglaniliyor..." -ForegroundColor Cyan
            $rootDse = New-Object System.DirectoryServices.DirectoryEntry("LDAP://RootDSE", $cred.UserName, $cred.GetNetworkCredential().Password)
            $configContext = $rootDse.Properties["configurationNamingContext"].Value
            $templatePath = "LDAP://CN=Certificate Templates,CN=Public Key Services,CN=Services,$configContext"
            $templatesContainer = New-Object System.DirectoryServices.DirectoryEntry($templatePath, $cred.UserName, $cred.GetNetworkCredential().Password)
        } catch {
            Write-Host "Girilen yetkili hesapla da baglanti kurulamadi: $_" -ForegroundColor Red
            Pause-PSCM
            return
        }
    }
    
    foreach ($child in $templatesContainer.Children) {
        $tName = $child.Name
        $tDisp = $child.Properties["displayName"].Value
        if (-not $tDisp) { $tDisp = $tName }
        $templates += [PSCustomObject]@{ Name = $tName; DisplayName = $tDisp }
    }
    
    if ($templates.Count -eq 0) {
        Write-Host "Active Directory icerisinde hicbir sertifika sablonu bulunamadi." -ForegroundColor Red
        Pause-PSCM
        return
    }
    
    $templates = $templates | Sort-Object DisplayName
    
    Clear-Host
    Show-PSCMBanner
    Write-Host '>> Local CA (ADCS) Izin ve Yetki Yonetimi' -ForegroundColor Yellow
    Write-Host ''
    Write-Host "Asagidaki listeden erisim izni (Enroll) tanimlanacak sablonun numarasini secin:" -ForegroundColor White
    Write-Host ''
    
    for ($i = 0; $i -lt $templates.Count; $i++) {
        Write-Host ("  {0,2}) {1} ({2})" -f ($i+1), $templates[$i].DisplayName, $templates[$i].Name)
    }
    Write-Host ''
    Write-Host '  0) Iptal / Cikis' -ForegroundColor DarkGray
    Write-Host ''
    
    $selection = Read-Host "Sablon Numarasi [1-$($templates.Count)]"
    if ($selection -eq '0' -or -not $selection) { return }
    
    $idx = 0
    if (-not ([int]::TryParse($selection, [ref]$idx)) -or $idx -lt 1 -or $idx -gt $templates.Count) {
        Write-Host "Gecersiz secim!" -ForegroundColor Red
        Pause-PSCM
        return
    }
    
    $selectedTemplate = $templates[$idx-1].Name
    
    try {
        Write-Host "Yetkilendirme basliyor: $selectedTemplate" -ForegroundColor Cyan
        if ($cred) {
            Repair-PSCMLocalCAPermissions -TemplateName $selectedTemplate -Credential $cred
        } else {
            Repair-PSCMLocalCAPermissions -TemplateName $selectedTemplate
        }
        Write-Host "Islem basariyla tamamlandi!" -ForegroundColor Green
    } catch {
        # Catch unauthorized access for write
        Write-Host "Mevcut hesabin okuma yetkisi vardi ancak yazma yetkisi YOK (Erisim Reddedildi)!" -ForegroundColor Yellow
        $cred = Get-Credential -Message "Sablon Guncelleme Icin Root Domain Admin Bilgilerini Girin"
        if (-not $cred) { return }
        try {
            Repair-PSCMLocalCAPermissions -TemplateName $selectedTemplate -Credential $cred
            Write-Host "Islem basariyla tamamlandi!" -ForegroundColor Green
        } catch {
            Write-Host "Hata: $_" -ForegroundColor Red
        }
    }
    Pause-PSCM
}
