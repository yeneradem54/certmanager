﻿function New-PSCMException {
<#
.SYNOPSIS
PSCM ozel istisna uretir.
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Message,
        [ValidateSet('Genel','ACME','Azure','Yapilandirma','Dogrulama','Guvenlik')]
        [string]$Category = 'Genel',
        [string]$ErrorCode = 'PSCM-0000'
    )
    switch ($Category) {
        'ACME'         { return (New-Object PSCMAcmeException($Message)) }
        'Azure'        { return (New-Object PSCMAzureException($Message)) }
        'Yapilandirma' { return (New-Object PSCMConfigException($Message)) }
        'Dogrulama'    { return (New-Object PSCMValidationException($Message)) }
        'Guvenlik'     { return (New-Object PSCMSecurityException($Message)) }
        default        { return (New-Object PSCMException($Message,$Category,$ErrorCode)) }
    }
}
