function Invoke-MenuActionQueue {
    Show-PSCMBanner
    Write-Host '  --- ISLEM KUYRUGU (ACTION QUEUE) ---' -ForegroundColor Yellow
    Write-Host ''
    try {
        $pend = @(Get-PSCMActionQueue -Status pending)
        $proc = @(Get-PSCMActionQueue -Status processed)
        $fail = @(Get-PSCMActionQueue -Status failed)
        Write-Host ('Bekleyen: ' + $pend.Count + ' | Islenen: ' + $proc.Count + ' | Hatali: ' + $fail.Count) -ForegroundColor Cyan
        if ($pend.Count -gt 0) {
            $pend | Format-Table Action,Domain,CreatedAt,Source,User -AutoSize | Out-String -Stream | ForEach-Object { Write-Host $_ }
        }
    } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
    Write-Host ''
    Write-Host '  [I] Hemen Isle   [E] Yeni Aksiyon Ekle   [T] Kuyrugu Temizle' -ForegroundColor Cyan
    Write-Host ''
    Write-Host '  Enter) Ana Menuye Don' -ForegroundColor DarkGray
    Write-Host ''
    $sel = Read-Host 'Islem'
    if (-not $sel) { return }
    switch ($sel.ToUpper()) {
        'I' {
            try {
                $r = @(Invoke-PSCMActionQueue)
                if ($r.Count -gt 0) { $r | Format-Table Action,Domain,Success,Error -AutoSize | Out-String -Stream | ForEach-Object { Write-Host $_ } }
                else { Write-Host 'Kuyruk bostu.' -ForegroundColor DarkGray }
            } catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
        }
        'E' {
            $act = Read-Host 'Aksiyon (renew/export/test/remove)'
            $dom = Read-Host 'Domain'
            try { Add-PSCMAction -Action $act -Domain $dom | Out-Null; Write-Host 'Eklendi.' -ForegroundColor Green }
            catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
        }
        'T' {
            try { $n = Clear-PSCMActionQueue -Status 'all' -OlderThanDays 0; Write-Host ('Kuyruk temizlendi. Silinen dosya sayisi: ' + $n) -ForegroundColor Green }
            catch { Write-Host ('Hata: ' + $_.Exception.Message) -ForegroundColor Red }
        }
    }
    Pause-PSCM
}
